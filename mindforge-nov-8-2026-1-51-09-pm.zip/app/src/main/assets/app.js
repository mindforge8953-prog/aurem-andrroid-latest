import {isNonCoreProduct,parseDelimited,detectTextEncoding,makeMaster,parseEanMappings,productMatches,resolveCode,boardFormat,parseMembership,normalizeBansal,parseMoneyCents,money,inferPack,unitPrice,barcodeText} from './core.js';

import {parseXlsxAll} from './xlsx.js';

import {boardSvg,pagePlan,a4Svg,makeTestPDF,planByPaper,boardPhysicalSize} from './preview.js';

import {mountNonCore} from './noncore.js';

import {mountInventory} from './inventory.js';

import {mountMigration} from './migration.js';

import {loadVerified,verifiedChoice,verified,verifiedName,saveVerified} from './verified.js';

const $=id=>document.getElementById(id);

const clean=()=>({master:null,stockFile:'',eanFile:'',importedAt:null,selected:{},issues:{},overrides:{},totalScans:0,duplicates:0,permanent:[],focus:[],nonCoreFocus:[],monthlyFile:'',monthlyAt:null,nameOverrides:{},theme:'dark',walkId:'',walkStatus:'in-progress',pairedPc:null,printMode:'standard',saverMargin:0,paperSelection:'ALL',printHistory:[],walkHistory:[]});

let quickEditCode=null,historyReturnState=null,historyReturnMode='core',historyViewRecord=null;

let state=clean(),eanLibrary={version:1,aliases:{},sourceFile:'',importedAt:null},pcService=false,localPc=false,editorCode=null,previewPage=0,previewCode=null,stream=null,cameraActive=false,cameraHold=false,cameraLast='',cameraLastAt=0,scanCameraNext=false,dbWrite=Promise.resolve(),saveOK=true,editorDirty=false;

async function walkHistoryList(){const db=await openDb();try{return await new Promise((res,rej)=>{const r=db.transaction('data').objectStore('data').get('floorWalkHistory');r.onsuccess=()=>res(Array.isArray(r.result)?r.result:[]);r.onerror=()=>rej(r.error)})}finally{db.close()}}
async function persistWalkArchive(record){const db=await openDb();try{return await new Promise((res,rej)=>{const tx=db.transaction('data','readwrite'),store=tx.objectStore('data'),req=store.get('floorWalkHistory');let result;req.onsuccess=()=>{const all=Array.isArray(req.result)?req.result:[],ix=all.findIndex(x=>x.kind===record.kind&&x.sessionId===record.sessionId);if(ix>=0){if(all[ix].status==='saved'&&record.status==='completed'){all[ix]=record;store.put(all,'floorWalkHistory')}result=all[ix]}else{all.unshift(record);store.put(all,'floorWalkHistory');result=record}};req.onerror=()=>rej(req.error||Error('History archive read failed'));tx.oncomplete=()=>res(result);tx.onerror=()=>rej(tx.error||Error('History archive write failed'));tx.onabort=()=>rej(tx.error||Error('History archive was aborted'))})}finally{db.close()}}
function makeCoreArchive(status='completed'){const codes=Object.keys(state.selected||{});const products=Object.fromEntries(codes.map(code=>[code,state.master?.products?.[code]]).filter(([,p])=>!!p));const selected=structuredClone(state.selected||{});const totalCopies=Object.values(selected).reduce((n,x)=>n+(Number(x.copies)||1),0);const at=new Date();return{kind:'CORE',status,sessionId:state.walkId||'CORE-'+at.getTime().toString(36),completedAt:status==='completed'?at.toISOString():null,localDateTime:at.toLocaleString('en-IN'),productCount:codes.length,totalCopies,selected,master:{products,lookups:{},productCount:codes.length},permanent:[...(state.permanent||[])],focus:[...(state.focus||[])],nonCoreFocus:[...(state.nonCoreFocus||[])],paperSelection:state.paperSelection||'ALL',printMode:state.printMode||'standard',saverMargin:state.saverMargin||0,stockFile:state.stockFile,eanFile:state.eanFile,importedAt:state.importedAt,totalScans:state.totalScans||0,duplicates:state.duplicates||0}}
async function archiveCoreWalk(status='completed'){if(!Object.keys(state.selected||{}).length)throw Error('There are no selected products to archive.');return persistWalkArchive(makeCoreArchive(status))}
let historyCurrentFilter='all';
async function renderWalkHistory(filter=historyCurrentFilter){historyCurrentFilter=filter;const root=$('floorWalkHistoryList');if(!root)return;root.innerHTML='<p class="quiet">Loading saved floor walks…</p>';try{const allItems=await walkHistoryList();const filtered=filter==='all'?allItems:allItems.filter(x=>String(x.kind).toUpperCase()===filter.toUpperCase());$('floorHistoryCount').textContent=`${filtered.length} of ${allItems.length} saved`;document.querySelectorAll('[data-history-filter]').forEach(b=>b.classList.toggle('active',b.dataset.historyFilter===filter));root.innerHTML=filtered.length?filtered.map((x)=>{const origIdx=allItems.indexOf(x);const when=x.localDateTime||new Date(x.completedAt||0).toLocaleString('en-IN'),label=x.status==='completed'?'Completed':'Saved unfinished',kind=x.kind==='NONCORE'?'NON-CORE':'CORE';return`<article class="history-session"><div class="section-title"><strong>${kind} · ${label}</strong><span class="tag">${escape(when)}</span></div><div class="subline">${Number(x.productCount)||0} unique products · ${Number(x.totalCopies)||0} requested copies</div><div class="action-grid"><button class="action ghost" data-open-floor-history="${origIdx}">Open Saved Floor Walk</button><button class="action ghost danger-text" data-delete-floor-history="${origIdx}">Delete</button></div></article>`}).join(''):`<p class="quiet">No ${filter==='all'?'':filter+' '}floor walks found in history.</p>`}catch(e){root.innerHTML='<p class="notice error">History could not be read: '+escape(e.message)+'</p>'}}
async function deleteFloorHistory(index){if(!confirm('Delete this saved floor walk from HISTORY? Saved product names, EAN aliases, and stock datasets will remain.'))return;const db=await openDb();try{const all=await walkHistoryList();if(index>=0&&index<all.length){all.splice(index,1);await new Promise((res,rej)=>{const tx=db.transaction('data','readwrite');tx.objectStore('data').put(all,'floorWalkHistory');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});toast('Floor walk removed from history.');renderWalkHistory();}}catch(e){toast('Could not delete history: '+e.message)}finally{db.close()}}
async function openFloorHistory(index){const items=await walkHistoryList(),record=items[index];if(!record)return toast('Saved floor walk not found.');if(historyReturnState)return toast('Close the current saved walk first.');historyReturnState=structuredClone(state);historyReturnMode=record.kind==='NONCORE'?'noncore':'core';historyViewRecord=record;if(record.kind==='NONCORE'){state={...clean(),master:record.master,selected:{},walkId:record.sessionId,walkStatus:'finished',nonCoreFocus:record.nonCoreFocus||[],focus:record.focus||[],permanent:record.permanent||[],paperSelection:record.paperSelection||'ALL',printMode:record.printMode||'standard'};window.auremOpenNonCoreHistory?.(record);setAppMode('noncore');return;}state={...clean(),...record,selected:structuredClone(record.selected),walkStatus:'finished'};setAppMode('core');selectTab('boards');$('historyViewBanner').classList.remove('hidden');$('historyViewLabel').textContent=`Viewing saved CORE walk · ${record.localDateTime||''}`;renderBoards()}
function closeFloorHistory(){if(!historyReturnState)return;state=historyReturnState;historyReturnState=null;historyViewRecord=null;if(historyReturnMode==='noncore')window.auremRestoreNonCoreHistory?.();$('historyViewBanner')?.classList.add('hidden');setAppMode('core');selectTab('scan');render()}
window.auremPersistWalkArchive=persistWalkArchive;window.auremRefreshWalkHistory=renderWalkHistory;window.auremCloseFloorHistory=closeFloorHistory;window.auremDeleteFloorHistory=deleteFloorHistory;
export function attachAutoUppercase(el){
 if(!el)return;
 el.style.textTransform='uppercase';
 const h=()=>{
  const val=el.value;const upper=val.toUpperCase();
  if(val!==upper){
   const start=el.selectionStart,end=el.selectionEnd;
   el.value=upper;
   if(start!==null&&end!==null)el.setSelectionRange(start,end);
  }
 };
 el.addEventListener('input',h);
 el.addEventListener('paste',()=>setTimeout(h,0));
}

const escape=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

const blobToBase64=blob=>new Promise((resolve,reject)=>{const r=new FileReader();r.onloadend=()=>resolve(r.result.split(',')[1]);r.onerror=reject;r.readAsDataURL(blob)});

let sharedScannerStream=null,sharedBarcodeActive=false,sharedOcrBusy=false,scannerMode='barcode',scannerCallback=null,scannerLoopTimer=0,ocrSamples=[],manualEntryAvailableAt=0;
window.onAuremOcrResult=(id,text)=>{const pending=window._auremOcrPending;if(!pending||pending.id!==id)return;pending.resolve(String(text||''));window._auremOcrPending=null};
function scannerStatus(text){const el=$('sharedScannerStatus');if(el)el.textContent=text}
function showScannerCandidate(number='',uncertain=false,note=''){const panel=$('scannerCandidate');panel?.classList.remove('hidden');$('scannerCandidateInput').value=number;$('scannerCandidateUncertainty').textContent=uncertain?'Review carefully: recognition is uncertain. Edit or retake before lookup.':note;$('scannerCandidateInput').readOnly=true;$('scannerEditNumber').textContent='Edit Number';$('scannerCandidateInput').focus({preventScroll:true})}
function hideScannerCandidate(){ $('scannerCandidate')?.classList.add('hidden');$('scannerCandidateInput').value='';$('scannerCandidateInput').readOnly=true;$('scannerEditNumber').textContent='Edit Number'}
function ean13Valid(s){if(!/^\d{13}$/.test(s))return false;let sum=0;for(let i=0;i<12;i++)sum+=Number(s[i])*(i%2?3:1);return(10-sum%10)%10===Number(s[12])}
function closeSharedScanner(){sharedBarcodeActive=false;sharedOcrBusy=false;clearTimeout(scannerLoopTimer);scannerLoopTimer=0;if(sharedScannerStream){sharedScannerStream.getTracks().forEach(t=>t.stop());sharedScannerStream=null}const v=$('sharedScannerVideo');if(v){v.pause();v.srcObject=null}const d=$('sharedScannerDialog');if(d?.open)d.close();hideScannerCandidate();cameraActive=false;if($('cameraBtn'))$('cameraBtn').textContent='Scan';if($('nScanCamera'))$('nScanCamera').textContent='Scan'}
async function openSharedCamera(defaultMode='barcode',callback=()=>{}){if(sharedScannerStream){closeSharedScanner();return}if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera permission or secure camera access is unavailable.');const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}}});sharedScannerStream=stream;scannerCallback=callback;scannerMode=defaultMode;ocrSamples=[];const d=$('sharedScannerDialog'),v=$('sharedScannerVideo');if(d&&!d.open)d.showModal();v.srcObject=stream;await v.play();$('scannerModeBarcode').classList.toggle('active',scannerMode==='barcode');$('scannerModeNumbers').classList.toggle('active',scannerMode==='numbers');$('scannerModeHint').textContent=scannerMode==='barcode'?'Scan (Barcode)':'Scan (Numbers)';$('scannerManual').classList.add('hidden');hideScannerCandidate();runScannerMode();return v}
window.auremStopScanner=closeSharedScanner;window.auremScannerActive=()=>!!sharedScannerStream;
function runScannerMode(){$('scannerModeBarcode').classList.toggle('active',scannerMode==='barcode');$('scannerModeNumbers').classList.toggle('active',scannerMode==='numbers');$('scannerModeHint').textContent=scannerMode==='barcode'?'Scan (Barcode)':'Scan (Numbers) · Experimental, on-device recognition';clearTimeout(scannerLoopTimer);sharedBarcodeActive=scannerMode==='barcode';if(scannerMode==='barcode'){hideScannerCandidate();scannerStatus('Looking for barcode…');runBarcodeLoop()}else{sharedBarcodeActive=false;scannerStatus('Looking for barcode…');ocrSamples=[];manualEntryAvailableAt=Date.now()+9000;runNumbersLoop()}}
async function runBarcodeLoop(){if(!sharedScannerStream||scannerMode!=='barcode')return;if(!('BarcodeDetector'in window)){scannerStatus('Barcode decoder is unavailable. Choose Scan (Numbers) or enter the code manually.');$('scannerManual').classList.remove('hidden');return}try{const formats=(await BarcodeDetector.getSupportedFormats()).filter(x=>['ean_13','ean_8','upc_a','upc_e','code_128','code_39','itf'].includes(x));if(!formats.length)throw Error('No supported linear barcode types.');const detector=new BarcodeDetector({formats}),v=$('sharedScannerVideo');let busy=false;const tick=async()=>{if(!sharedScannerStream||scannerMode!=='barcode'||busy)return;try{if(v.readyState>=2){busy=true;const hits=await detector.detect(v);if(hits.length){const value=String(hits[0].rawValue||'');closeSharedScanner();scannerCallback?.(value);return}}}catch(e){scannerStatus('Looking for barcode… '+e.message)}finally{busy=false}if(sharedScannerStream&&scannerMode==='barcode')scannerLoopTimer=setTimeout(tick,220)};tick()}catch(e){scannerStatus('Barcode scanning unavailable: '+e.message);$('scannerManual').classList.remove('hidden')}}
async function readLocalizedOcrFrame(video){if(!window.AUREMNative?.recognizeDigits)throw Error('On-device OCR is unavailable in this Android build.');const c=document.createElement('canvas');c.width=video.videoWidth;c.height=video.videoHeight;if(!c.width||!c.height)return'';c.getContext('2d').drawImage(video,0,0);const b64=c.toDataURL('image/jpeg',.88).split(',')[1],id='ocr-'+Date.now()+'-'+Math.random().toString(36).slice(2,7);return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{if(window._auremOcrPending?.id===id)window._auremOcrPending=null;reject(Error('OCR took too long.'))},12000);window._auremOcrPending={id,resolve:t=>{clearTimeout(timer);resolve(t)}};window.AUREMNative.recognizeDigits(b64,id)})}
async function runNumbersLoop(){if(!sharedScannerStream||scannerMode!=='numbers'||sharedOcrBusy)return;sharedOcrBusy=true;try{const raw=await readLocalizedOcrFrame($('sharedScannerVideo')),uncertain=raw.includes('UNSURE'),digits=[...new Set((raw.replace(/UNSURE/g,'').match(/\d{5,14}/g)||[]))];ocrSamples.push({digits,uncertain});if(ocrSamples.length>4)ocrSamples.shift();const all=ocrSamples.flatMap(x=>x.digits),stable=[...new Set(all)].map(n=>({n,count:all.filter(x=>x===n).length,good:ocrSamples.filter(x=>!x.uncertain&&x.digits.includes(n)).length})).sort((a,b)=>b.good-a.good||b.count-a.count||b.n.length-a.n.length)[0];if(stable&&stable.count>=2&&stable.good>=2){const bad13=stable.n.length===13&&!ean13Valid(stable.n),uncertainRead=bad13||ocrSamples.slice(-2).some(x=>x.uncertain);showScannerCandidate(stable.n,uncertainRead,bad13?'EAN-13 checksum does not match; no digit was changed. Retake or edit the complete printed number.':stable.n.length===12?'12 digits detected. If the label is EAN-13, check for a separately printed leading digit.':'Digits detected near a linear barcode.');scannerStatus('Digits are stable. Confirm or edit the printed number.');return}scannerStatus(uncertain?'Looking for barcode… hold the barcode in view.':'Looking for barcode…');if(Date.now()>manualEntryAvailableAt)$('scannerManual').classList.remove('hidden')}catch(e){scannerStatus('Looking for barcode… '+e.message);if(Date.now()>manualEntryAvailableAt)$('scannerManual').classList.remove('hidden')}finally{sharedOcrBusy=false}if(sharedScannerStream&&scannerMode==='numbers'&&$('scannerCandidate').classList.contains('hidden'))scannerLoopTimer=setTimeout(runNumbersLoop,850)}
window.auremOpenScanner=async(callback,mode='barcode')=>{try{await openSharedCamera(mode,callback)}catch(e){closeSharedScanner();throw e}};window.auremStartBarcodeScan=callback=>window.auremOpenScanner(callback,'barcode');window.auremScanNumbers=callback=>window.auremOpenScanner(callback,'numbers');
function confirmScannerCandidate(){const value=$('scannerCandidateInput').value.trim();if(!/^\d{5,18}$/.test(value)){scannerStatus('Enter 5–18 digits, or retake the scan.');return}const cb=scannerCallback;closeSharedScanner();cb?.(value)}
function chooseScannerManual(){showScannerCandidate('',true,'Manual entry. Type the complete printed barcode or Bansal CODE; nothing is guessed.');$('scannerCandidateInput').readOnly=false;$('scannerCandidateInput').focus()}
function resetScannerNumbers(){hideScannerCandidate();ocrSamples=[];$('scannerManual').classList.remove('hidden');scannerStatus('Looking for barcode…')}
$('scannerModeBarcode')?.addEventListener('click',()=>{scannerMode='barcode';runScannerMode()});$('scannerModeNumbers')?.addEventListener('click',()=>{scannerMode='numbers';runScannerMode()});$('sharedScannerClose')?.addEventListener('click',closeSharedScanner);$('scannerCandidateConfirm')?.addEventListener('click',confirmScannerCandidate);$('scannerCandidateRetake')?.addEventListener('click',resetScannerNumbers);$('scannerEditNumber')?.addEventListener('click',()=>{const input=$('scannerCandidateInput');input.readOnly=false;input.focus();$('scannerEditNumber').textContent='Editing number'});$('scannerManual')?.addEventListener('click',chooseScannerManual);$('sharedScannerDialog')?.addEventListener('cancel',closeSharedScanner);
async function startCoreOcr(){if(!ready())return toast('Import stock first.');window.auremOpenScanner(value=>findScan(value,true),'numbers')}
const ready=()=>!!state.master?.productCount;

const humanDate=v=>v?new Date(v).toLocaleString('en-IN'):'not loaded';

function setMessage(id,msg,type=''){const e=$(id);e.textContent=msg;e.className='notice '+type;}

function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),3700)}

function openDb(){return new Promise((res,rej)=>{const req=indexedDB.open('AUREM_Offline_Data',1);req.onupgradeneeded=()=>req.result.createObjectStore('data');req.onerror=()=>rej(req.error);req.onsuccess=()=>res(req.result)})}

async function loadStored(){
 const db=await openDb();
 try{return await new Promise((res,rej)=>{let session=null,master=null,history=null,library=null;const tx=db.transaction('data'),store=tx.objectStore('data');
  store.get('session').onsuccess=e=>session=e.target.result;store.get('master').onsuccess=e=>master=e.target.result;store.get('printHistory').onsuccess=e=>history=e.target.result;store.get('eanLibrary').onsuccess=e=>library=e.target.result;
  tx.oncomplete=()=>res(session?{...session,master:master||session.master,printHistory:history||session.printHistory||[],eanLibrary:library}:master||library?{master,eanLibrary:library,printHistory:history||[]}:null);tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error||Error('Offline storage read was aborted'))
 })}finally{db.close()}
}
function normalizeEanLibrary(value={}){const aliases=Object.create(null);for(const [raw,codes]of Object.entries(value.aliases||{})){const alias=barcodeText(raw),list=[...new Set((Array.isArray(codes)?codes:[codes]).map(normalizeBansal).filter(c=>/^\d{9}$/.test(c)))];if(alias&&list.length)aliases[alias]=list}const conflicts=Array.isArray(value.conflicts)?structuredClone(value.conflicts):[];return{version:1,aliases,conflicts,sourceFile:String(value.sourceFile||''),importedAt:Number(value.importedAt)||null}}
function mergeEanPairs(base,pairs){const library=normalizeEanLibrary(base);const conflicts=library.conflicts?[...library.conflicts]:[];let added=0,duplicates=0,newConflicts=0;for(const {code,ean}of pairs){const alias=barcodeText(ean),canonical=normalizeBansal(code);if(!alias||!/^\d{9}$/.test(canonical))continue;const linked=library.aliases[alias];if(linked&&linked.length){if(linked.includes(canonical)){duplicates++;continue;}const alreadyLogged=conflicts.some(c=>c.ean===alias&&c.incomingCode===canonical);if(!alreadyLogged){conflicts.push({ean:alias,existingCodes:[...linked],incomingCode:canonical,recordedAt:Date.now()});newConflicts++;}continue;}library.aliases[alias]=[canonical];added++;}library.conflicts=conflicts;return{library,conflicts,added,duplicates,newConflicts};}
function applyEanLibrary(master,library){const merged=normalizeEanLibrary(library),lookups=Object.create(null);for(const [alias,codes]of Object.entries(merged.aliases))lookups[alias]=[...codes];for(const code of Object.keys(master.products||{})){for(const alias of [code,master.products[code].barcode]){const key=barcodeText(alias);if(!key)continue;const list=lookups[key]||(lookups[key]=[]);if(!list.includes(code))list.push(code)}}master.lookups=lookups;master.conflicts=Object.entries(lookups).filter(([,codes])=>codes.length>1).map(([barcode,codes])=>({barcode,codes}));return master}
async function persistImportedState(){if(!saveOK)throw Error('Offline browser storage is unavailable.');const session=structuredClone({...state,master:null,printHistory:[]}),master=structuredClone(state.master),library=structuredClone(eanLibrary);dbWrite=dbWrite.catch(()=>{}).then(async()=>{const db=await openDb();try{await new Promise((res,rej)=>{const tx=db.transaction('data','readwrite'),store=tx.objectStore('data');store.put(session,'session');if(master)store.put(master,'master');store.put(library,'eanLibrary');tx.oncomplete=res;tx.onerror=()=>rej(tx.error||Error('Imported data transaction failed'));tx.onabort=()=>rej(tx.error||Error('Imported data transaction aborted'))})}finally{db.close()}});return dbWrite}
function save(withMaster=false){if(!saveOK)return Promise.reject(Error('Offline browser storage is unavailable'));

 const session=structuredClone({...state,master:null,printHistory:[]}),master=withMaster?structuredClone(state.master):null;

 dbWrite=dbWrite.catch(()=>{}).then(async()=>{const db=await openDb();try{await new Promise((res,rej)=>{const tx=db.transaction('data','readwrite');tx.objectStore('data').put(session,'session');if(withMaster)tx.objectStore('data').put(master,'master');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}finally{db.close()}});

 return dbWrite;

}

async function persistLibraryAndMaster(){const master=structuredClone(state.master),library=structuredClone(eanLibrary),session=structuredClone({...state,master:null,printHistory:[]});dbWrite=dbWrite.catch(()=>{}).then(async()=>{const db=await openDb();try{await new Promise((res,rej)=>{const tx=db.transaction('data','readwrite'),store=tx.objectStore('data');store.put(master,'master');store.put(library,'eanLibrary');store.put(session,'session');tx.oncomplete=res;tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error||Error('EAN Library save aborted'))})}finally{db.close()}});return dbWrite}
async function persistRegRemoval(){const session=structuredClone({...state,master:null,printHistory:[]});dbWrite=dbWrite.catch(()=>{}).then(async()=>{const db=await openDb();try{await new Promise((res,rej)=>{const tx=db.transaction('data','readwrite'),store=tx.objectStore('data');store.put(session,'session');store.delete('master');tx.oncomplete=res;tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error||Error('REG-STAT removal was aborted'))})}finally{db.close()}});return dbWrite}


// Store history under its own IndexedDB key so daily scan autosaves stay fast.

function saveHistory(){if(!saveOK)return Promise.reject(Error('Offline browser storage is unavailable'));

 const history=structuredClone(state.printHistory||[]);

 dbWrite=dbWrite.catch(()=>{}).then(async()=>{const db=await openDb();try{await new Promise((res,rej)=>{const tx=db.transaction('data','readwrite');tx.objectStore('data').put(history,'printHistory');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}finally{db.close()}});

 return dbWrite;

}

function importYield(){return new Promise(resolve=>setTimeout(resolve,0))}
function setImportProgress(value,label,kind=''){$('importProgress').value=Math.max(0,Math.min(100,value));$('importProgressText').textContent=label;$('importProgressText').className='mini'+(kind?' '+kind:'')}
function textDelimiter(text,fileName){if(/\.tsv$/i.test(fileName))return'\t';if(/\.csv$/i.test(fileName))return',';let bestTab=0,bestComma=0;for(const line of text.slice(0,2000000).split(/\r?\n/).slice(0,3000)){let tabs=0,commas=0;for(const ch of line){if(ch==='\t')tabs++;else if(ch===',')commas++;}bestTab=Math.max(bestTab,tabs);bestComma=Math.max(bestComma,commas);}return bestTab>bestComma?'\t':','}
function readImportBytes(blob,fileName){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error(`Android could not read ${fileName} (${reader.error?.name||'FileReader error'}). Check the file is available in Downloads and try again.`));reader.onabort=()=>reject(Error(`Reading ${fileName} was cancelled.`));try{reader.readAsArrayBuffer(blob)}catch(e){reject(Error(`Android could not open ${fileName}: ${e?.message||'file access failed'}`))}})}
async function decodeImportText(f,fileName,encoding,onProgress){const decoder=new TextDecoder(encoding,{fatal:true}),chunkSize=1024*1024;let content='';for(let offset=0;offset<f.size;offset+=chunkSize){const end=Math.min(f.size,offset+chunkSize),chunk=new Uint8Array(await readImportBytes(f.slice(offset,end),fileName));content+=decoder.decode(chunk,{stream:end<f.size});onProgress(end/f.size);await importYield();}return content+decoder.decode()}
async function fileSheets(f,onProgress=()=>{}){if(!f)throw Error('Choose a file.');const fileName=f.name||'selected file',nameExt=(fileName.match(/\.[^.]+$/)||[''])[0].toLowerCase(),mime=String(f.type||'').split(';')[0].trim().toLowerCase();if(nameExt==='.xlsx'||mime==='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'){onProgress(0);const workbookFile={name:fileName,arrayBuffer:()=>readImportBytes(f,fileName)};const sheets=await parseXlsxAll(workbookFile);onProgress(1);return sheets.map(sheet=>({...sheet,format:'XLSX'}));}if(nameExt==='.xls')throw Error(`Legacy .xls workbook ${fileName} cannot be read offline. Save it as CSV or XLSX and select the converted file.`);const textMimes=['text/csv','application/csv','text/plain','application/vnd.ms-excel','application/octet-stream'];if(!['.csv','.tsv','.txt'].includes(nameExt)&&!textMimes.includes(mime))throw Error(`Unsupported file ${fileName} (type ${mime||'unknown'}). Select a CSV, TSV, TXT, or XLSX file.`);if(!f.size)throw Error(`${fileName} is empty.`);const effectiveExt=['.csv','.tsv','.txt'].includes(nameExt)?nameExt:(mime==='text/csv'||mime==='application/csv'?'.csv':'.txt');const sample=new Uint8Array(await readImportBytes(f.slice(0,Math.min(65536,f.size)),fileName));let encoding=detectTextEncoding(sample),content='';try{content=await decodeImportText(f,fileName,encoding,onProgress)}catch(e){if(e?.message?.startsWith('Android could not')||e?.message?.startsWith('Reading '))throw e;if(encoding!=='utf-8')throw Error(`${fileName} could not be decoded as ${encoding}. Check that the file is complete and try again.`);try{encoding='windows-1252';content=await decodeImportText(f,fileName,encoding,onProgress)}catch(fallbackError){if(fallbackError?.message?.startsWith('Android could not')||fallbackError?.message?.startsWith('Reading '))throw fallbackError;throw Error(`${fileName} could not be decoded as UTF-8 or Windows-1252. Check the file encoding and try again.`)}}if(!content.trim())throw Error(`${fileName} contains no readable text.`);const delimiter=textDelimiter(content,effectiveExt),rows=parseDelimited(content,delimiter);if(!rows.length)throw Error(`${fileName} contains no readable rows.`);return[{name:fileName,rows,encoding,delimiter,format:effectiveExt.slice(1).toUpperCase()}];}function membershipWorkbook(all){const focus=all.find(s=>/FOCUS/i.test(s.name)),permanent=all.find(s=>/PERMANENT/i.test(s.name));if(!focus||!permanent)throw Error('Monthly Excel needs a FOCUS sheet and a PERMANENT sheet.');return{focus:parseMembership(focus.rows,'focus'),permanent:parseMembership(permanent.rows,'permanent')}}

function updateSelectedFileName(id){const input=$(id),label=$(id+'Name');if(label)label.textContent=input.files?.[0]?.name||'No file selected';}async function importReports(){
 const reg=$('regFile').files[0],ean=$('eanFile').files[0],month=$('monthlyFile').files[0],f=$('focusFile').files[0],p=$('permanentFile').files[0],ncFocus=$('nonCoreFocusFile').files[0];
 if(!reg&&!ean&&!month&&!f&&!p&&!ncFocus)return setMessage('importInfo','Choose at least one file to import or update.','warn');
 if(month&&(f||p))return setMessage('importInfo','Choose either one combined monthly workbook OR two separate lists.','error');
 if((f&&!p)||(p&&!f))return setMessage('importInfo','Please select BOTH separate Focus and Permanent files.','error');
 if(reg&&(Object.keys(state.selected||{}).length||Object.keys(state.issues||{}).length)&&!confirm('Replacing REG-STAT starts a fresh floor walk. Corrected names, EAN aliases, audit records and completed History are preserved. Continue?'))return;
 const button=$('importBoth'),tasks=[...(reg?[['REG-STAT',reg]]:[]),...(ean?[['ITEM_EANS',ean]]:[]),...(month?[['Monthly workbook',month]]:[]),...(f?[['Focus list',f],['Permanent list',p]]:[]),...(ncFocus?[['NON-CORE Focus list',ncFocus]]:[])],totalBytes=tasks.reduce((n,[,file])=>n+Math.max(1,file.size||0),0);let completedBytes=0;button.disabled=true;button.textContent='Reading files…';$('importProgress').value=0;setImportProgress(0,'Validated data stays available unless this update passes and is saved.');
 const read=async(label,file)=>{setImportProgress(totalBytes?70*completedBytes/totalBytes:0,'Reading '+label+': '+file.name);await importYield();const result=await fileSheets(file,fraction=>setImportProgress(totalBytes?70*(completedBytes+Math.max(1,file.size||0)*fraction)/totalBytes:0,'Reading '+label+': '+file.name));completedBytes+=Math.max(1,file.size||0);return result};
 const before=structuredClone(state),oldLibrary=structuredClone(eanLibrary);
 try{
  let stockSheets=null,eanSheets=null,monthlySheets=null,focusSheets=null,permanentSheets=null,nonCoreSheets=null;
  for(const [label,file]of tasks){const result=await read(label,file);if(file===reg)stockSheets=result;else if(file===ean)eanSheets=result;else if(file===month)monthlySheets=result;else if(file===f)focusSheets=result;else if(file===p)permanentSheets=result;else if(file===ncFocus)nonCoreSheets=result}
  setImportProgress(76,'Validating stock columns, canonical codes and barcode aliases…');await importYield();
  let master=stockSheets?makeMaster(stockSheets[0].rows,[],true):structuredClone(state.master);
  let merged=mergeEanPairs(eanLibrary,master?Object.entries(master.lookups||{}).flatMap(([alias,codes])=>(codes||[]).map(code=>({ean:alias,code}))):[]);
  let added=merged.added;
  let conflicts=merged.conflicts;
  let eanRowsProcessed=0;
  if(eanSheets){
   const parsed=parseEanMappings(eanSheets[0].rows);
   eanRowsProcessed=parsed.totalProcessed||(eanSheets[0].rows.length-1);
   const result=mergeEanPairs(merged.library,parsed);
   merged=result;
   added+=result.added;
   conflicts=result.conflicts;
  }
  eanLibrary=merged.library;
  eanLibrary.conflicts=conflicts;
  if(eanSheets){
   eanLibrary.sourceFile=ean.name;
   eanLibrary.importedAt=Date.now();
  }
  if(master&&master.products&&Object.keys(master.products).length){
   master=applyEanLibrary(master,eanLibrary);
   master.mappingRows=Object.keys(eanLibrary.aliases).length;
   master.libraryAliasCount=master.mappingRows;
   master.sourceFormat=stockSheets?stockSheets[0].format:state.master?.sourceFormat||'';
   master.encoding=stockSheets?stockSheets[0].encoding:state.master?.encoding||'';
  }
  const monthLists=monthlySheets?membershipWorkbook(monthlySheets):focusSheets&&permanentSheets?{focus:parseMembership(focusSheets[0].rows,'focus'),permanent:parseMembership(permanentSheets[0].rows,'permanent')}:null,nextNonCore=nonCoreSheets?parseMembership(nonCoreSheets[0].rows,'focus'):state.nonCoreFocus;
  state={...state,master:master||state.master,nonCoreFocus:nextNonCore,stockFile:reg?.name||state.stockFile,eanFile:ean?.name||state.eanFile,importedAt:reg?Date.now():state.importedAt,selected:reg?{}:state.selected,issues:reg?{}:state.issues,overrides:reg?{}:state.overrides,totalScans:reg?0:state.totalScans,duplicates:reg?0:state.duplicates,walkId:reg?'FW-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10):state.walkId,walkStatus:reg?'in-progress':state.walkStatus,...(monthLists?{...monthLists,monthlyFile:month?.name||((f?.name||'Focus')+' + '+(p?.name||'Permanent')),monthlyAt:Date.now()}: {})};
  setImportProgress(92,'Saving validated datasets and merged EAN aliases on this device…');await importYield();await persistImportedState();editorCode=null;editorDirty=false;previewPage=0;render();renderEanLibrary();setAppMode('core');
  const summaryParts=[];
  summaryParts.push('File accepted successfully');
  if(eanSheets){
   summaryParts.push(`${eanRowsProcessed.toLocaleString('en-IN')} valid rows processed`);
  }else if(reg&&state.master){
   summaryParts.push(`${state.master.productCount.toLocaleString('en-IN')} valid products processed`);
  }
  if(conflicts.length){
   summaryParts.push(`${conflicts.length} conflict(s) saved for review`);
  }
  const resultMsg=summaryParts.join(' · ')+'.';
  setImportProgress(100,resultMsg,'good');
  setMessage('importInfo',resultMsg,'good');
  toast('File accepted successfully');
 }catch(e){state=before;eanLibrary=oldLibrary;renderImport();renderEanLibrary();setMessage('importInfo','Update failed. Your previous saved datasets remain active. '+(e?.message||'Check the selected files.'),'error');setImportProgress(0,'Update failed; previous data kept. '+(e?.message||''),'error');toast('Import failed: '+(e?.message||'Could not validate files.'))}
 finally{button.disabled=false;button.innerHTML='Import & validate files <span>→</span>'}
}
function selectTab(key){document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===key));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('hidden',p.id!=='page-'+key));if(key!=='scan')stopCamera();if(key==='boards')renderBoards();if(key==='scan')renderScan();}

function selectedProduct(code){const p=state.master.products[code],choice=state.selected[code];return{...p,name:choice?.name||state.nameOverrides[code]||p.name,mrp:choice?.mrpOverride||p.mrp,retail:choice?.spOverride||p.retail}}

function selections(){const perms=new Set(state.permanent),focus=new Set(state.focus);return Object.keys(state.selected).map(code=>({product:selectedProduct(code),format:boardFormat(selectedProduct(code),perms,focus),choice:state.selected[code]}))}

function initialChoice(code){const p=state.master.products[code],fmt=boardFormat(p,new Set(state.permanent),new Set(state.focus)),inf=inferPack(p);return{size:fmt.format==='B1G1'||fmt.format==='B1G2'?'1/4':'1/8',style20:'standard',copies:1,name:verified(code)?.name||state.nameOverrides[code]||p.name,qty:verifiedChoice(code).qty||inf.qty,unit:verifiedChoice(code).unit||(inf.unit==='KGS'?'KG':inf.unit==='GRAM'?'G':inf.unit==='LITRE'?'LTR':inf.unit),mrpOverride:'',spOverride:''}}

function findScan(raw,fromCamera=false){

 if(!ready()){selectTab('import');toast('Import your files first.');return}if(state.walkStatus==='finished'){toast('Floor walk finished. Reopen scanning by selecting Save Floor Walk.');return}const barcode=barcodeText(raw);if(!barcode)return;

 

 if(fromCamera){cameraLast=barcode;cameraLastAt=Date.now()}

 const result=resolveCode(barcode,state.master,state.overrides);state.totalScans++;scanCameraNext=result.status==='MATCH'&&fromCamera;

 if(result.status==='MATCH' && isNonCoreProduct(result.product)){

  $('barcodeInput').value='';setMessage('scanResult','WRONG SECTION — NON-CORE PRODUCT. Scan in NON-CORE: '+result.product.name,'error');renderScan();return;

 }

 if(result.status==='MATCH'){

  const existed=!!state.selected[result.code];if(existed)state.duplicates++;else state.selected[result.code]=initialChoice(result.code);

  editorCode=result.code;editorDirty=false;

  if(fromCamera)stopCamera();

  setMessage('scanResult',`${existed?'ALREADY ON LIST':'PRODUCT FOUND'} — ${state.selected[result.code].name} • ${result.code}`,'good');

 }else{

  const issue=state.issues[barcode]||{barcode,count:0,status:result.status,candidates:[]};issue.count++;issue.status=result.status;issue.candidates=result.candidates||[];state.issues[barcode]=issue;

  setMessage('scanResult',`${result.status} — ${barcode}. Not recognized; skipped. Continue scanning.`,'warn');

 }

 $('barcodeInput').value='';save().catch(e=>toast('Autosave failed: '+e.message));renderScan();if(result.status==='MATCH')$('scanEditor').scrollIntoView({behavior:'smooth',block:'start'});

}

function renderCoreProductMatches(){const q=$('coreProductSearch').value.trim().toLocaleLowerCase();const root=$('coreProductResults');if(!q){root.innerHTML='';return;}if(!ready()){root.innerHTML='<p class="quiet">Import stock data first.</p>';return;}const matches=Object.keys(state.master.products).filter(code=>{const p=state.master.products[code];return !isNonCoreProduct(p)&&productMatches(state.master,code,q,[verifiedName(code,p.name)]);}).slice(0,30);root.innerHTML=matches.length?matches.map(code=>{const p=state.master.products[code];return `<button type="button" class="product-search-result" role="option" data-core-product="${escape(code)}"><strong>${escape(verifiedName(code,p.name))}</strong><span>Bansal CODE ${escape(code)} · CORE${state.selected[code]?' · already added':''}</span></button>`;}).join(''):'<p class="quiet">No CORE products match that name.</p>';}
function selectCoreProductByName(code){if(!ready()||!state.master.products[code]||isNonCoreProduct(state.master.products[code]))return;if(state.walkStatus==='finished')return toast('Floor walk finished. Reopen scanning by selecting Save Floor Walk.');const existed=!!state.selected[code];state.selected[code]??=initialChoice(code);editorCode=code;editorDirty=false;$('coreProductSearch').value='';$('coreProductResults').innerHTML='';setMessage('scanResult',`${existed?'ALREADY ON LIST':'PRODUCT SELECTED'} — ${state.selected[code].name} • ${code}`,'good');save().catch(e=>toast('Autosave failed: '+e.message));renderScan();if(window.innerWidth<730)$('scanEditor').scrollIntoView({behavior:'smooth',block:'start'});}
async function resolveIssue(barcode,input){const code=normalizeBansal(input);if(!state.master.products[code])return toast('That Bansal CODE is not in the current stock report');if(isNonCoreProduct(state.master.products[code]))return toast('WRONG SECTION — NON-CORE product: use NON-CORE floor walk.');if(!confirm(`Confirm ${barcode} is ${code} (${state.master.products[code].name})?`))return;

 state.overrides[barcode]=code;delete state.issues[barcode];state.selected[code]??=initialChoice(code);editorCode=code;await save();renderScan();toast('Barcode resolved to '+code);

}

function editorControls(){

 const valid=!!editorCode&&ready()&&!!state.selected[editorCode];$('editEmpty').classList.toggle('hidden',valid);$('editForm').classList.toggle('hidden',!valid);if(!valid)return;

 const c=state.selected[editorCode],base=state.master.products[editorCode];$('editItem').innerHTML=`${escape(c.name||verifiedName(editorCode,base.name))}<small>Bansal CODE ${escape(editorCode)} · MRP ₹${escape(base.mrp)} · RETAIL ₹${escape(base.retail)}</small>`;

 $('editName').value=c.name;$('editSize').value=c.size;$('editStyle20').value=c.style20==='mahir'?'mahir':'standard';$('editCopies').value=c.copies;$('editQty').value=c.qty??'';$('editUnit').value=['KG','G','LTR','ML','NOS'].includes(c.unit)?c.unit:'';

 $('editMrp').value=c.mrpOverride||'';$('editSp').value=c.spOverride||'';

 for(const id of ['editName','editSize','editStyle20','editCopies','editQty','editUnit','editMrp','editSp','saveEdit','resetBoardName'])$(id).disabled=state.walkStatus==='finished';

 refreshEditorOffer();

}

function refreshEditorOffer(){if(!editorCode||!state.selected[editorCode])return;const ch=state.selected[editorCode],p=selectedProduct(editorCode),fmt=boardFormat(p,new Set(state.permanent),new Set(state.focus)),u=unitPrice(p,fmt,ch);

 const compact=ch.size==='1/20';$('style20Section').classList.toggle('hidden',!compact);const buyget=['B1G1','B1G2'].includes(fmt.format);$('editStyle20').disabled=state.walkStatus==='finished'||!buyget;$('style20Note').textContent=buyget?'Standard keeps the original 1/20 R-Soft layout; Mahir’s Style adds a bordered PER PCS footer, without changing size or main text.':'Only B1G1/B1G2 can use Mahir’s Style. Other 1/20 boards always use Standard.';

 $('editOffer').innerHTML=fmt.error?`<strong style="color:var(--bad)">PRICE REVIEW REQUIRED</strong><div>${escape(fmt.detail)}</div>`:`<strong>${escape(fmt.detail||fmt.format)}</strong><div class="subline">${fmt.focus?'★ Focus product · ':''}${ch.size!=='1/20'&&u&&u.unit!=='PCS'?`₹${money(u.amount)} PER ${escape(u.unit)} · `:''}${escape(fmt.format)} · MRP ₹${escape(p.mrp)} · SP ₹${escape(p.retail)}</div>`;

}

function draftEditor(){if(state.walkStatus==='finished')return;if(!editorCode||!state.selected[editorCode])return;const c=state.selected[editorCode];c.name=$('editName').value;c.size=$('editSize').value;c.style20=$('editStyle20').value==='mahir'?'mahir':'standard';c.copies=Number($('editCopies').value);c.qty=$('editQty').value.trim();c.unit=$('editUnit').value;c.mrpOverride=$('editMrp').value.trim();c.spOverride=$('editSp').value.trim();editorDirty=true;refreshEditorOffer();save().catch(e=>toast('Autosave failed: '+e.message));}

async function saveEdit(){if(state.walkStatus==='finished')return toast('Select Save Floor Walk to reopen editing.');if(!editorCode)return;draftEditor();const c=state.selected[editorCode],p=state.master.products[editorCode];if(!c.name.trim())return toast('Please enter a board name.');if(!Number.isInteger(c.copies)||c.copies<1||c.copies>300)return toast('Copies must be a whole number between 1 and 300.');if(!['1/20','1/9','1/8','1/4','1/3','1/2','1/1'].includes(c.size))return toast('Select a board size.');if(!['standard','mahir'].includes(c.style20))return toast('Select a valid 1/20 style.');

 if(c.mrpOverride&&parseMoneyCents(c.mrpOverride)===null)return toast('Correct MRP must be a valid price.');if(c.spOverride&&parseMoneyCents(c.spOverride)===null)return toast('Correct selling price must be valid.');

 if(c.qty&&(!/^\d+(?:\.\d+)?$/.test(c.qty)||Number(c.qty)<=0))return toast('Quantity must be a positive number.');

 const name=c.name.trim().replace(/\s+/g,' ');c.name=name;if(name!==p.name)state.nameOverrides[editorCode]=name;else delete state.nameOverrides[editorCode];

 try{await saveVerified(editorCode,{name:c.name,qty:c.qty,unit:c.unit,kind:'core'});await save();editorDirty=false;cameraHold=false;toast('Board saved • name remembered for next walk');const resumeCamera=scanCameraNext;scanCameraNext=false;if(resumeCamera)setTimeout(()=>camera(),120);else $('barcodeInput').focus();}catch(e){toast('Save failed: '+e.message)}renderRecent();

}

async function resetName(){if(state.walkStatus==='finished')return toast('Select Save Floor Walk to reopen editing.');if(!editorCode)return;delete state.nameOverrides[editorCode];state.selected[editorCode].name=state.master.products[editorCode].name;await saveVerified(editorCode,{name:''});await save();editorControls();renderRecent();toast('Stock-report name restored');}

function renderEanLibrary(){const status=$('eanLibraryStatus'),list=$('eanAliases');if(!status||!list)return;const aliases=eanLibrary.aliases||{},count=Object.keys(aliases).length,conflicts=eanLibrary.conflicts||[],codes=new Set(Object.values(aliases).flat()),pending=[...codes].filter(c=>!state.master?.products?.[c]).length;status.textContent=count.toLocaleString('en-IN')+' saved barcode aliases · '+pending+' pending product mapping(s)'+(conflicts.length?' · '+conflicts.length+' conflict(s) saved for review':'')+(eanLibrary.sourceFile?' · last file '+eanLibrary.sourceFile:'')+(eanLibrary.importedAt?' · '+humanDate(eanLibrary.importedAt):'');const code=normalizeBansal($('eanProductCode')?.value||''),items=code?Object.entries(aliases).filter(([alias,mapped])=>mapped.includes(code)&&alias!==code).map(([alias])=>alias):[];list.innerHTML=items.length?items.map(alias=>'<span class="tag ean-alias">'+escape(alias)+'</span>').join(' '):'<p class="quiet">Enter or select a Bansal CODE to view its saved EAN aliases.</p>';const product=state.master?.products?.[code];$('eanProductSummary').textContent=code?(product?verifiedName(code,product.name)+' · Bansal CODE '+code:'Pending mapping · Bansal CODE '+code):'Select a product or enter its permanent Bansal CODE.'}
function renderEanProductMatches(){const q=$('eanProductSearch').value.trim().toLocaleLowerCase(),root=$('eanProductResults');if(!q||!ready()){root.innerHTML='';return}const master=state.master,matches=Object.keys(master.products).filter(code=>productMatches(master,code,q,[verifiedName(code,master.products[code].name)])).slice(0,12);root.innerHTML=matches.length?matches.map(code=>'<button type="button" class="product-search-result" data-ean-code="'+escape(code)+'"><strong>'+escape(verifiedName(code,master.products[code].name))+'</strong><span>Bansal CODE '+escape(code)+'</span></button>').join(''):'<p class="quiet">No matching product. You can enter a pending Bansal CODE below.</p>'}
function selectEanProduct(code){$('eanProductCode').value=normalizeBansal(code);$('eanProductSearch').value='';$('eanProductResults').innerHTML='';renderEanLibrary()}
function eanNotice(text,kind=''){const el=$('eanMappingNotice');if(el){el.textContent=text;el.className='notice '+kind}}
async function addEanAlias(){const rawCode=$('eanProductCode').value.trim(),code=normalizeBansal(rawCode),alias=barcodeText($('eanAliasInput').value.trim());if(!/^\d{9}$/.test(code))return eanNotice('Enter a valid permanent Bansal CODE.','error');if(!/^\d{5,18}$/.test(alias))return eanNotice('Enter a numeric barcode between 5 and 18 digits.','error');const linked=eanLibrary.aliases?.[alias]||[];if(linked.length&&(!linked.includes(code)||linked.some(x=>x!==code)))return eanNotice('Conflict: barcode '+alias+' is already mapped to '+linked.join(', ')+'. No change was made.','error');if(linked.includes(code))return eanNotice('This barcode is already linked to Bansal CODE '+code+'.','warn');const oldLib=structuredClone(eanLibrary),oldMaster=state.master?structuredClone(state.master):null;try{eanLibrary=normalizeEanLibrary(eanLibrary);eanLibrary.aliases[alias]=[code];if(state.master)applyEanLibrary(state.master,eanLibrary);await persistLibraryAndMaster();$('eanAliasInput').value='';renderEanLibrary();eanNotice((state.master?.products?.[code]?verifiedName(code,state.master.products[code].name):'Pending product')+' · barcode '+alias+' saved to Bansal CODE '+code+'.','good')}catch(e){eanLibrary=oldLib;if(state.master)state.master=oldMaster;eanNotice('Alias was not saved: '+e.message,'error')}}
async function removeEanAliases(){if(!confirm('Remove imported and manually added EAN aliases from this device? REG-STAT, corrected names, audit records and History will remain.'))return;const old=structuredClone(eanLibrary),oldMaster=state.master?structuredClone(state.master):null,oldFile=state.eanFile;try{eanLibrary={version:1,aliases:{},sourceFile:'',importedAt:null};state.eanFile='';if(state.master)applyEanLibrary(state.master,eanLibrary);await persistLibraryAndMaster();renderImport();renderEanLibrary();eanNotice('Saved EAN aliases were removed. Bansal CODE and current REG-STAT BAR CODE lookups remain.','good')}catch(e){eanLibrary=old;state.eanFile=oldFile;if(state.master)state.master=oldMaster;eanNotice('EAN Library was not removed: '+e.message,'error')}}
async function removeRegDataset(){if(!state.master)return toast('No REG-STAT dataset is loaded.');if(Object.keys(state.selected||{}).length)return toast('Finish, save or clear the active floor walk before removing REG-STAT. Your active work is preserved.');if(!confirm('Remove the saved REG-STAT product dataset? EAN aliases, corrected names, Mall Audit records, saved walks and completed History will remain.'))return;const old=state;try{state={...state,master:null,stockFile:'',importedAt:null};await persistRegRemoval();render();renderEanLibrary();toast('REG-STAT dataset removed; other saved data remains.')}catch(e){state=old;toast('REG-STAT was not removed: '+e.message)}}
async function exportEanLibrary(){const payload={format:'AUREM_EAN_LIBRARY_V1',exportedAt:new Date().toISOString(),sourceFile:eanLibrary.sourceFile||'',importedAt:eanLibrary.importedAt||null,aliases:structuredClone(eanLibrary.aliases||{}),conflicts:structuredClone(eanLibrary.conflicts||[])},blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),name='AUREM_EAN_LIBRARY_'+new Date().toISOString().slice(0,10)+'.json';if(window.AUREMNative?.saveFile){try{window.AUREMNative.saveFile(await blobToBase64(blob),name,'application/json');toast('Saving EAN Library backup…')}catch(e){eanNotice('Backup export failed: '+e.message,'error')}return}const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000)}
async function restoreEanLibrary(file){if(!file)return;try{if(file.size>25_000_000)throw Error('EAN backup is too large (limit 25 MB).');const text=await file.text(),data=JSON.parse(text);if(data?.format!=='AUREM_EAN_LIBRARY_V1'||!data.aliases||typeof data.aliases!=='object')throw Error('This is not a valid AUREM EAN Library backup.');const pairs=Object.entries(data.aliases).flatMap(([ean,codes])=>(Array.isArray(codes)?codes:[codes]).map(code=>({ean,code}))),merged=mergeEanPairs(eanLibrary,pairs);const old=eanLibrary,oldMaster=state.master?structuredClone(state.master):null;eanLibrary=merged.library;if(data.conflicts&&Array.isArray(data.conflicts))eanLibrary.conflicts=[...(eanLibrary.conflicts||[]),...data.conflicts];if(state.master)applyEanLibrary(state.master,eanLibrary);try{await persistLibraryAndMaster()}catch(e){eanLibrary=old;if(state.master)state.master=oldMaster;throw e}renderEanLibrary();eanNotice('Merged '+merged.added.toLocaleString('en-IN')+' new alias(es); existing mappings were retained.'+(merged.conflicts.length?' ('+merged.conflicts.length+' conflict(s) saved for review)':''),'good')}catch(e){eanNotice('EAN backup was not restored: '+e.message,'error')}finally{$('eanRestoreFile').value=''}}
function renderImport(){if(ready()){const m=state.master,map=m.mapping,details=map?'Header row '+map.headerRow+' · CODE='+map.code+' · ITEM NAME='+map.name+' · BAR CODE='+map.barcode+' · CLOSING QTY='+map.stock+' · MRP='+map.mrp+' · RETAIL='+map.retail+' · COST='+(map.cost||'not found')+' · SUPPLIER='+(map.supplier||'not found')+' · LAST PUR DATE='+(map.lastPurDate||'not found'):'Column mapping for this saved dataset is unavailable.';setMessage('importInfo','Loaded successfully · '+m.productCount.toLocaleString('en-IN')+' REG-STAT products · '+(state.stockFile||'saved dataset')+' · imported '+humanDate(state.importedAt)+'. '+details,'good')}else setMessage('importInfo','REG-STAT is not loaded. Import a valid stock report to enable product features.','warn');$('regDataStatus').textContent=ready()?'Loaded successfully · '+state.stockFile+' · '+state.master.productCount.toLocaleString('en-IN')+' products · '+humanDate(state.importedAt):'No REG-STAT dataset loaded.';$('eanLibraryStatus')&&renderEanLibrary();$('membershipInfo').textContent='CORE Focus: '+state.focus.length.toLocaleString('en-IN')+' · Permanent: '+state.permanent.length.toLocaleString('en-IN')+' · NON-CORE Focus: '+(state.nonCoreFocus||[]).length.toLocaleString('en-IN')+' · updated '+humanDate(state.monthlyAt)}
function renderRecent(){const codes=Object.keys(state.selected);$('recentCount').textContent=String(codes.length);

 $('recentItems').innerHTML=codes.length?codes.map(code=>{const c=state.selected[code],p=state.master.products[code];return `<div class="recent-item"><div><strong>${escape(c.name||p.name)}</strong><div class="subline">${escape(code)} · ${escape(c.size)} · ${escape(String(c.copies))} copy/copies</div></div><button data-edit="${escape(code)}">Edit</button></div>`}).join(''):'<p class="quiet">Nothing scanned yet.</p>';

}

function renderScan(){const yes=ready();$('scanGuard').classList.toggle('hidden',yes&&saveOK);if(!saveOK)setMessage('scanGuard','Offline storage is unavailable; do not use for a real floor walk. Open via localhost or HTTPS.','error');

 $('cameraBtn').disabled=!yes||state.walkStatus==='finished';$('barcodeInput').disabled=!yes;$('addBarcode').disabled=!yes||state.walkStatus==='finished';

 const issues=Object.values(state.issues),codes=Object.keys(state.selected);$('statScans').textContent=String(state.totalScans);$('statBoards').textContent=String(codes.length);$('statPending').textContent=String(issues.length);$('pendingBadge').textContent=String(issues.length);

 // Unknown barcodes are counted only; no Pending Review list or resolution requirement.

 $('pendingList').textContent='';

 renderRecent();editorControls();renderWalkInfo();

}

function allBoardChecks(){if(!ready())return'Import fresh stock and EAN reports first.';if(Object.keys(state.selected).some(code=>isNonCoreProduct(state.master.products[code])))return'NON-CORE product found in CORE board list. Remove it before printing.';if(!state.focus.length||!state.permanent.length)return'Import Focus and Permanent lists before PDF output.';if(!Object.keys(state.selected).length)return'Scan products first.';

 for(const it of selections()){if(!it.choice.name.trim())return`Empty name: ${it.product.code}`;if(!Number.isInteger(Number(it.choice.copies))||Number(it.choice.copies)<1||Number(it.choice.copies)>300)return`Invalid copies: ${it.product.code}`;

 if(it.format.error)return`Check MRP/SP for ${it.product.code}`;

 if(boardSvg(it.product,it.format,it.choice).overflow)return`Text cannot fit into two lines: ${it.product.code}`;

 }

 return null;

}

function selectedPages(){

 const all=planByPaper(selections(),state.printMode||'standard',Number(state.saverMargin)||0);

 return state.paperSelection&&state.paperSelection!=='ALL'?all.filter(p=>p.paper===state.paperSelection):all;

}

function renderWalkInfo(){

 $('floorWalkId').textContent=state.walkId||'Not started';

 $('floorWalkStatus').textContent=state.walkStatus==='finished'?'Finished — ready for sending. Changes require reopening the walk.':'In progress — scans are automatically saved on this device.';

 $('finishWalk').disabled=!ready()||state.walkStatus==='finished';

 $('saveWalk').disabled=!ready();

}

async function saveWalk(){

 if(!ready())return toast('Import your reports first.');

 if(state.walkStatus==='finished')state.walkId='FW-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);

 state.walkStatus='in-progress';

 try{await save();renderScan();toast('Floor walk saved locally. You can resume scanning.');}catch(e){toast('Save failed: '+e.message)}

}

async function chooseUnfinishedWalk(){const d=$('walkDecisionDialog');if(!d)return confirm('Save current unfinished walk before starting a new one? OK=Save, Cancel=Discard')?'save':'discard';return new Promise(resolve=>{const done=v=>{d.close();resolve(v)};d.querySelector('[data-walk-choice="save"]').onclick=()=>done('save');d.querySelector('[data-walk-choice="discard"]').onclick=()=>done('discard');d.querySelector('[data-walk-choice="cancel"]').onclick=()=>done('cancel');d.showModal()})}

async function clearCoreWalk(){if(!confirm('Clear products from this CORE floor walk? Imported stock, corrected names, audit records, custom boards, settings, and history will remain.'))return;state.selected={};state.issues={};state.overrides={};state.totalScans=0;state.duplicates=0;state.walkId='CORE-'+Date.now().toString(36);state.walkStatus='in-progress';editorCode=null;await save();renderScan();toast('Current CORE floor walk cleared.')}
async function startCoreWalk(){const has=Object.keys(state.selected||{}).length>0;if(has){const choice=await chooseUnfinishedWalk();if(choice==='cancel')return;if(choice==='save'){try{await archiveCoreWalk('saved')}catch(e){return toast('Could not save this unfinished walk: '+e.message)}}}else if(!confirm('Start a new CORE floor walk?'))return;state.selected={};state.issues={};state.overrides={};state.totalScans=0;state.duplicates=0;state.walkId='CORE-'+Date.now().toString(36);state.walkStatus='in-progress';editorCode=null;await save();renderScan();toast('New CORE floor walk started.')}
async function finishWalk(){const problem=allBoardChecks();if(problem){setMessage('finishNotice',problem,'error');return toast(problem)}const prev=structuredClone(state);try{await archiveCoreWalk('completed');state.selected={};state.issues={};state.overrides={};state.totalScans=0;state.duplicates=0;state.walkId='CORE-'+Date.now().toString(36);state.walkStatus='in-progress';editorCode=null;await save();renderScan();renderBoards();setMessage('finishNotice','Floor walk archived to HISTORY. A new empty walk is ready.','good');toast('Floor walk saved to HISTORY.')}catch(e){state=prev;renderScan();renderBoards();toast('History save failed; the active floor walk is still available. '+e.message)}}

function transferPayload(){

 const prices={},sourcePrices={};for(const code of Object.keys(state.selected)){const p=selectedProduct(code),f=boardFormat(p,new Set(state.permanent),new Set(state.focus));prices[code]={mrp:p.mrp,retail:p.retail,focus:f.focus,permanent:f.permanent};const raw=state.master.products[code];sourcePrices[code]={mrp:raw.mrp,retail:raw.retail};}

 return{sessionId:state.walkId,deviceId:getMobileId(),sentAt:new Date().toISOString(),stockFile:state.stockFile,eanFile:state.eanFile,importedAt:state.importedAt,monthlyFile:state.monthlyFile,monthlyAt:state.monthlyAt,pendingCount:Object.keys(state.issues).length,selected:structuredClone(state.selected),prices,sourcePrices};

}

function getMobileId(){let id=localStorage.getItem('aurem-mobile-id');if(!id){id='MOB-'+Math.random().toString(36).slice(2,13).toUpperCase();localStorage.setItem('aurem-mobile-id',id)}return id}

function pairingFromUrl(text){

 try{const u=new URL(text);if(!/^https?:$/.test(u.protocol)||!u.searchParams.get('pair')||!u.searchParams.get('pc'))throw Error('Not a valid AUREM pairing URL');

 return{base:u.origin,token:u.searchParams.get('pair'),id:u.searchParams.get('pc')};}catch{throw Error('Scan the PC QR code using your phone camera, or paste the full pairing link.');}

}

async function applyPair(text){

 const p=pairingFromUrl(text);

 const r=await fetch(p.base+'/api/status',{cache:'no-store'});

 if(!r.ok)throw Error('PC service could not be reached. Confirm both devices use the same Wi-Fi.');

 const st=await r.json();if(st.server!=='AUREM_PC_V3'||st.pcId!==p.id)throw Error('Pairing QR does not match the receiving PC.');

 state.pairedPc=p;await save();renderLink();toast('Paired to '+p.id);return p;

}

function renderLink(){if(!$('linkStatus'))return;

 $('linkStatus').textContent=state.pairedPc?`Connected to ${state.pairedPc.id} — ready when this walk is finished`:location.protocol==='file:'?'QR pairing is not available in the standalone file. Open AUREM PC using START_AUREM_PC_WINDOWS.bat first.':'Not paired yet — scan the QR on AUREM PC with your phone Camera app.';

 $('linkStatus').className='notice '+(state.pairedPc?'good':'warn');

 $('sendPc').disabled=state.walkStatus!=='finished'||!state.pairedPc;

 $('pcSide').classList.toggle('hidden',!localPc);

}

async function sendPc(){

 const problem=allBoardChecks();if(problem)return toast(problem);

 if(state.walkStatus!=='finished')return toast('Finish Floor Walk first.');

 if(!state.pairedPc)return toast('Pair your mobile with AUREM PC first.');

 const btn=$('sendPc');btn.disabled=true;btn.textContent='Sending over Wi-Fi…';

 try{

  const payload={...transferPayload(),pairToken:state.pairedPc.token};

  const res=await fetch(state.pairedPc.base+'/api/receive',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});

  const out=await res.json();if(!res.ok)throw Error(out.error||'PC refused transfer');

  setMessage('transferNotice',out.status==='duplicate'?`PC already has floor walk ${out.sessionId}. No duplicate created.`:`PC ${out.pcId} acknowledged floor walk ${out.sessionId}. Open AUREM PC inbox.`, 'good');

  toast('PC received your floor walk.');

 }catch(e){setMessage('transferNotice','Transfer failed; floor walk stays saved on mobile. '+e.message,'error');toast('Send failed: '+e.message)}

 finally{btn.textContent='Send to PC →';renderLink()}

}

async function setupPcReceiver(){

 try{const r=await fetch('/api/status',{cache:'no-store'});if(!r.ok)return;const ob=await r.json();if(ob.server!=='AUREM_PC_V3')return;

  pcService=true;localPc=!!ob.local;

  if(localPc){

   const pair=await(await fetch('/api/pairing',{cache:'no-store'})).json();

   $('pcIdText').textContent=`PC device ID: ${pair.pcId} · Scan QR with phone camera to connect automatically`;window.auremPairLink=pair.pairUrl;

   $('pairQr').innerHTML=pair.qr?`<img src="${pair.qr}" alt="Scan this QR with your phone camera to pair AUREM" width="225" height="225">`:'<p class="quiet">QR could not be generated; use the manual pairing link below.</p>';

   refreshInbox();

  }

  if(location.search.includes('pair=')){

   try{const here=new URL(location.href);await applyPair(here.href);history.replaceState(null,'',here.pathname);}catch(e){setMessage('transferNotice',e.message,'error')}

  }

  renderLink();

 }catch(e){renderLink()}

}

async function refreshInbox(){

 if(!localPc)return;

 try{const r=await fetch('/api/inbox',{cache:'no-store'});const data=await r.json();$('pcInbox').innerHTML=data.sessions.length?data.sessions.map(x=>`<div class="board-item"><div><strong>${escape(x.id)}</strong><div class="subline">${escape(x.deviceId)} · ${x.products} products · ${escape(x.receivedAt||'')}</div></div><button data-inbox="${escape(x.id)}">Load for review</button></div>`).join(''):'<p class="quiet">No received floor walks yet.</p>'}catch(e){toast('PC inbox unavailable: '+e.message)}

}

async function loadReceivedSession(incoming){

  if(incoming.kind==='noncore'){if(typeof window.auremLoadNonCoreSession!=='function')throw Error('Non-Core receiver unavailable');await window.auremLoadNonCoreSession(incoming);return;}

  if(!ready())throw Error('Import fresh REG-STAT and ITEM_EANS on the PC before loading the received walk.');

  if(state.stockFile!==incoming.stockFile||state.eanFile!==incoming.eanFile)throw Error('PC report file names differ from mobile snapshot; import matching fresh files.');

  if(!incoming.sourcePrices)throw Error('Received session lacks its unmodified stock-price snapshot.');

  if(!Array.isArray(state.focus)||!state.focus.length||!state.permanent.length)throw Error('Load valid Focus/Permanent lists on PC first.');

  const changes=[];

  for(const[code,snap]of Object.entries(incoming.prices||{})){

   const base=state.master.products[code];if(!base){changes.push(`${code} missing`);continue;}

   const raw=incoming.sourcePrices[code];if(!raw||parseMoneyCents(base.mrp)!==parseMoneyCents(raw.mrp)||parseMoneyCents(base.retail)!==parseMoneyCents(raw.retail))changes.push(`${code} fresh-stock price mismatch`);

   const ch=incoming.selected[code];const mrp=ch.mrpOverride||base.mrp,retail=ch.spOverride||base.retail;

   if(parseMoneyCents(mrp)!==parseMoneyCents(snap.mrp)||parseMoneyCents(retail)!==parseMoneyCents(snap.retail))changes.push(`${code} price mismatch`);

   if(state.focus.includes(code)!==snap.focus||state.permanent.includes(code)!==snap.permanent)changes.push(`${code} Focus/Permanent mismatch`);

  }

  if(changes.length)throw Error('PC validation blocked: '+changes.slice(0,4).join('; ')+(changes.length>4?` +${changes.length-4} more`:''));

  if(Object.keys(incoming.selected||{}).length!==Object.keys(incoming.prices||{}).length)throw Error('Incomplete transferred price snapshot.');

  if(Object.keys(incoming.selected||{}).some(code=>isNonCoreProduct(state.master.products[code])))throw Error('Received CORE session contains NON-CORE product(s); transfer blocked.');

  if(!confirm(`Load received floor walk ${incoming.sessionId} (${Object.keys(incoming.selected).length} products)? Current active PC scan selections will be replaced.`))return;

  state.selected=incoming.selected;state.walkId=incoming.sessionId;state.walkStatus='finished';state.issues={};state.totalScans=Object.keys(state.selected).length;

  await save();previewPage=0;selectTab('boards');render();setMessage('transferNotice',`Received floor walk ${incoming.sessionId} loaded and prices cross-checked. Check A4 previews before printing.`,'good');



}

async function loadInbox(id){

 if(!localPc)return toast('Open on PC to load received sessions.');

 try{const res=await fetch('/api/inbox/'+encodeURIComponent(id),{cache:'no-store'});const incoming=await res.json();await loadReceivedSession(incoming);

 }catch(e){setMessage('transferNotice','Unable to load: '+e.message,'error');toast(e.message)}

}

async function exportWalk(){

 if(!ready()||!Object.keys(state.selected).length)return toast('Scan products before exporting a floor walk.');

 if(state.walkStatus!=='finished')return toast('Finish Floor Walk before exporting.');

 const ob=transferPayload(),blob=new Blob([JSON.stringify(ob,null,2)],{type:'application/json'}),fileName=`AUREM_${ob.sessionId}.json`;

 if(window.AUREMNative?.saveFile){

  try{const base64=await blobToBase64(blob);window.AUREMNative.saveFile(base64,fileName,'application/json');toast('Saving session to Downloads/AUREM…');}catch(e){toast('Export failed: '+e.message)}

  return;

 }

 const u=URL.createObjectURL(blob),link=document.createElement('a');

 link.href=u;link.download=fileName;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(u),8000);toast('Floor-walk backup exported.');

}

async function importWalkFile(file){

 if(!file)return;

 try{if(file.size>2000000)throw Error('Session file is too large.');

 const incoming=JSON.parse(await file.text());

 if(!/^FW-[a-zA-Z0-9-]{6,70}$/.test(incoming.sessionId||''))throw Error('Not an AUREM session');

 if(!incoming.prices||!incoming.sourcePrices||!incoming.selected)throw Error('Incomplete session or unresolved unknown scans.');

 await loadReceivedSession(incoming);

 }catch(e){setMessage('transferNotice','Offline import failed: '+e.message,'error');toast(e.message)}

}



// Added Core helpers: never overwrite the user-approved SVG or price algorithms.

function focusCounts(){

 const list=[...new Set((state.focus||[]).map(normalizeBansal))];

 const found=list.filter(code=>!!state.master?.products?.[code]);

 return{total:list.length,found,missing:list.filter(code=>!state.master?.products?.[code]),newCodes:found.filter(code=>!state.selected[code])};

}

async function addAllFocus(){

 if(!ready()||!state.focus.length||!state.permanent.length)return toast('Import fresh stock/EAN and Focus/Permanent lists first.');

 if(state.walkStatus==='finished')return toast('Click Save Floor Walk in Scan to reopen editing.');

 const c=focusCounts();if(!c.newCodes.length)return toast(c.missing.length?`${c.missing.length} Focus CODEs missing from stock; nothing new added.`:'All available Focus products are already on Boards.');

 const eligible=c.newCodes.filter(code=>!isNonCoreProduct(state.master.products[code]));if(!eligible.length)return toast('No CORE Focus products remain after REG-STAT MAIN CODE classification.');for(const code of eligible)state.selected[code]=initialChoice(code);

 try{await save();previewPage=0;renderScan();renderBoards();setMessage('focusBulkNotice',`Added ${eligible.length} Focus boards; ${c.found.length-c.newCodes.length} already present; ${c.missing.length} CODEs absent from stock${c.missing.length?': '+c.missing.slice(0,15).join(', ')+(c.missing.length>15?' …':''):''}. Check/edit all names and sizes before printing.`,c.missing.length?'warn':'good');toast(`${eligible.length} CORE Focus boards added. Review before printing.`)}

 catch(e){toast('Could not save Focus list: '+e.message)}

}

function renderCoreBoardMatches(){const root=$('quickBoardMatches'),q=$('quickBoardSearch').value.trim().toLocaleLowerCase();if(!q){root.innerHTML='';$('quickBoardForm').classList.toggle('hidden',!quickEditCode);return;}const matches=Object.keys(state.selected).filter(code=>{const p=state.master.products[code];const c=state.selected[code];return p&&!isNonCoreProduct(p)&&productMatches(state.master,code,q,[c.name,verifiedName(code,p.name)]);}).slice(0,30);root.innerHTML=matches.length?matches.map(code=>`<button type="button" class="product-search-result" role="option" data-quick="${escape(code)}"><strong>${escape(state.selected[code].name)}</strong><span>Bansal CODE ${escape(code)} · ${escape(state.selected[code].size)} · ${escape(String(state.selected[code].copies))} copies</span></button>`).join(''):'<p class="quiet">No added CORE boards match that search.</p>';}
function openBoardQuickEdit(code){if(!ready()||!state.selected[code])return;if(state.walkStatus==='finished')return toast('Click Save Floor Walk in Scan to reopen editing.');quickEditCode=code;const c=state.selected[code];$('quickEditTitle').textContent='Quick edit · '+code;$('quickName').value=c.name;$('quickSize').value=c.size;$('quickCopies').value=c.copies;$('quickQty').value=c.qty||'';$('quickUnit').value=['KG','G','LTR','ML','NOS'].includes(c.unit)?c.unit:'';$('quickBoardForm').classList.remove('hidden');renderCoreBoardMatches();$('quickBoardForm').scrollIntoView({behavior:'smooth',block:'nearest'});}
async function saveBoardQuickEdit(){const code=quickEditCode;if(!code||!state.selected[code]||!ready())return;if(state.walkStatus==='finished')return toast('Reopen the floor walk before editing.');const name=$('quickName').value.trim().replace(/\s+/g,' '),qty=$('quickQty').value.trim(),unit=$('quickUnit').value,size=$('quickSize').value,copies=Number($('quickCopies').value);if(!name)return toast('Board name cannot be empty.');if(qty&&(!/^\d+(?:\.\d+)?$/.test(qty)||Number(qty)<=0))return toast('Enter a positive total quantity.');if(!['1/20','1/9','1/8','1/4','1/3','1/2','1/1'].includes(size))return toast('Select a valid board size.');if(!Number.isInteger(copies)||copies<1||copies>300)return toast('Copies must be a whole number between 1 and 300.');const choice={...state.selected[code],name,qty,unit,size,copies},product={...selectedProduct(code),name};const fmt=boardFormat(product,new Set(state.permanent),new Set(state.focus));if(!fmt.error&&boardSvg(product,fmt,choice).overflow)return toast('Name does not fit the original board. Shorten the name; nothing changed.');state.selected[code]=choice;if(name!==state.master.products[code].name)state.nameOverrides[code]=name;else delete state.nameOverrides[code];try{await saveVerified(code,{name,qty,unit,kind:'core'});await save();quickEditCode=null;$('quickBoardForm').classList.add('hidden');renderScan();renderBoards();toast('Board name, size, copies and quantity saved.')}catch(e){toast('Save failed: '+e.message)}}
function printHistoryJob(pages){

 const ids=new Set();for(const page of pages)for(const it of page.items)ids.add(it.product.code);

 const items=selections().filter(it=>ids.has(it.product.code));

 return{id:'PRINT-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8),createdAt:Date.now(),paper:state.paperSelection||'ALL',mode:state.printMode||'standard',margin:Number(state.saverMargin)||0,pages:pages.length,boards:items.map(it=>({code:it.product.code,name:it.choice.name,choice:structuredClone(it.choice),mrp:it.product.mrp,retail:it.product.retail,focus:it.format.focus,permanent:it.format.permanent}))};

}

async function recordPrintJob(pages){

 const record=printHistoryJob(pages);if(!record.boards.length)return;

 state.printHistory=[record,...(state.printHistory||[])].slice(0,200);

 try{await saveHistory();renderPrintHistory()}catch(e){setMessage('historyNotice','Print dialog opened, but local print-history save FAILED: '+e.message,'error')}

}

function renderPrintHistory(){

 const list=state.printHistory||[];

 $('historyCount').textContent=list.length+' jobs';

 $('historyList').innerHTML=list.length?list.map(x=>`<div class="history-item"><strong>${escape(humanDate(x.createdAt))}</strong><div class="subline">${escape(x.paper)} · ${escape(x.mode)} · ${escape(String(x.pages))} A4 sheet(s) · ${escape(String(x.boards?.length||0))} unique boards · print dialog opened</div><button data-reuse-history="${escape(x.id)}">Load full job using latest prices</button><details class="correction"><summary>Reprint just ONE board from this job</summary><label class="field">Choose old board<select data-history-product="${escape(x.id)}">${(x.boards||[]).map(it=>`<option value="${escape(it.code)}">${escape(it.name)} · ${escape(it.code)} · ${escape(it.choice.size)}</option>`).join('')}</select></label><button data-reuse-one="${escape(x.id)}">Load selected board using latest prices</button></details></div>`).join(''):'<p class="quiet">No print history yet.</p>';

}

async function reusePrintJob(id,onlyCode=null){

 const job=(state.printHistory||[]).find(x=>x.id===id);if(!job)return toast('History record not found.');

 if(!ready()||!state.focus.length||!state.permanent.length)return toast('Import fresh stock, EAN and Focus/Permanent lists to validate historic boards.');

 const existing=(job.boards||[]).filter(x=>!onlyCode||x.code===onlyCode),available=existing.filter(x=>!!state.master.products[x.code]),missing=existing.filter(x=>!state.master.products[x.code]);

 if(!available.length)return toast('None of these historic products exists in the current stock file.');

 const changed=available.filter(x=>{const p=state.master.products[x.code];return parseMoneyCents(p.mrp)!==parseMoneyCents(x.mrp)||parseMoneyCents(p.retail)!==parseMoneyCents(x.retail)||state.focus.includes(x.code)!==x.focus||state.permanent.includes(x.code)!==x.permanent;});

 const msg=`Load ${available.length} historic boards and REPLACE the ${Object.keys(state.selected).length} boards currently selected? Existing scans are not preserved by this action. Latest imported stock prices and current Focus/Permanent membership will be used, never the historic prices or old manual price overrides.${changed.length?' '+changed.length+' item(s) have price or Focus/Permanent changes and will be recalculated.':''}${missing.length?' '+missing.length+' CODE(s) missing from the latest stock report and cannot be restored: '+missing.slice(0,15).map(x=>x.code).join(', ')+(missing.length>15?' …':''):''} Continue?`;

 if(!confirm(msg))return;

 const next={};for(const item of available){const p=state.master.products[item.code];const c={...initialChoice(item.code),...structuredClone(item.choice),mrpOverride:'',spOverride:''};if(!c.name?.trim())c.name=p.name;next[item.code]=c;}

 state.selected=next;state.issues={};state.totalScans=available.length;state.duplicates=0;state.walkStatus='in-progress';state.walkId='FW-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);

 state.printMode=job.mode==='saver'?'saver':'standard';state.saverMargin=[0,1,2,3].includes(job.margin)?job.margin:0;state.paperSelection=['WHITE','YELLOW','ALL'].includes(job.paper)?job.paper:'ALL';

 for(const item of available){const name=next[item.code].name;if(name!==state.master.products[item.code].name)state.nameOverrides[item.code]=name;else delete state.nameOverrides[item.code]}

 try{await save();previewPage=0;quickEditCode=null;$('boardQuickEdit').classList.add('hidden');document.querySelectorAll('input[name=printMode]').forEach(x=>x.checked=x.value===state.printMode);document.querySelectorAll('input[name=paperSelection]').forEach(x=>x.checked=x.value===state.paperSelection);$('marginGroup').classList.toggle('hidden',state.printMode!=='saver');$('saverMargin').value=String(state.saverMargin);render();selectTab('boards');setMessage('historyNotice',`Loaded ${available.length} boards with CURRENT prices/membership. ${changed.length} record(s) changed; ${missing.length} missing. Review names, offers and page previews before printing.`,missing.length||changed.length?'warn':'good');toast('Historic boards restored using latest prices.');}

 catch(e){toast('Could not save restored boards: '+e.message)}

}



function renderBoards(){const codes=Object.keys(state.selected),valid=ready();const f=focusCounts();$('focusBulkCount').textContent=`${f.found.length} available`; $('addAllFocus').disabled=!valid||!state.focus.length||!state.permanent.length||state.walkStatus==='finished';renderPrintHistory();$('selectedCount').textContent=String(codes.length);renderCoreBoardMatches();$('boardGuard').classList.toggle('hidden',valid&&codes.length>0);

 $('boardList').innerHTML=!valid||!codes.length?'<p class="quiet">No boards yet. Scan a product first.</p>':selections().filter(it=>{const q=($('coreBoardSearch')?.value||'').trim().toLowerCase();return !q||it.product.code.toLowerCase().includes(q)||it.choice.name.toLowerCase().includes(q)}).map(it=>`<div class="board-item"><div><strong>${escape(it.choice.name)}</strong><div class="board-label">${escape(it.product.code)} · MRP ₹${escape(it.product.mrp)} · SP ₹${escape(it.product.retail)}</div><span class="board-pill">${escape(it.format.format)} · ${escape(it.choice.size)}${it.choice.size==='1/20'?' '+(it.choice.style20==='mahir'&&['B1G1','B1G2'].includes(it.format.format)?'Mahir’s Style':'Standard'):''} · ${escape(String(it.choice.copies))} copies</span></div><div class="board-actions"><button data-quick="${escape(it.product.code)}" ${historyReturnState?'hidden':''}>Quick edit</button><button data-jump="${escape(it.product.code)}" ${historyReturnState?'hidden':''}>Edit in Scan</button><button data-delete="${escape(it.product.code)}" ${historyReturnState?'hidden':''}>Delete board</button></div></div>`).join('');

 const problem=allBoardChecks();$('downloadTestPdf').disabled=!!problem;$('printReview').disabled=!!problem;setMessage('pdfWarning',problem||'Check the final page preview, printed scale and correct paper colour before printing.',problem?'error':'good');

 if(!valid||!codes.length){$('boardPreview').innerHTML='<p class="quiet">A4 preview will appear here.</p>';$('previewPosition').textContent='0 / 0';$('previewProduct').textContent='';$('previousBoard').disabled=true;$('nextBoard').disabled=true;return;}

 try{

  const pages=selectedPages();if(!pages.length){'boardPreview';$('boardPreview').innerHTML='<p class="quiet">No boards in this paper group.</p>';$('previewPosition').textContent='0 / 0';$('previewProduct').textContent='No products in the chosen paper group.';$('previousBoard').disabled=true;$('nextBoard').disabled=true;return;}if(previewCode){const idx=pages.findIndex(p=>p.items.some(i=>i.product.code===previewCode));if(idx>=0)previewPage=idx;previewCode=null;}previewPage=Math.max(0,Math.min(previewPage,pages.length-1));const page=pages[previewPage];$('boardPreview').innerHTML=a4Svg(page,{watermark:false});$('previewPosition').textContent=`${previewPage+1} / ${pages.length}`;

  $('previewProduct').textContent=`${page.paper} paper · ${page.mode==='saver'?'Page Saver experimental':page.size+' Standard'} · ${page.items.length} physical boards on this sheet · never scaled or rotated`;

  $('previousBoard').disabled=previewPage===0;$('nextBoard').disabled=previewPage===pages.length-1;

  setMessage('previewWarning',problem?`REVIEW: ${problem}`:'Preview is ready. Confirm lettering and physical print size before printing.',problem?'warn':'good');

 }catch(e){setMessage('previewWarning','Layout cannot be generated: '+e.message,'error')}

}

async function shareWhatsApp(){const problem=allBoardChecks();if(problem)return toast(problem);const b=$('shareWhatsAppBtn');if(b)b.disabled=true;
 try{const pages=selectedPages();if(!pages.length)throw Error("No boards in this paper group");toast("Generating PDF for WhatsApp…");const blob=await makeTestPDF(selections(),()=>{},pages);const fileName="AUREM_"+(state.paperSelection||"ALL")+"_BOARDS.pdf";if(window.AUREMNative?.sharePdf){const base64=await blobToBase64(blob);window.AUREMNative.sharePdf(base64,fileName,"whatsapp");toast("Opening WhatsApp with PDF…");}else{toast("WhatsApp sharing is active in the installed Android app.");await downloadPdf();}}catch(e){toast("WhatsApp share failed: "+e.message)}finally{if(b)b.disabled=false}
}

async function downloadPdf(){const problem=allBoardChecks();if(problem)return toast(problem);const b=$('downloadTestPdf');b.disabled=true;b.textContent='Generating PDF…';

 try{const pages=selectedPages();if(!pages.length)throw Error('No boards in this paper group');const pdfStarted=performance.now();let pipeline=null;const blob=await makeTestPDF(selections(),(cur,n,metrics)=>{pipeline=metrics||pipeline;b.textContent=metrics?.stage==='complete'?`Preparing ${((metrics.bytes||0)/1048576).toFixed(1)} MB…`:`Page ${cur} of ${n}…`},pages);b.textContent=`PDF ready · ${blob.size.toLocaleString()} bytes · ${((performance.now()-pdfStarted)/1000).toFixed(1)}s`;if(pipeline)console.info('AUREM PDF stage timings',pipeline);

  const fileName='AUREM_'+(state.paperSelection||'ALL')+'_BOARDS.pdf';

  if(window.AUREMNative?.saveFile){

   const base64=await blobToBase64(blob);

   window.AUREMNative.saveFile(base64,fileName,'application/pdf');

   toast('Saving PDF to Downloads/AUREM…');

  }else{

   const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=fileName;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),8000);toast('AUREM PDF saved.');

  }

 }catch(e){toast('PDF failed: '+e.message)}finally{b.disabled=false;b.textContent='Save PDF (optional) ↓'}

}

async function printPreview(){

 const problem=allBoardChecks();if(problem)return toast(problem);

 const pages=selectedPages();if(!pages.length)return toast('No boards selected for this paper group.');

 if(state.paperSelection==='ALL'&&pages.some(p=>p.paper==='YELLOW')&&pages.some(p=>p.paper==='WHITE'))return toast('Select WHITE or YELLOW paper before printing. Do not mix paper colors.');

 if(window.AUREMNative?.printPdf){

  try{

   toast('Preparing print layout…');

   const blob=await makeTestPDF(selections(),()=>{},pages);

   const base64=await blobToBase64(blob);

   window.AUREMNative.printPdf(base64,'AUREM BOARDS ('+(state.paperSelection||'ALL')+')');

   await recordPrintJob(pages);

  }catch(e){toast('Print setup failed: '+e.message)}

  return;

 }

 const w=window.open('','_blank');if(!w)return toast('Allow popups for the Windows print dialog.');

 try{

  const css=`@page auremPortrait { size: A4 portrait; margin:0; } @page auremLandscape { size: A4 landscape; margin:0; } body{margin:0;} .sheet{break-after:page;page-break-after:always;} .sheet.portrait{page:auremPortrait;width:210mm;height:297mm;} .sheet.landscape{page:auremLandscape;width:297mm;height:210mm;} .sheet svg{width:100%;height:100%;display:block;} .sheet:last-child{break-after:auto;}`;

  w.document.open();w.document.write(`<html><head><title>AUREM — PRINT BOARDS</title><style>${css}</style></head><body>${pages.map(p=>`<div class="sheet ${p.portrait?'portrait':'landscape'}">${a4Svg(p,{watermark:false})}</div>`).join('')}</body></html>`);w.document.close();w.focus();setTimeout(()=>w.print(),650);await recordPrintJob(pages);

 }catch(e){w.close();toast('Print setup failed: '+e.message)}

}



function stopCamera(){cameraActive=false;cameraHold=false;if(stream){for(const t of stream.getTracks())t.stop();stream=null}closeSharedScanner();$('cameraBtn').textContent='Scan'}async function camera(){if(sharedScannerStream){closeSharedScanner();$('cameraBtn').textContent='Scan';return}if(!ready())return toast('Import files first');cameraActive=true;$('cameraBtn').textContent='Close Scan';scannerStatus('Looking for barcode…');try{await window.auremStartBarcodeScan(raw=>{cameraActive=false;$('cameraBtn').textContent='Scan';findScan(raw,true)})}catch(e){stopCamera();toast(e.message)}}
function setTheme(t){state.theme=t==='light'?'light':'dark';document.body.dataset.theme=state.theme;$('themeText').textContent=state.theme==='dark'?'Light':'Dark';$('themeIcon').textContent=state.theme==='dark'?'☼':'☾';save().catch(()=>{})}

function render(){renderImport();renderScan();renderBoards();if($('historyPage')&&!$('historyPage').classList.contains('hidden'))renderWalkHistory()}



function setAppMode(targetMode){

 const modeButtons={

  core:$('switchCore'),

  noncore:$('switchNonCore'),

  import:$('switchImport'),

  stock:$('switchStock'),

  audit:$('switchAudit'),
  history:$('switchHistory'),

 };
 for(const [k,btn] of Object.entries(modeButtons)){

  if(btn)btn.classList.toggle('active',k===targetMode);

 }

 const corePages=document.querySelectorAll('.page');

 const coreNav=$('coreNav');

 const ncMount=$('noncoreMount');

 const invMount=$('inventoryMount');



 if(targetMode==='history'){corePages.forEach(p=>p.classList.add('hidden'));if(coreNav)coreNav.classList.add('hidden');if(ncMount)ncMount.classList.add('hidden');if(invMount)invMount.classList.add('hidden');stopCamera();window.auremStopNCamera?.();$('historyPage').classList.remove('hidden');document.querySelectorAll('.mode-tabs button').forEach(b=>b.classList.toggle('active',b.id==='switchHistory'));renderWalkHistory();return;}else{$('historyPage')?.classList.add('hidden')}
 if(targetMode==='core'){

  if(ncMount)ncMount.classList.add('hidden');

  if(invMount)invMount.classList.add('hidden');

  if(coreNav)coreNav.classList.remove('hidden');

  window.auremStopNCamera?.();

  const curActive=document.querySelector('#coreNav [data-tab].active')?.dataset.tab;

  const tabToOpen=(curActive&&curActive!=='import'&&curActive!=='history')?curActive:'scan';

  selectTab(tabToOpen);

 }else if(targetMode==='import'){

  if(ncMount)ncMount.classList.add('hidden');

  if(invMount)invMount.classList.add('hidden');

  if(coreNav)coreNav.classList.remove('hidden');

  window.auremStopNCamera?.();

  selectTab('import');

 }else if(targetMode==='noncore'){

  corePages.forEach(p=>p.classList.add('hidden'));

  if(coreNav)coreNav.classList.add('hidden');

  if(invMount)invMount.classList.add('hidden');

  stopCamera();

  if(ncMount){

   ncMount.classList.remove('hidden');

   window.auremRenderNonCore?.();

  }

 }else if(targetMode==='stock'||targetMode==='audit'){

  corePages.forEach(p=>p.classList.add('hidden'));

  if(coreNav)coreNav.classList.add('hidden');

  if(ncMount)ncMount.classList.add('hidden');

  stopCamera();

  window.auremStopNCamera?.();

  if(invMount){

   invMount.classList.remove('hidden');

   window.auremSetInventoryMode?.(targetMode);

  }

 }

}

window.auremSetAppMode=setAppMode;



function connect(){document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>selectTab(b.dataset.tab)));

 $('switchCore')?.addEventListener('click',()=>setAppMode('core'));$('switchNonCore')?.addEventListener('click',()=>setAppMode('noncore'));$('switchImport')?.addEventListener('click',()=>setAppMode('import'));$('switchStock')?.addEventListener('click',()=>setAppMode('stock'));$('switchAudit')?.addEventListener('click',()=>setAppMode('audit'));$('switchHistory')?.addEventListener('click',()=>{if(historyReturnState)closeFloorHistory();setAppMode('history');renderWalkHistory()});

 window.auremChooseUnfinishedWalk=chooseUnfinishedWalk;
 $('floorWalkHistoryList')?.addEventListener('click',e=>{const b=e.target.closest('[data-open-floor-history]');if(b)openFloorHistory(Number(b.dataset.openFloorHistory)).catch(x=>toast('History open failed: '+x.message))});$('historyViewClose')?.addEventListener('click',closeFloorHistory);
 $('sharedScannerClose')?.addEventListener('click',closeSharedScanner);$('sharedScannerDialog')?.addEventListener('cancel',e=>{e.preventDefault();closeSharedScanner()});$('themeToggle').addEventListener('click',()=>setTheme(state.theme==='dark'?'light':'dark'));

 $('importBoth').addEventListener('click',importReports);for(const id of ['regFile','eanFile','monthlyFile','focusFile','permanentFile','nonCoreFocusFile'])$(id).addEventListener('change',()=>updateSelectedFileName(id));$('addBarcode').addEventListener('click',()=>findScan($('barcodeInput').value));$('barcodeInput').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();findScan(e.currentTarget.value)}});$('cameraBtn').addEventListener('click',camera);$('removeRegDataset').addEventListener('click',removeRegDataset);$('removeEanDataset').addEventListener('click',removeEanAliases);$('eanProductSearch').addEventListener('input',()=>renderEanProductMatches());$('eanProductCode').addEventListener('input',renderEanLibrary);$('eanProductResults').addEventListener('click',e=>{const b=e.target.closest('[data-ean-code]');if(b)selectEanProduct(b.dataset.eanCode)});$('eanAddMapping').addEventListener('click',()=>addEanAlias());$('eanAliasInput').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();addEanAlias()}});$('eanScanButton').addEventListener('click',()=>window.auremOpenScanner?.(raw=>{$('eanAliasInput').value=raw;eanNotice('Scanned barcode '+raw+'. Confirm the Bansal CODE before saving.','good')},'barcode').catch(e=>eanNotice('Scanner could not open: '+e.message,'error')));$('eanExport').addEventListener('click',exportEanLibrary);$('eanRestoreFile').addEventListener('change',e=>restoreEanLibrary(e.target.files?.[0]));

 $('pendingList').addEventListener('click',e=>{const b=e.target.closest('[data-resolve]');if(!b)return;const inp=[...$('pendingList').querySelectorAll('[data-code-for]')].find(x=>x.dataset.codeFor===b.dataset.resolve);resolveIssue(b.dataset.resolve,inp?.value||'')});

 $('recentItems').addEventListener('click',e=>{const b=e.target.closest('[data-edit]');if(!b)return;editorCode=b.dataset.edit;editorControls();$('scanEditor').scrollIntoView({behavior:'smooth',block:'start'})});

 for(const id of ['editName','editSize','editStyle20','editCopies','editQty','editUnit','editMrp','editSp'])$(id).addEventListener('input',draftEditor);
 attachAutoUppercase($('editName'));
 attachAutoUppercase($('coreProductSearch'));
 attachAutoUppercase($('quickName'));
 attachAutoUppercase($('eanProductSearch'));

 $('saveEdit').addEventListener('click',saveEdit);$('resetBoardName').addEventListener('click',resetName);

 $('coreBoardSearch')?.addEventListener('input',renderBoards);let coreNameSearchTimer;$('coreProductSearch').addEventListener('input',()=>{clearTimeout(coreNameSearchTimer);coreNameSearchTimer=setTimeout(renderCoreProductMatches,90)});$('coreProductResults').addEventListener('click',e=>{const b=e.target.closest('[data-core-product]');if(b)selectCoreProductByName(b.dataset.coreProduct)});$('quickBoardSearch').addEventListener('input',()=>{quickEditCode=null;$('quickBoardForm').classList.add('hidden');renderCoreBoardMatches()});$('quickBoardMatches').addEventListener('click',e=>{const b=e.target.closest('[data-quick]');if(b)openBoardQuickEdit(b.dataset.quick)});$('boardList').addEventListener('click',e=>{const del=e.target.closest('[data-delete]');if(del){const code=del.dataset.delete,name=state.selected[code]?.name||state.master?.products?.[code]?.name||code;if(historyReturnState)return toast('Historical boards are read-only.');if(confirm('Delete this board from the current floor walk?\n\n'+name)){delete state.selected[code];if(editorCode===code)editorCode=null;save().then(()=>{renderScan();renderBoards()}).catch(x=>toast('Delete failed: '+x.message))}return;}const q=e.target.closest('[data-quick]');if(q)return openBoardQuickEdit(q.dataset.quick);const b=e.target.closest('[data-jump]');if(!b)return;editorCode=b.dataset.jump;selectTab('scan');$('scanEditor').scrollIntoView({behavior:'smooth',block:'start'})});

 $('addAllFocus').addEventListener('click',addAllFocus);$('saveQuickEdit').addEventListener('click',saveBoardQuickEdit);$('cancelQuickEdit').addEventListener('click',()=>{quickEditCode=null;$('quickBoardForm').classList.add('hidden')});$('historyList').addEventListener('click',e=>{const b=e.target.closest('[data-reuse-history]');if(b)return reusePrintJob(b.dataset.reuseHistory);const one=e.target.closest('[data-reuse-one]');if(one){const picker=[...$('historyList').querySelectorAll('[data-history-product]')].find(x=>x.dataset.historyProduct===one.dataset.reuseOne);if(picker?.value)reusePrintJob(one.dataset.reuseOne,picker.value)}});

 $('saveWalk').addEventListener('click',saveWalk);$('finishWalk').addEventListener('click',finishWalk);$('clearCoreWalk').addEventListener('click',clearCoreWalk);$('startCoreWalk').addEventListener('click',startCoreWalk);

 $('exportWalk')?.addEventListener('click',exportWalk);$('importWalkFile')?.addEventListener('change',e=>importWalkFile(e.target.files[0]));

 $('connectPc')?.addEventListener('click',async()=>{try{await applyPair($('pairInput').value.trim())}catch(e){toast(e.message)}});$('copyPhoneLink')?.addEventListener('click',async()=>{if(!window.auremPairLink)return toast('Start the PC receiver to create the QR first.');try{await navigator.clipboard.writeText(window.auremPairLink);toast('Phone pairing link copied. Share it only with your own phone.')}catch{toast('Clipboard unavailable; scan the QR with your phone instead.')}});$('sendPc')?.addEventListener('click',sendPc);$('refreshInbox')?.addEventListener('click',refreshInbox);$('pcInbox')?.addEventListener('click',e=>{const b=e.target.closest('[data-inbox]');if(b)loadInbox(b.dataset.inbox)});

 document.querySelectorAll('input[name=printMode]').forEach(x=>x.addEventListener('change',()=>{state.printMode=x.value;$('marginGroup').classList.toggle('hidden',state.printMode!=='saver');$('pageModeNote').textContent=state.printMode==='saver'?'Experimental packing; original physical sizes, lettering and shapes unchanged. Always inspect output.':'Standard Mode: original size-specific board arrangements.';previewPage=0;save().catch(()=>{});renderBoards()}));

 document.querySelectorAll('input[name=paperSelection]').forEach(x=>x.addEventListener('change',()=>{state.paperSelection=x.value;previewPage=0;save().catch(()=>{});renderBoards()}));

 $('saverMargin').addEventListener('change',e=>{state.saverMargin=Number(e.target.value);previewPage=0;save().catch(()=>{});renderBoards()});

 $('previousBoard').addEventListener('click',()=>{previewPage--;renderBoards()});$('nextBoard').addEventListener('click',()=>{previewPage++;renderBoards()});$('downloadTestPdf').addEventListener('click',downloadPdf);$('shareWhatsAppBtn')?.addEventListener('click',shareWhatsApp);document.querySelectorAll('[data-history-filter]').forEach(btn=>btn.addEventListener('click',()=>renderWalkHistory(btn.dataset.historyFilter)));$('floorWalkHistoryList')?.addEventListener('click',e=>{const d=e.target.closest('[data-delete-floor-history]');if(d)deleteFloorHistory(Number(d.dataset.deleteFloorHistory));});$('printReview').addEventListener('click',printPreview);

 $('newWalk').addEventListener('click',async()=>{if(Object.keys(state.selected||{}).length){const choice=await chooseUnfinishedWalk();if(choice==='cancel')return;if(choice==='save'){try{await archiveCoreWalk('saved')}catch(e){return toast('Could not save unfinished walk: '+e.message)}}}if(!confirm('Open IMPORT / UPLOAD? Current imported data stays active until a replacement passes validation.'))return;stopCamera();state.selected={};state.issues={};state.overrides={};state.totalScans=0;state.duplicates=0;state.walkId='CORE-'+Date.now().toString(36);state.walkStatus='in-progress';editorCode=null;previewPage=0;await save();render();setAppMode('import');});

 window.addEventListener('pagehide',stopCamera);

}

async function init(){connect();await loadVerified().catch(e=>console.warn('Verified register unavailable:',e));if(location.protocol==='file:'){const notice=document.createElement('div');notice.setAttribute('role','alert');notice.style.cssText='background:#402c1b;color:#ffe0a5;border:2px solid #d8af64;border-radius:10px;padding:14px;margin:12px auto;max-width:970px;font-weight:700;line-height:1.5';notice.innerHTML='⚠ AUREM is open as a local HTML file. CORE offline preview remains available, but Loose Grocery, Smart Crop and AI NEED THE PC SERVER. Open the installed AUREM desktop application; file:// cannot access the internal services.';document.querySelector('.app-shell')?.prepend(notice);}try{const stored=await loadStored(),hasLibrary=!!stored?.eanLibrary?.aliases;if(stored){if(stored.eanLibrary)eanLibrary=normalizeEanLibrary(stored.eanLibrary);else eanLibrary=normalizeEanLibrary({aliases:stored.master?.lookups||{},sourceFile:stored.eanFile||'',importedAt:stored.importedAt});if(stored.master)state.master=stored.master;const {eanLibrary:ignored,master:savedMaster,...session}=stored;if(session&&Object.keys(session).length){state={...clean(),...session,master:savedMaster||state.master};}else if(savedMaster){state.master=savedMaster;}if(state.master&&eanLibrary)applyEanLibrary(state.master,eanLibrary);if(!hasLibrary&&state.master)await persistLibraryAndMaster();}for(const [code,name] of Object.entries(state.nameOverrides||{})){if(!verified(code)&&/^\d{9}$/.test(code)&&name)await saveVerified(code,{name,kind:'core'});}if(navigator.storage?.persist)navigator.storage.persist().catch(()=>{})}catch(e){saveOK=false;setMessage('scanGuard','WARNING: IndexedDB unavailable. Do not use for floor walking until local storage works.','error')}

 document.body.dataset.theme=state.theme||'dark';

 document.querySelectorAll('input[name=printMode]').forEach(x=>x.checked=x.value===(state.printMode||'standard'));

 document.querySelectorAll('input[name=paperSelection]').forEach(x=>x.checked=x.value===(state.paperSelection||'ALL'));

 $('saverMargin').value=String(state.saverMargin||0);$('marginGroup').classList.toggle('hidden',state.printMode!=='saver');

 $('pageModeNote').textContent=state.printMode==='saver'?'Experimental packing; board artwork/dimensions stay unchanged. Inspect every page.':'Standard Mode: original size-specific board arrangements.';

mountNonCore({getContext:()=>state,coreSelectTab:selectTab,coreToast:toast});mountInventory({getContext:()=>state});mountMigration();window.addEventListener('aurem-data-cleared',e=>{const groups=e.detail.selected||[];if(groups.includes('core')){state.selected={};state.issues={};state.overrides={};state.totalScans=0;state.duplicates=0;editorCode=null;quickEditCode=null;}if(groups.includes('history'))state.printHistory=[];render();});

 $('themeIcon').textContent=state.theme==='light'?'☾':'☼';$('themeText').textContent=state.theme==='light'?'Dark':'Light';render();if('serviceWorker' in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('./sw.js').catch(()=>{})}

let currentAuth = { signedIn: false, email: '', displayName: '', photoUrl: '' };

function renderAuth() {
  const mount = $('authAccountMount');
  if (!mount) return;
  if (!currentAuth.signedIn) {
    mount.innerHTML = `
      <button id="googleSignInBtn" class="auth-signin-btn" type="button" title="Sign in with Google (Optional)">
        <svg class="google-g" viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.24v3.15C3.26 21.36 7.33 24 12 24z"/><path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.24C.45 8.15 0 9.99 0 12s.45 3.85 1.24 5.42l4.04-3.15z"/><path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.24 6.58l4.04 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/></svg>
        <span>Sign in</span>
      </button>
    `;
    $('googleSignInBtn')?.addEventListener('click', () => {
      if (window.AUREMNative?.requestGoogleSignIn) {
        window.AUREMNative.requestGoogleSignIn();
      } else {
        toast('Google Sign-In is active in the installed Android app.');
      }
    });
  } else {
    const initials = (currentAuth.displayName || currentAuth.email || 'U').charAt(0).toUpperCase();
    const avatarContent = currentAuth.photoUrl
      ? `<img src="${currentAuth.photoUrl}" alt="${currentAuth.displayName}" onerror="this.parentNode.textContent='${initials}'">`
      : initials;
    mount.innerHTML = `
      <div id="authUserPill" class="auth-user-pill" title="Signed in as ${currentAuth.displayName || currentAuth.email}">
        <div class="auth-user-avatar">${avatarContent}</div>
        <span class="auth-user-name">${currentAuth.displayName || currentAuth.email}</span>
      </div>
      <div id="authPopover" class="auth-popover hidden">
        <div class="auth-popover-header">
          <div class="auth-user-avatar" style="width:36px;height:36px;font-size:16px">${avatarContent}</div>
          <div class="auth-popover-info">
            <div class="auth-popover-name">${currentAuth.displayName || 'Google User'}</div>
            <div class="auth-popover-email">${currentAuth.email}</div>
          </div>
        </div>
        <div class="auth-popover-actions">
          <button type="button" id="authSwitchBtn" class="action ghost">Switch Account</button>
          <button type="button" id="authSignOutBtn" class="action ghost">Sign Out</button>
        </div>
        <div class="auth-popover-note">Google Sign-In is optional. All floor walks, scans, stock data, and PDF printing work completely offline without signing in.</div>
      </div>
    `;
    $('authUserPill')?.addEventListener('click', (e) => {
      e.stopPropagation();
      $('authPopover')?.classList.toggle('hidden');
    });
    $('authSwitchBtn')?.addEventListener('click', () => {
      $('authPopover')?.classList.add('hidden');
      window.AUREMNative?.requestGoogleSignIn?.();
    });
    $('authSignOutBtn')?.addEventListener('click', () => {
      $('authPopover')?.classList.add('hidden');
      if (window.AUREMNative?.requestSignOut) {
        window.AUREMNative.requestSignOut();
      } else {
        currentAuth = { signedIn: false, email: '', displayName: '', photoUrl: '' };
        renderAuth();
      }
    });
  }
}

document.addEventListener('click', (e) => {
  const popover = $('authPopover');
  if (popover && !popover.classList.contains('hidden')) {
    if (!popover.contains(e.target) && !$('authUserPill')?.contains(e.target)) {
      popover.classList.add('hidden');
    }
  }
});

window.onAuremAuthChanged = (user) => {
  if (user && typeof user === 'object') {
    currentAuth = {
      signedIn: !!user.signedIn,
      email: user.email || '',
      displayName: user.displayName || '',
      photoUrl: user.photoUrl || ''
    };
  } else {
    currentAuth = { signedIn: false, email: '', displayName: '', photoUrl: '' };
  }
  renderAuth();
};

window.onAuremAuthError = (msg) => {
  if (msg) toast('Google Sign-In: ' + msg);
};

window.onAuremAuthCancelled = () => {
  // Silent dismissal on user cancel
};

function initAuth() {
  if (window.AUREMNative?.getSignedInUser) {
    try {
      const raw = window.AUREMNative.getSignedInUser();
      const parsed = JSON.parse(raw);
      window.onAuremAuthChanged(parsed);
    } catch (e) {
      renderAuth();
    }
  } else {
    renderAuth();
  }
}

init();
initAuth();


