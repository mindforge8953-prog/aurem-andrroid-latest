/* AUREM Notebook Boards — Original Multi-Piece Price Boards
   Faithful reproduction of original black-and-white retail notebook price board family.
   Reuses existing REG-STAT and ITEM_EANS lookup via Bansal CODE.
   Minimal-typing photo OCR workflow. */

import {resolveCode, productMatches, normalizeBansal, barcodeText, money} from './core.js';
import {jpegPdf, svgImage} from './preview.js';
import {attachAutoUppercase} from './app.js';

const B$ = id => document.getElementById(id);
const bEsc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const DB_KEY = 'auremNotebookBoards';

function getDb() {
  return new Promise((yes, no) => {
    const r = indexedDB.open('AUREM_Offline_Data', 1);
    r.onsuccess = () => yes(r.result);
    r.onerror = () => no(r.error);
  });
}

async function loadSavedNotebooks() {
  try {
    const db = await getDb();
    return await new Promise((yes, no) => {
      const tx = db.transaction('data', 'readonly'), r = tx.objectStore('data').get(DB_KEY);
      r.onsuccess = () => yes(Array.isArray(r.result) ? r.result : []);
      r.onerror = () => no(r.error);
    });
  } catch (_) {
    return [];
  }
}

async function saveNotebooksList(list) {
  const db = await getDb();
  try {
    await new Promise((yes, no) => {
      const tx = db.transaction('data', 'readwrite');
      tx.objectStore('data').put(list, DB_KEY);
      tx.oncomplete = yes;
      tx.onerror = () => no(tx.error);
    });
  } finally {
    db.close();
  }
}

// Decimal arithmetic helper
function formatPriceVal(num) {
  if (num === null || num === undefined || num === '') return '0/-';
  const val = Number(num);
  if (!Number.isFinite(val)) return '0/-';
  if (Number.isInteger(val)) return `${val}/-`;
  return `${val.toFixed(2).replace(/\.?0+$/, '')}/-`;
}

function calcPriceVal(num) {
  const val = Number(num);
  if (!Number.isFinite(val)) return '0';
  if (Number.isInteger(val)) return val.toString();
  return val.toFixed(2).replace(/\.?0+$/, '');
}

/**
 * Builds the exact SVG board matching Reference Image 1
 */
export function notebookBoardSvg(data) {
  const W = 1000, H = 705;
  const brand = String(data.brand || 'VIDYA LEKHAN').trim().toUpperCase();
  const name = String(data.name || 'SINGLE LINE NOTE BOOK').trim().toUpperCase();
  const sizePageLine = String(data.sizePageLine || '(SIZE :-29.70 X 21 CM A4  PAGE:-224)').trim().toUpperCase();
  const spNum = Number(data.sp || 0);
  const mrpNum = Number(data.mrp || 0);

  const spDisplay = calcPriceVal(spNum);
  const bspStr = formatPriceVal(spNum);
  const mrpStr = formatPriceVal(mrpNum);
  const pcs3Str = formatPriceVal(spNum * 3);
  const pcs6Str = formatPriceVal(spNum * 6);
  const pcs12Str = formatPriceVal(spNum * 12);

  // Dynamic price sizing to prevent overflow while keeping it massive
  const priceLen = spDisplay.length;
  const priceFontSize = priceLen <= 3 ? 360 : priceLen <= 5 ? 290 : 230;
  const priceY = priceLen <= 3 ? 320 : 310;
  const priceW = Math.min(560, Math.max(220, priceLen * (priceFontSize * 0.58)));

  // Brand layout at top-left
  let brandSvg = '';
  const brandWords = brand.split(/\s+/);
  if (brandWords.length >= 2) {
    brandSvg = `
      <text x="36" y="80" font-family="Arial Black,DejaVu Sans,sans-serif" font-size="64" font-weight="900" fill="black">${bEsc(brandWords[0])}</text>
      <text x="36" y="142" font-family="Arial Black,DejaVu Sans,sans-serif" font-size="64" font-weight="900" fill="black">${bEsc(brandWords.slice(1).join(' '))}</text>
    `;
  } else {
    brandSvg = `<text x="36" y="112" font-family="Arial Black,DejaVu Sans,sans-serif" font-size="92" font-weight="900" fill="black">${bEsc(brand)}</text>`;
  }

  // Name width adjusting
  const safeName = name.slice(0, 65);
  const nameLen = safeName.length;
  const nameTargetW = Math.min(940, Math.max(480, nameLen * 38));

  // Size/Page width adjusting
  const spLineLen = sizePageLine.length;
  const spTargetW = Math.min(940, Math.max(440, spLineLen * 24));

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <rect width="${W}" height="${H}" fill="white"/>
    <!-- Outer thick black border -->
    <rect x="8" y="8" width="984" height="689" fill="none" stroke="black" stroke-width="14"/>

    <!-- Brand top-left -->
    ${brandSvg}

    <!-- Rupee symbol left of giant price -->
    <text x="56" y="275" font-family="Arial Black,DejaVu Sans,sans-serif" font-size="140" font-weight="900" fill="black">₹</text>

    <!-- Dominant massive center price -->
    <text x="490" y="${priceY}" text-anchor="middle" font-family="Arial Black,Arial,DejaVu Sans,sans-serif" font-size="${priceFontSize}" font-weight="900" stroke="black" stroke-width="3" paint-order="stroke" fill="black" textLength="${priceW.toFixed(0)}" lengthAdjust="spacingAndGlyphs">${bEsc(spDisplay)}</text>

    <!-- 1 PCS ONLY at right of price -->
    <text x="965" y="200" text-anchor="end" font-family="Arial Black,Impact,sans-serif" font-size="82" font-weight="900" fill="black">1 PCS</text>
    <text x="965" y="275" text-anchor="end" font-family="Arial Black,Impact,sans-serif" font-size="82" font-weight="900" fill="black">ONLY</text>

    <!-- Center notebook title -->
    <text x="500" y="405" text-anchor="middle" font-family="Arial Black,DejaVu Sans,sans-serif" font-size="80" font-weight="900" stroke="black" stroke-width="1.5" paint-order="stroke" fill="black" textLength="${nameTargetW}" lengthAdjust="spacingAndGlyphs">${bEsc(safeName)}</text>

    <!-- Parenthesized spec line -->
    <text x="500" y="465" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="44" font-weight="900" stroke="black" stroke-width="0.8" paint-order="stroke" fill="black" textLength="${spTargetW}" lengthAdjust="spacingAndGlyphs">${bEsc(sizePageLine)}</text>

    <!-- Bottom 5-column table: MRP | B.SP | 3 PCS | 6 PCS | 12 PCS -->
    <g id="priceTable">
      <!-- Table outer border -->
      <rect x="8" y="490" width="984" height="207" fill="none" stroke="black" stroke-width="10"/>
      <!-- Header row divider -->
      <line x1="8" y1="565" x2="992" y2="565" stroke="black" stroke-width="8"/>
      <!-- Vertical dividers at 204, 401, 598, 795 -->
      <line x1="204" y1="490" x2="204" y2="697" stroke="black" stroke-width="8"/>
      <line x1="401" y1="490" x2="401" y2="697" stroke="black" stroke-width="8"/>
      <line x1="598" y1="490" x2="598" y2="697" stroke="black" stroke-width="8"/>
      <line x1="795" y1="490" x2="795" y2="697" stroke="black" stroke-width="8"/>

      <!-- Column Headers -->
      <text x="106" y="546" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="46" font-weight="900" fill="black">MRP</text>
      <text x="302" y="546" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="46" font-weight="900" fill="black">B.SP</text>
      <text x="500" y="546" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="46" font-weight="900" fill="black">3 PCS</text>
      <text x="696" y="546" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="46" font-weight="900" fill="black">6 PCS</text>
      <text x="893" y="546" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="46" font-weight="900" fill="black">12 PCS</text>

      <!-- Column Values -->
      <text x="106" y="650" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="52" font-weight="900" fill="black">${bEsc(mrpStr)}</text>
      <text x="302" y="650" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="52" font-weight="900" fill="black">${bEsc(bspStr)}</text>
      <text x="500" y="650" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="52" font-weight="900" fill="black">${bEsc(pcs3Str)}</text>
      <text x="696" y="650" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="52" font-weight="900" fill="black">${bEsc(pcs6Str)}</text>
      <text x="893" y="650" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="52" font-weight="900" fill="black">${bEsc(pcs12Str)}</text>
    </g>
  </svg>`;
}

/**
 * Builds A4 printable sheet for Notebook Boards with exact requested copies and size
 */
export function notebookPagePlan(data, size = '1/2', copies = 1) {
  const total = Math.max(1, Math.min(300, parseInt(copies, 10) || 1));
  const board = notebookBoardSvg(data);

  let perPage = 2;
  let cols = 1, rows = 2;
  let isPortrait = true;

  if (size === '1/1') {
    perPage = 1;
    cols = 1;
    rows = 1;
    isPortrait = false;
  } else if (size === '1/4') {
    perPage = 4;
    cols = 2;
    rows = 2;
    isPortrait = false;
  } else if (size === '1/8') {
    perPage = 8;
    cols = 2;
    rows = 4;
    isPortrait = true;
  } else {
    // 1/2 size default: 2 stacked on A4 portrait, exactly matching Reference Image 1!
    perPage = 2;
    cols = 1;
    rows = 2;
    isPortrait = true;
  }

  const pagesCount = Math.ceil(total / perPage);
  const wMm = isPortrait ? 210 : 297;
  const hMm = isPortrait ? 297 : 210;

  const svgs = [];
  let placed = 0;

  for (let p = 0; p < pagesCount; p++) {
    const onThisPage = Math.min(perPage, total - placed);
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${wMm}mm" height="${hMm}mm" viewBox="0 0 ${wMm} ${hMm}"><rect width="${wMm}" height="${hMm}" fill="white"/>`;

    const cellW = wMm / cols;
    const cellH = hMm / rows;

    for (let i = 0; i < onThisPage; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = col * cellW;
      const y = row * cellH;
      s += board.replace(/^<svg[^>]*>/, `<svg x="${x}" y="${y}" width="${cellW}" height="${cellH}" viewBox="0 0 1000 705" preserveAspectRatio="none">`);
    }

    s += '</svg>';
    svgs.push(s);
    placed += onThisPage;
  }

  return {svgs, pagesCount, totalCopies: total, perPage, size};
}

/**
 * On-device photo parser extracting EAN, MRP, Pages, Dimensions, Brand from notebook back photo
 */
export function parseNotebookPhotoOcrText(text) {
  const result = {
    ean: '',
    mrp: '',
    pages: '',
    size: '',
    isA4: false,
    brand: '',
    productName: '',
    uncertainBarcode: false
  };

  if (!text) return result;

  // Pages detection: e.g. "Pages: 224", "Pages : 276", "276 PAGES"
  const pagesMatch = text.match(/Pages?\s*[:\-]\s*(\d{2,4})/i) || text.match(/(\d{2,4})\s*Pages?\b/i);
  if (pagesMatch) {
    result.pages = pagesMatch[1];
  }

  // MRP detection: e.g. "MRP Rs. 95.00", "MRP: ₹120", "MRP 165/-"
  const mrpMatch = text.match(/MRP\s*(?:Rs\.?|₹|INR)?\s*([0-9]{1,4}(?:\.[0-9]{1,2})?)/i) ||
                   text.match(/(?:Rs\.?|₹)\s*([0-9]{1,4}(?:\.[0-9]{1,2})?)\s*\(?\s*Including/i);
  if (mrpMatch) {
    result.mrp = mrpMatch[1];
  }

  // Size detection: e.g. "Size - 29.70 cm x 21 cm", "29.7 X 21 CM", "21 x 29.7 cm"
  const sizeMatch = text.match(/Size\s*[:\-]\s*([0-9.]+\s*(?:cm|mm)?\s*[xX×]\s*[0-9.]+\s*(?:cm|mm)?)/i) ||
                    text.match(/([0-9]{1,2}(?:\.[0-9]{1,2})?\s*(?:cm)?\s*[xX×]\s*[0-9]{1,2}(?:\.[0-9]{1,2})?\s*cm)/i);
  if (sizeMatch) {
    let rawSize = sizeMatch[1].toUpperCase().replace(/\s+/g, ' ');
    if (!rawSize.includes('CM')) rawSize += ' CM';
    result.size = rawSize;
  }

  // A4 detection from text or dimensions (29.7 and 21)
  if (/\bA4\b/i.test(text) || (text.includes('29.7') && text.includes('21'))) {
    result.isA4 = true;
  }

  // Brand detection
  if (/VIDYA\s*LEKHAN/i.test(text)) {
    result.brand = 'VIDYA LEKHAN';
  } else if (/YOUVA/i.test(text)) {
    result.brand = 'YOUVA';
  } else if (/CLASSMATE/i.test(text)) {
    result.brand = 'CLASSMATE';
  } else if (/NAWNEET|NAVNEET/i.test(text)) {
    result.brand = 'NAVNEET';
  }

  // Product name detection
  if (/SPIRAL/i.test(text)) {
    result.productName = 'SINGLE LINE SPIRAL NOTE BOOK';
  } else if (/SINGLE\s*LINE/i.test(text)) {
    result.productName = 'SINGLE LINE NOTE BOOK';
  } else if (/DOUBLE\s*LINE/i.test(text)) {
    result.productName = 'DOUBLE LINE NOTE BOOK';
  } else if (/FOUR\s*LINE/i.test(text)) {
    result.productName = 'FOUR LINE NOTE BOOK';
  } else if (/LONG\s*BOOK/i.test(text)) {
    result.productName = 'LONG BOOK';
  } else if (/NOTE\s*BOOK/i.test(text)) {
    result.productName = 'NOTE BOOK';
  }

  // Barcode / EAN extraction
  // Look for 13 digit number, check EAN-13 valid checksum
  const digitGroups = text.match(/\d{5,18}/g) || [];
  for (const d of digitGroups) {
    if (d.length === 13) {
      let sum = 0;
      for (let i = 0; i < 12; i++) sum += Number(d[i]) * (i % 2 ? 3 : 1);
      if ((10 - sum % 10) % 10 === Number(d[12])) {
        result.ean = d;
        break;
      }
    }
  }

  if (!result.ean && digitGroups.length) {
    // Check if partial digits were detected
    const candidate = digitGroups.find(x => x.length >= 8 && x.length <= 14);
    if (candidate) {
      result.ean = candidate;
      result.uncertainBarcode = true;
    }
  }

  return result;
}

export function mountNotebookBoards({getContext, nToast, saveBlob, printPdf}) {
  const mount = B$('notebookMount');
  if (!mount) return;

  let currentBoardData = {
    brand: 'VIDYA LEKHAN',
    name: 'SINGLE LINE NOTE BOOK',
    pages: '224',
    size: '29.70 X 21 CM',
    isA4: true,
    sizePageLine: '(SIZE :-29.70 X 21 CM A4  PAGE:-224)',
    mrp: '95',
    sp: '84',
    code: '',
    boardSize: '1/2',
    copies: 2
  };

  let savedBoards = [];
  let previewIndex = 0;
  let activePlan = null;

  mount.innerHTML = `
    <section class="card notebook-card">
      <div class="section-title">
        <h2>NOTEBOOK BOARDS — Original Multi-Piece Price Boards</h2>
        <span class="tag">Photo-First · 3/6/12 PCS Multiples</span>
      </div>
      <p class="quiet">Upload or capture notebook packaging. AUREM detects pages, size and MRP, resolves retail SP from imported stock, and generates mathematically accurate 3/6/12 PCS price boards.</p>

      <!-- Step 1: Photo / Barcode Input -->
      <div class="notebook-input-row">
        <label class="upload compact-upload">
          📷 Photo from Camera / Gallery
          <input type="file" id="nbPhotoInput" accept="image/jpeg,image/png,image/webp">
        </label>
        <button type="button" id="nbScanBarcodeBtn" class="action ghost">Scan Printed Barcode</button>
      </div>
      <div id="nbOcrStatus" class="notice">Ready. Capture notebook back-cover photo or scan its barcode.</div>

      <!-- Step 2: Form Fields -->
      <div class="notebook-form-grid">
        <div class="notebook-form-col">
          <label class="field">Brand
            <select id="nbBrand">
              <option value="VIDYA LEKHAN">VIDYA LEKHAN</option>
              <option value="YOUVA">YOUVA</option>
              <option value="CLASSMATE">CLASSMATE</option>
              <option value="NAVNEET">NAVNEET</option>
              <option value="CUSTOM">Custom Brand...</option>
            </select>
          </label>
          <label class="field hidden" id="nbCustomBrandField">Custom Brand Name
            <input type="text" id="nbCustomBrand" placeholder="ENTER BRAND NAME" autocomplete="off">
          </label>
          <label class="field">Notebook Center Name
            <input type="text" id="nbName" placeholder="SINGLE LINE NOTE BOOK" autocomplete="off">
          </label>
          <div class="input-grid">
            <label class="field">Number of Pages
              <input type="number" id="nbPages" placeholder="224" min="16" max="999">
            </label>
            <label class="field">Dimensions (e.g. 29.70 X 21 CM)
              <input type="text" id="nbSize" placeholder="29.70 X 21 CM">
            </label>
            <label class="field" style="display:flex;align-items:center;gap:6px;margin-top:22px">
              <input type="checkbox" id="nbIsA4" checked> Include "A4" in specification
            </label>
          </div>
          <label class="field">Generated Spec Line (Preview)
            <input type="text" id="nbSpecLine" readonly style="background:rgba(0,0,0,0.15)">
          </label>
        </div>

        <div class="notebook-form-col">
          <label class="field">Barcode / EAN or Bansal CODE
            <div class="scan-row">
              <input type="text" id="nbCodeInput" placeholder="Barcode or 9-digit Bansal CODE" autocomplete="off">
              <button type="button" id="nbLookupBtn" class="action primary">Lookup Stock</button>
            </div>
          </label>
          <div id="nbLookupResult" class="notice">Lookup product to retrieve authoritative Retail SP from REG-STAT.</div>

          <div class="input-grid">
            <label class="field">MRP ₹ (from packaging / stock)
              <input type="text" id="nbMrp" inputmode="decimal" placeholder="95">
            </label>
            <label class="field">Retail SP ₹ (B.SP / Center Price)
              <input type="text" id="nbSp" inputmode="decimal" placeholder="84">
            </label>
          </div>

          <div class="input-grid">
            <label class="field">Physical Board Size
              <select id="nbBoardSize">
                <option value="1/2" selected>1/2 • 2 per A4 (Reference Standard)</option>
                <option value="1/4">1/4 • 4 per A4</option>
                <option value="1/1">1/1 • Full A4</option>
                <option value="1/8">1/8 • 8 per A4</option>
              </select>
            </label>
            <label class="field">Number of Physical Copies
              <input type="number" id="nbCopies" min="1" max="300" step="1" value="2">
            </label>
          </div>

          <!-- Calculated multiples preview table -->
          <div class="nb-calc-preview">
            <div class="nb-calc-title">Calculated Price Multiples (Exact Arithmetic)</div>
            <div class="nb-calc-grid">
              <div><small>MRP</small><strong id="nbPrevMrp">95/-</strong></div>
              <div><small>B.SP (SP)</small><strong id="nbPrevBsp">84/-</strong></div>
              <div><small>3 PCS</small><strong id="nbPrevPcs3">252/-</strong></div>
              <div><small>6 PCS</small><strong id="nbPrevPcs6">504/-</strong></div>
              <div><small>12 PCS</small><strong id="nbPrevPcs12">1008/-</strong></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="action-grid" style="margin-top:14px">
        <button type="button" id="nbSaveBtn" class="action primary">Save Notebook Board ✓</button>
        <button type="button" id="nbSavePdfBtn" class="action ghost">Save PDF</button>
        <button type="button" id="nbPrintBtn" class="action ghost">Print Manually</button>
      </div>

      <!-- Board Preview Stage -->
      <div class="section-title" style="margin-top:18px">
        <h3>A4 Print Preview</h3>
        <span id="nbPreviewStatus" class="tag">Sheet 1 / 1 · 2 copies</span>
      </div>
      <div id="nbPreviewStage" class="sheet-stage"></div>
      <div class="pager">
        <button type="button" id="nbPrevPage" class="action ghost">← Previous Sheet</button>
        <span id="nbPageTag" class="tag">1 / 1</span>
        <button type="button" id="nbNextPage" class="action ghost">Next Sheet →</button>
      </div>

      <!-- Saved Notebook Boards -->
      <div class="section-title" style="margin-top:20px">
        <h3>Saved Notebook Boards</h3>
        <span id="nbSavedCount" class="tag">0 saved</span>
      </div>
      <div id="nbSavedList" class="saved-notebooks-list">
        <p class="quiet">No saved notebook boards yet.</p>
      </div>
    </section>
  `;

  // Attach auto uppercase to notebook input fields
  attachAutoUppercase(B$('nbName'));
  attachAutoUppercase(B$('nbCustomBrand'));
  attachAutoUppercase(B$('nbSize'));

  function updateSpecLine() {
    const size = B$('nbSize').value.trim().toUpperCase() || '29.70 X 21 CM';
    const pages = B$('nbPages').value.trim() || '224';
    const isA4 = B$('nbIsA4').checked;
    const a4Part = isA4 ? ' A4 ' : ' ';
    const line = `(SIZE :-${size}${a4Part}PAGE:-${pages})`;
    B$('nbSpecLine').value = line;
    currentBoardData.sizePageLine = line;
  }

  function updateMultiplesPreview() {
    const sp = Number(B$('nbSp').value) || 0;
    const mrp = Number(B$('nbMrp').value) || 0;
    B$('nbPrevMrp').textContent = formatPriceVal(mrp);
    B$('nbPrevBsp').textContent = formatPriceVal(sp);
    B$('nbPrevPcs3').textContent = formatPriceVal(sp * 3);
    B$('nbPrevPcs6').textContent = formatPriceVal(sp * 6);
    B$('nbPrevPcs12').textContent = formatPriceVal(sp * 12);
  }

  function syncFormData() {
    let brand = B$('nbBrand').value;
    if (brand === 'CUSTOM') {
      brand = B$('nbCustomBrand').value.trim().toUpperCase() || 'CUSTOM BRAND';
    }
    currentBoardData.brand = brand;
    currentBoardData.name = B$('nbName').value.trim().toUpperCase() || 'SINGLE LINE NOTE BOOK';
    currentBoardData.pages = B$('nbPages').value.trim() || '224';
    currentBoardData.size = B$('nbSize').value.trim().toUpperCase() || '29.70 X 21 CM';
    currentBoardData.isA4 = B$('nbIsA4').checked;
    updateSpecLine();
    currentBoardData.mrp = B$('nbMrp').value.trim() || '95';
    currentBoardData.sp = B$('nbSp').value.trim() || '84';
    currentBoardData.boardSize = B$('nbBoardSize').value || '1/2';
    currentBoardData.copies = parseInt(B$('nbCopies').value, 10) || 2;
    updateMultiplesPreview();
  }

  function renderPreview() {
    syncFormData();
    activePlan = notebookPagePlan(currentBoardData, currentBoardData.boardSize, currentBoardData.copies);
    const totalPages = activePlan.pagesCount;
    previewIndex = Math.max(0, Math.min(previewIndex, totalPages - 1));

    B$('nbPreviewStatus').textContent = `Sheet ${previewIndex + 1} of ${totalPages} · ${currentBoardData.copies} copies requested (${currentBoardData.boardSize})`;
    B$('nbPageTag').textContent = `${previewIndex + 1} / ${totalPages}`;
    B$('nbPrevPage').disabled = previewIndex === 0;
    B$('nbNextPage').disabled = previewIndex >= totalPages - 1;

    const stage = B$('nbPreviewStage');
    if (stage && activePlan.svgs[previewIndex]) {
      stage.innerHTML = activePlan.svgs[previewIndex];
    }
  }

  function renderSavedList() {
    const container = B$('nbSavedList');
    if (!container) return;
    B$('nbSavedCount').textContent = `${savedBoards.length} saved`;
    if (!savedBoards.length) {
      container.innerHTML = '<p class="quiet">No saved notebook boards yet.</p>';
      return;
    }

    container.innerHTML = savedBoards.slice().reverse().map((b, revIdx) => {
      const origIdx = savedBoards.length - 1 - revIdx;
      return `
        <div class="board-item">
          <div>
            <strong>${bEsc(b.brand)} — ${bEsc(b.name)}</strong>
            <div class="subline">SP: ₹${bEsc(b.sp)} · MRP: ₹${bEsc(b.mrp)} · ${bEsc(b.sizePageLine)} · ${bEsc(b.boardSize || '1/2')} (${b.copies || 2} copies)</div>
          </div>
          <div class="board-actions">
            <button type="button" data-open-nb="${origIdx}">Open &amp; Print</button>
            <button type="button" data-del-nb="${origIdx}" class="danger-text">Delete</button>
          </div>
        </div>
      `;
    }).join('');
  }

  // Lookup in current REG-STAT
  function performStockLookup(rawInput) {
    const text = barcodeText(rawInput || B$('nbCodeInput').value);
    if (!text) {
      B$('nbLookupResult').textContent = 'Enter a barcode or Bansal CODE.';
      B$('nbLookupResult').className = 'notice warn';
      return;
    }

    const ctx = getContext();
    if (!ctx.master?.products) {
      B$('nbLookupResult').textContent = 'REG-STAT not loaded. Import fresh stock reports under CORE → Import to retrieve retail SP.';
      B$('nbLookupResult').className = 'notice warn';
      return;
    }

    const exact = resolveCode(text, ctx.master, {});
    if (exact.status === 'MATCH') {
      const code = exact.code;
      const p = ctx.master.products[code];
      currentBoardData.code = code;
      B$('nbCodeInput').value = code;

      // Extract Retail SP and MRP
      if (p.retail) {
        B$('nbSp').value = p.retail;
        currentBoardData.sp = p.retail;
      }
      if (p.mrp) {
        B$('nbMrp').value = p.mrp;
        currentBoardData.mrp = p.mrp;
      }
      if (p.name) {
        // Only override name if current is default
        if (B$('nbName').value === 'SINGLE LINE NOTE BOOK' || !B$('nbName').value) {
          B$('nbName').value = p.name.toUpperCase();
        }
      }

      B$('nbLookupResult').textContent = `Matched Bansal CODE ${code} (${p.name}). Retail SP: ₹${p.retail || '—'} · MRP: ₹${p.mrp || '—'}`;
      B$('nbLookupResult').className = 'notice good';
      nToast(`Found stock product: ₹${p.retail}`);
      renderPreview();
    } else if (exact.status === 'AMBIGUOUS') {
      B$('nbLookupResult').textContent = `Barcode is ambiguous (${exact.candidates.length} products). Please enter the unique Bansal CODE directly.`;
      B$('nbLookupResult').className = 'notice warn';
    } else {
      B$('nbLookupResult').textContent = `Code ${text} not found in current REG-STAT. You may enter verified SP and MRP manually.`;
      B$('nbLookupResult').className = 'notice warn';
    }
  }

  // Process photo OCR
  async function processPackagingPhoto(file) {
    if (!file) return;
    const status = B$('nbOcrStatus');
    status.textContent = 'Reading notebook packaging photo...';
    status.className = 'notice';

    try {
      const bmp = await createImageBitmap(file);
      const canvas = document.createElement('canvas');
      const scale = Math.min(1, 1400 / Math.max(bmp.width, bmp.height));
      canvas.width = Math.round(bmp.width * scale);
      canvas.height = Math.round(bmp.height * scale);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
      bmp.close();

      const b64 = canvas.toDataURL('image/jpeg', 0.88).split(',')[1];
      const requestId = 'ocr-nb-' + Date.now();

      // Read OCR text via native bridge or on-device fallback
      let ocrText = '';
      if (window.AUREMNative?.recognizeDigits) {
        ocrText = await new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            if (window._auremOcrPending?.id === requestId) {
              window._auremOcrPending = null;
              reject(Error('OCR timed out'));
            }
          }, 15000);
          window._auremOcrPending = {
            id: requestId,
            resolve: txt => {
              clearTimeout(timer);
              resolve(txt);
            }
          };
          window.AUREMNative.recognizeDigits(b64, requestId);
        });
      }

      const parsed = parseNotebookPhotoOcrText(ocrText);

      // Populate extracted values
      if (parsed.brand) {
        B$('nbBrand').value = parsed.brand;
      }
      if (parsed.productName) {
        B$('nbName').value = parsed.productName;
      }
      if (parsed.pages) {
        B$('nbPages').value = parsed.pages;
      }
      if (parsed.size) {
        B$('nbSize').value = parsed.size;
      }
      if (parsed.isA4 !== undefined) {
        B$('nbIsA4').checked = parsed.isA4;
      }
      if (parsed.mrp) {
        B$('nbMrp').value = parsed.mrp;
      }

      if (parsed.ean) {
        B$('nbCodeInput').value = parsed.ean;
        if (parsed.uncertainBarcode) {
          status.textContent = `Extracted photo details (Pages: ${parsed.pages || '—'}, MRP: ₹${parsed.mrp || '—'}). Barcode ${parsed.ean} is partial; review before lookup.`;
          status.className = 'notice warn';
        } else {
          status.textContent = `Extracted details from photo! Complete EAN detected: ${parsed.ean}. Performing automatic stock lookup...`;
          status.className = 'notice good';
          performStockLookup(parsed.ean);
        }
      } else {
        status.textContent = `Extracted photo details: Pages: ${parsed.pages || '—'}, Size: ${parsed.size || '—'}, MRP: ₹${parsed.mrp || '—'}. Barcode not visible or cut off; scan barcode directly or enter code.`;
        status.className = 'notice warn';
      }

      renderPreview();
    } catch (err) {
      status.textContent = 'Photo recognition: ' + err.message + '. Enter details manually.';
      status.className = 'notice warn';
    }
  }

  // Event Listeners
  B$('nbBrand')?.addEventListener('change', () => {
    const isCustom = B$('nbBrand').value === 'CUSTOM';
    B$('nbCustomBrandField')?.classList.toggle('hidden', !isCustom);
    renderPreview();
  });

  ['nbCustomBrand', 'nbName', 'nbPages', 'nbSize', 'nbMrp', 'nbSp', 'nbBoardSize', 'nbCopies'].forEach(id => {
    B$(id)?.addEventListener('input', renderPreview);
    B$(id)?.addEventListener('change', renderPreview);
  });

  B$('nbIsA4')?.addEventListener('change', renderPreview);

  B$('nbLookupBtn')?.addEventListener('click', () => performStockLookup());
  B$('nbCodeInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') performStockLookup();
  });

  B$('nbPhotoInput')?.addEventListener('change', e => {
    const file = e.target.files?.[0];
    if (file) processPackagingPhoto(file);
  });

  B$('nbScanBarcodeBtn')?.addEventListener('click', () => {
    window.auremOpenScanner?.(raw => {
      B$('nbCodeInput').value = raw;
      performStockLookup(raw);
    }, 'barcode');
  });

  B$('nbPrevPage')?.addEventListener('click', () => {
    previewIndex--;
    renderPreview();
  });

  B$('nbNextPage')?.addEventListener('click', () => {
    previewIndex++;
    renderPreview();
  });

  // Save Notebook Board to IndexedDB
  B$('nbSaveBtn')?.addEventListener('click', async () => {
    syncFormData();
    try {
      const record = {
        ...currentBoardData,
        id: 'nb-' + Date.now().toString(36),
        savedAt: Date.now()
      };
      savedBoards.push(record);
      await saveNotebooksList(savedBoards);
      renderSavedList();
      nToast('Notebook board saved locally in AUREM.');
    } catch (e) {
      nToast('Save failed: ' + e.message);
    }
  });

  // Click on saved notebook board
  B$('nbSavedList')?.addEventListener('click', async e => {
    const openBtn = e.target.closest('[data-open-nb]');
    if (openBtn) {
      const idx = parseInt(openBtn.dataset.openNb, 10);
      const item = savedBoards[idx];
      if (!item) return;

      currentBoardData = {...item};
      if (B$('nbBrand')) {
        if (['VIDYA LEKHAN', 'YOUVA', 'CLASSMATE', 'NAVNEET'].includes(item.brand)) {
          B$('nbBrand').value = item.brand;
          B$('nbCustomBrandField')?.classList.add('hidden');
        } else {
          B$('nbBrand').value = 'CUSTOM';
          B$('nbCustomBrandField')?.classList.remove('hidden');
          B$('nbCustomBrand').value = item.brand;
        }
      }
      if (B$('nbName')) B$('nbName').value = item.name;
      if (B$('nbPages')) B$('nbPages').value = item.pages;
      if (B$('nbSize')) B$('nbSize').value = item.size;
      if (B$('nbIsA4')) B$('nbIsA4').checked = !!item.isA4;
      if (B$('nbMrp')) B$('nbMrp').value = item.mrp;
      if (B$('nbSp')) B$('nbSp').value = item.sp;
      if (B$('nbBoardSize')) B$('nbBoardSize').value = item.boardSize || '1/2';
      if (B$('nbCopies')) B$('nbCopies').value = item.copies || 2;
      if (B$('nbCodeInput')) B$('nbCodeInput').value = item.code || '';

      // Re-validate SP against latest REG-STAT
      if (item.code) {
        const ctx = getContext();
        const p = ctx.master?.products?.[item.code];
        if (p && p.retail && p.retail !== item.sp) {
          B$('nbSp').value = p.retail;
          currentBoardData.sp = p.retail;
          nToast(`Updated SP to ₹${p.retail} from latest REG-STAT report`);
        }
      }

      renderPreview();
      B$('notebookMount').scrollIntoView({behavior: 'smooth', block: 'start'});
      return;
    }

    const delBtn = e.target.closest('[data-del-nb]');
    if (delBtn) {
      const idx = parseInt(delBtn.dataset.delNb, 10);
      if (!confirm('Delete this saved notebook board?')) return;
      savedBoards.splice(idx, 1);
      await saveNotebooksList(savedBoards);
      renderSavedList();
      nToast('Saved notebook board deleted.');
    }
  });

  // Save PDF
  B$('nbSavePdfBtn')?.addEventListener('click', async () => {
    syncFormData();
    try {
      nToast('Preparing Notebook Boards PDF...');
      const plan = notebookPagePlan(currentBoardData, currentBoardData.boardSize, currentBoardData.copies);
      const sheets = [];

      for (let i = 0; i < plan.svgs.length; i++) {
        const svg = plan.svgs[i];
        const isPortrait = currentBoardData.boardSize === '1/2' || currentBoardData.boardSize === '1/8';
        const wMm = isPortrait ? 210 : 297;
        const hMm = isPortrait ? 297 : 210;

        const cv = document.createElement('canvas');
        cv.width = Math.round(wMm * 5);
        cv.height = Math.round(hMm * 5);
        const c = cv.getContext('2d', {alpha: false});
        c.fillStyle = '#ffffff';
        c.fillRect(0, 0, cv.width, cv.height);

        const img = await svgImage(svg);
        c.drawImage(img, 0, 0, cv.width, cv.height);
        const jpeg = await new Promise(res => cv.toBlob(b => b.arrayBuffer().then(v => res(new Uint8Array(v))), 'image/jpeg', 0.96));
        sheets.push({jpeg, wPt: wMm * 72 / 25.4, hPt: hMm * 72 / 25.4, wPx: cv.width, hPx: cv.height});
      }

      const pdfBlob = jpegPdf(sheets);
      const filename = `AUREM_NOTEBOOK_${currentBoardData.brand.replace(/\s+/g, '_')}_${Date.now()}.pdf`;
      saveBlob(pdfBlob, filename);
      nToast('Notebook board PDF saved.');
    } catch (err) {
      nToast('PDF generation failed: ' + err.message);
    }
  });

  // Print manually
  B$('nbPrintBtn')?.addEventListener('click', async () => {
    syncFormData();
    try {
      const plan = notebookPagePlan(currentBoardData, currentBoardData.boardSize, currentBoardData.copies);
      printPdf(plan.svgs, `AUREM NOTEBOOK - ${currentBoardData.brand}`);
    } catch (err) {
      nToast('Print error: ' + err.message);
    }
  });

  // Initial load
  loadSavedNotebooks().then(list => {
    savedBoards = list;
    renderSavedList();
  });

  renderPreview();
}
