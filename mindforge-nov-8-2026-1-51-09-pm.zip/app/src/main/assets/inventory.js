/* CORE+NON-CORE read-only Stock/SP and permanent rack-by-rack Mall Audit. */

import {resolveCode,isNonCoreProduct,productMatches} from './core.js';
import {attachAutoUppercase} from './app.js';

import {verified,verifiedName,allVerified,saveVerified,restoreVerified} from './verified.js';

const $=id=>document.getElementById(id);

const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));

function db(){return new Promise((ok,no)=>{const r=indexedDB.open('AUREM_Offline_Data',1);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})}

async function getMeta(){const d=await db();try{return await new Promise((ok,no)=>{const r=d.transaction('data').objectStore('data').get('auremAuditLocationsV7');r.onsuccess=()=>ok(r.result||{racks:[],categories:[]});r.onerror=()=>no(r.error)})}finally{d.close()}}

async function putMeta(value){const d=await db();try{return await new Promise((ok,no)=>{const tx=d.transaction('data','readwrite');tx.objectStore('data').put(structuredClone(value),'auremAuditLocationsV7');tx.oncomplete=ok;tx.onerror=()=>no(tx.error)})}finally{d.close()}}

export function mountInventory({getContext}){

 const root=$('inventoryMount');if(!root)return;

 let current=null,mode='',meta={racks:[],categories:[]},selectedRack='',selectedCategory='';

 root.innerHTML=`<div class="intro"><div class="eyebrow" id="invEyebrow">AUREM / STOCK</div><h1 id="invTitle">Stock & Retail (SP)</h1><p id="invSubtitle">Read-only product stock and selling price from the most recently imported REG-STAT.</p></div>
<div class="inv-workspace">
<div class="inv-workspace-left" id="invWorkspaceLeft">
 <section class="card" id="invLocationCard"><h2>Choose rack & section</h2><div class="input-grid"><label class="field">Rack<select id="invRack"><option value="">Choose a rack</option></select></label><label class="field">Category / section<select id="invCategory"><option value="">Choose a category</option></select></label></div><div class="input-grid"><label class="field">New rack name<input id="invRackNew" placeholder="RACK-1"></label><label class="field">New category<input id="invCategoryNew" placeholder="TEA SECTION"></label></div><div class="action-grid"><button class="action ghost" id="invAddRack">+ Create Rack</button><button class="action ghost" id="invAddCategory">+ Create Category</button></div></section>
 <section class="card inv-scan-card"><h2>Scan / find product</h2><div class="scan-row"><input id="invSearch" type="search" autocomplete="off" placeholder="Barcode, EAN, Bansal CODE or product name"><button class="action primary" id="invFind">Find</button><button class="action ghost" id="invScan">Scan</button></div><div id="invNote" class="notice">Import REG-STAT and ITEM_EANS under Import / Upload first.</div><div id="invCandidates" class="inv-list"></div></section>
</div>
<div class="inv-workspace-right" id="invWorkspaceRight">
 <section class="card hidden" id="invProductCard">
  <div class="inv-product-header">
   <div class="inv-product-ident">
    <h2 id="invProductName">Product</h2>
    <div class="inv-meta-row"><span class="inv-code" id="invCode">Bansal CODE</span><span id="invType" class="tag">CORE</span><span id="invBarcodeChip" class="inv-barcode-chip">BAR CODE: <strong id="invBarcodeHeader">—</strong><strong id="invBarcodeValue" style="display:none">—</strong></span></div>
   </div>
  </div>
  <div id="invStockSection" class="inv-stock-details">
   <div class="inv-price-row-hero">
    <div class="inv-hero-cost"><span class="inv-label">COST</span><strong id="invCostValue">Not Available</strong></div>
    <div class="inv-hero-sp"><span class="inv-label">SELLING PRICE (SP)</span><strong id="invPriceValue">Not Available</strong></div>
    <div class="inv-hero-mrp"><span class="inv-label">MRP</span><strong id="invMrpValue">Not Available</strong></div>
   </div>
   <div class="inv-stock-row-hero">
    <div class="inv-hero-opening"><span class="inv-label">OPENING QTY</span><strong id="invOpeningValue">Not Available</strong></div>
    <div class="inv-hero-closing"><span class="inv-label">CLOSING QTY</span><strong id="invStockValue">Not Available</strong><small id="invStockSource"></small></div>
   </div>
   <div class="inv-details-row-hero">
    <div class="inv-detail-card"><span class="inv-label">LAST PURCHASE DATE</span><strong id="invLastDateValue">Not Available</strong></div>
    <div class="inv-detail-card"><span class="inv-label">SUPPLIER</span><strong id="invSupplierValue">Not Available</strong></div>
   </div>
  </div>
  <div id="invAuditSection" class="hidden">
   <label class="field">Correct product name<input id="invName" autocomplete="off"></label>
   <div id="invCoreFields" class="input-grid"><label class="field">Quantity / grammage<input id="invQty" placeholder="500" inputmode="decimal"></label><label class="field">Unit<select id="invUnit"><option value="">None</option><option value="G">G</option><option value="KG">KG</option><option value="ML">ML</option><option value="LTR">LTR</option><option value="NOS">NOS</option></select></label></div>
   <div id="invNonCoreFields" class="hidden"><h3>NON-CORE information — select applicable types</h3><div class="input-grid"><label class="field"><span><input type="checkbox" id="invPcsOn"> PCS SET</span><input type="number" id="invPcs" min="1" max="9999" placeholder="3"></label><label class="field"><span><input type="checkbox" id="invUnderOn"> SIZE (UNDERGARMENT STYLE)</span><input id="invUnder" placeholder="90 CM"></label><label class="field"><span><input type="checkbox" id="invHomeOn"> SIZE (DOORMAT STYLE)</span><input id="invHome" placeholder="225 X 250 CM APPROX"></label></div><p class="mini">Example: (2 PCS SET) (90 CM), or (SIZE:-225 X 250 CM APPROX)</p></div>
   <div class="notice" id="invLocations">No saved locations yet.</div>
   <button id="invSave" class="action primary">Save Product & Scan Next →</button>
   <p class="mini">Saved by permanent Bansal CODE. Importing a new report does not overwrite your verified details. Stock prices still come from REG-STAT.</p>
  </div>
 </section>
</div>
</div>
<section id="invAuditProgress" class="card hidden"><div class="action-grid"><button id="invBackup" class="action ghost" type="button">Download Audit Backup</button><label class="upload compact-upload">Restore Audit Backup<input id="invRestore" type="file" accept=".json,application/json"></label></div><div class="section-title"><h2>Audit progress</h2><span id="invTotal" class="tag">0 verified products</span></div><div id="invProgress" class="inv-list"></div></section>`;

 const product=c=>getContext().master?.products?.[c];

 const status=(msg,cls='')=>{$('invNote').textContent=msg;$('invNote').className='notice '+cls};

 const lists=()=>{

  const racks=[...new Set([...meta.racks,...allVerified().flatMap(p=>(p.locations||[]).map(l=>l.rack))])].sort();

  const cats=[...new Set([...meta.categories,...allVerified().flatMap(p=>(p.locations||[]).map(l=>l.category))])].sort();

  $('invRack').innerHTML='<option value="">Choose a rack</option>'+racks.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');

  $('invCategory').innerHTML='<option value="">Choose a category</option>'+cats.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');

  $('invRack').value=selectedRack;$('invCategory').value=selectedCategory;

 };

 function setInventoryMode(m){

  mode=m;current=null;

  const audit=m==='audit';

  $('invEyebrow').textContent=audit?'AUREM / MALL AUDIT':'AUREM / STOCK';

  $('invTitle').textContent=audit?'Mall Audit':'Stock & Retail (SP)';

  $('invSubtitle').textContent=audit?'Audit CORE and NON-CORE products, rack by rack. One verified name, multiple saved locations.':'Scan or search and view only available stock and current retail selling price (SP). No refill workflow.';

  $('invLocationCard').classList.toggle('hidden',!audit);

  $('invAuditProgress').classList.toggle('hidden',!audit);

  $('invProductCard').classList.add('hidden');

  $('invSearch').value='';$('invCandidates').textContent='';

  status(getContext().master?.products?'Ready. Scan product barcode or search its name.':'Import REG-STAT and ITEM_EANS first.',getContext().master?.products?'good':'warn');

  lists();

  renderProgress();

  setTimeout(()=>$('invSearch')?.focus(),50);

 }

 window.auremSetInventoryMode=setInventoryMode;

 function renderProgress(){const arr=allVerified().filter(x=>x.locations?.length);$('invTotal').textContent=arr.length+' products with rack locations';$('invProgress').innerHTML=arr.length?arr.slice().sort((a,b)=>b.updatedAt-a.updatedAt).slice(0,80).map(x=>`<div class="inv-result"><strong>${esc(x.name||product(x.code)?.name||x.code)}</strong> <span class="inv-help">${esc(x.code)}</span><br>${x.locations.map(l=>`<span class="inv-chip">${esc(l.rack)} / ${esc(l.category)}</span>`).join('')}</div>`).join(''):'<p class="quiet">No audited products yet. Choose rack/category and save your first scanned product.</p>'}

 function select(code,searchedBarcode=''){const p=product(code);if(!p)return status('This product is not in the latest imported REG-STAT.','warn');current=code;
 const nc=isNonCoreProduct(p),v=verified(code)||{};if($('invProductCard'))$('invProductCard').classList.remove('hidden');if($('invProductName'))$('invProductName').textContent=verifiedName(code,p.name);if($('invCode'))$('invCode').textContent=`Bansal CODE ${code}`;if($('invType'))$('invType').textContent=nc?'NON-CORE':'CORE';
 if($('invStockSection'))$('invStockSection').classList.toggle('hidden',mode!=='stock');if($('invAuditSection'))$('invAuditSection').classList.toggle('hidden',mode!=='audit');if($('invCoreFields'))$('invCoreFields').classList.toggle('hidden',nc);if($('invNonCoreFields'))$('invNonCoreFields').classList.toggle('hidden',!nc);
 const available=val=>{if(val===0||val==='0'||val==='0.0'||val==='0.00')return'0';if(val===null||val===undefined||String(val).trim()==='')return'Not Available';return String(val).trim();};
 const moneyDisplay=val=>{if(val===0||val==='0'||val==='0.0'||val==='0.00'||val==='0.000')return'₹ 0';const s=available(val);if(s==='Not Available')return'Not Available';if(s==='0')return'₹ 0';return s.startsWith('₹')?s:'₹ '+s;};
 const master=getContext().master;
 const lookupBarcode=(master?.lookups?Object.keys(master.lookups).find(k=>k!==code&&master.lookups[k]?.includes(code)):'')||'';
 const barcodeToShow=(p.barcode&&String(p.barcode).trim())?String(p.barcode).trim():(searchedBarcode||lookupBarcode||'—');
 if($('invBarcodeHeader'))$('invBarcodeHeader').textContent=barcodeToShow;
 if($('invBarcodeValue'))$('invBarcodeValue').textContent=barcodeToShow;
 if($('invCostValue'))$('invCostValue').textContent=moneyDisplay(p.cost);
 if($('invPriceValue'))$('invPriceValue').textContent=moneyDisplay(p.retail);
 if($('invMrpValue'))$('invMrpValue').textContent=moneyDisplay(p.mrp);
 const opStr=available(p.openingStock);if($('invOpeningValue'))$('invOpeningValue').textContent=opStr==='Not Available'?'0':(opStr+(p.stockUnit?' '+p.stockUnit:''));
 const clStr=available(p.stock);if($('invStockValue'))$('invStockValue').textContent=clStr==='Not Available'?'0':(clStr+(p.stockUnit?' '+p.stockUnit:''));
 if($('invStockSource'))$('invStockSource').textContent=p.stockColumn?'REG-STAT source: '+p.stockColumn:'';
 if($('invLastDateValue'))$('invLastDateValue').textContent=available(p.lastPurDate);
 if($('invSupplierValue'))$('invSupplierValue').textContent=available(p.supplier);
 if($('invName'))$('invName').value=v.name||p.name;if($('invQty'))$('invQty').value=v.qty||'';if($('invUnit'))$('invUnit').value=v.unit||'';
 if($('invPcsOn'))$('invPcsOn').checked=!!v.infoPcs;if($('invUnderOn'))$('invUnderOn').checked=!!v.infoUnder;if($('invHomeOn'))$('invHomeOn').checked=!!v.infoHome;if($('invPcs'))$('invPcs').value=v.pcs||'';if($('invUnder'))$('invUnder').value=v.underSize||'';if($('invHome'))$('invHome').value=v.homeSize||'';
 if($('invLocations'))$('invLocations').textContent=(v.locations||[]).length?'Saved locations: '+v.locations.map(l=>l.rack+' / '+l.category).join(' · '):'Not yet audited in any rack';if($('invCandidates'))$('invCandidates').textContent='';status('Found: '+code+' — '+p.name,'good')}
 function find(){const ctx=getContext();if(!ctx.master?.products)return status('Import REG-STAT and ITEM_EANS first.','warn');const q=$('invSearch').value.trim();if(!q)return status('Scan or type a barcode, Bansal CODE, or product name.','warn');
 const exact=resolveCode(q,ctx.master,{});if(exact.status==='MATCH'){select(exact.code,exact.barcode);return}

 if(exact.status==='AMBIGUOUS'){status('Barcode matches multiple Bansal CODEs. Select the correct product manually; never guess.','warn');showCandidates(exact.candidates);return}

 const terms=q.toLowerCase();const codes=Object.keys(ctx.master.products).filter(c=>productMatches(ctx.master,c,terms,[verifiedName(c,ctx.master.products[c].name)])).slice(0,45);

 if(!codes.length){status('UNKNOWN BARCODE / no matching product. Nothing added.','warn');$('invCandidates').textContent='';return}if(codes.length===1){select(codes[0]);return}status(`${codes.length} matching products — select the correct one.`);showCandidates(codes)}

 function liveNameSearch(){const ctx=getContext(),q=$('invSearch').value.trim().toLocaleLowerCase();if(!q){$('invCandidates').innerHTML='';return;}if(!ctx.master?.products){$('invCandidates').innerHTML='';return;}const codes=Object.keys(ctx.master.products).filter(code=>{const p=ctx.master.products[code];return productMatches(ctx.master,code,q,[verifiedName(code,p.name)]);}).slice(0,45);if(!codes.length){$('invCandidates').innerHTML='<p class="quiet">No matching product name. Nothing selected.</p>';return;}status(`${codes.length} name matches — select the correct product.`);showCandidates(codes);} function showCandidates(codes){$('invCandidates').innerHTML=codes.map(code=>`<div class="inv-result"><strong>${esc(verifiedName(code,product(code)?.name))}</strong> <span class="inv-help">${esc(code)} · ${isNonCoreProduct(product(code))?'NON-CORE':'CORE'}</span> <button type="button" data-inv-code="${esc(code)}">Select</button></div>`).join('')}

 async function create(kind){const id=kind==='racks'?'invRackNew':'invCategoryNew',selectId=kind==='racks'?'invRack':'invCategory';const name=$(id).value.trim().toUpperCase().replace(/\s+/g,' ');if(!name||name.length>70)return status('Enter a rack or category name (up to 70 characters).','warn');if(!meta[kind].includes(name))meta[kind].push(name);await putMeta(meta);if(kind==='racks')selectedRack=name;else selectedCategory=name;lists();$(selectId).value=name;$(id).value='';status('Created '+name,'good')}

 async function auditSave(){if(mode!=='audit'||!current)return status('Scan an item before saving.','warn');selectedRack=$('invRack').value;selectedCategory=$('invCategory').value;if(!selectedRack||!selectedCategory)return status('Select both Rack and Category before saving.','warn');const p=product(current),nc=isNonCoreProduct(p),name=$('invName').value.trim().replace(/\s+/g,' ');if(!name)return status('Enter a corrected product name.','warn');

 let attrs={name,kind:nc?'noncore':'core',location:{rack:selectedRack,category:selectedCategory}};

 if(nc){attrs={...attrs,infoPcs:$('invPcsOn').checked,pcs:$('invPcs').value.trim(),infoUnder:$('invUnderOn').checked,underSize:$('invUnder').value.trim(),infoHome:$('invHomeOn').checked,homeSize:$('invHome').value.trim()};if(attrs.infoPcs&&(!/^\d{1,4}$/.test(attrs.pcs)||Number(attrs.pcs)<1))return status('Enter a valid Number of PCS.','warn');if(attrs.infoUnder&&!attrs.underSize)return status('Enter undergarment size.','warn');if(attrs.infoHome&&!attrs.homeSize)return status('Enter doormat-style size.','warn');if(attrs.infoUnder&&attrs.infoHome)return status('Choose one of the two size styles, not both.','warn')}

 else{attrs.qty=$('invQty').value.trim();attrs.unit=$('invUnit').value;if(attrs.qty&&(!/^\d+(?:\.\d+)?$/.test(attrs.qty)||Number(attrs.qty)<=0))return status('Enter a positive grammage/quantity.','warn')}

 try{await saveVerified(current,attrs);const code=current;current=null;$('invProductCard').classList.add('hidden');$('invSearch').value='';renderProgress();lists();status(`Saved ${code} with ${selectedRack} / ${selectedCategory}. Scan the next product.`, 'good');$('invSearch').focus()}catch(e){status('Save failed: '+e.message,'error')}

 }

 $('invRack').addEventListener('change',e=>selectedRack=e.target.value);$('invCategory').addEventListener('change',e=>selectedCategory=e.target.value);

 $('invAddRack').addEventListener('click',()=>create('racks').catch(e=>status(e.message,'error')));$('invAddCategory').addEventListener('click',()=>create('categories').catch(e=>status(e.message,'error')));

 $('invScan').addEventListener('click',()=>{if(window.auremScannerActive?.())return window.auremStopScanner?.();window.auremOpenScanner?.(raw=>{$('invSearch').value=raw;find();$('invProductCard').scrollIntoView({behavior:'smooth',block:'start'})},'barcode').catch(e=>status('Camera scan failed: '+e.message,'error'))});let invSearchTimer;$("invSearch").addEventListener("input",()=>{clearTimeout(invSearchTimer);invSearchTimer=setTimeout(liveNameSearch,100)});$('invFind').addEventListener('click',find);$('invSearch').addEventListener('keydown',e=>{if(e.key==='Enter')find()});$('invCandidates').addEventListener('click',e=>{const b=e.target.closest('[data-inv-code]');if(b)select(b.dataset.invCode)});

 $('invUnderOn').addEventListener('change',()=>{if($('invUnderOn').checked)$('invHomeOn').checked=false});$('invHomeOn').addEventListener('change',()=>{if($('invHomeOn').checked)$('invUnderOn').checked=false});
 attachAutoUppercase($('invName'));

 $('invSave').addEventListener('click',auditSave);

 $('invBackup').addEventListener('click',()=>{const d={format:'AUREM-AUDIT-V7',savedAt:new Date().toISOString(),records:allVerified(),racks:meta.racks,categories:meta.categories};const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const fileName='AUREM_AUDIT_BACKUP_'+new Date().toISOString().slice(0,10)+'.json';if(window.AUREMNative?.saveFile){const reader=new FileReader();reader.onloadend=()=>window.AUREMNative.saveFile(reader.result.split(',')[1],fileName,'application/json');reader.readAsDataURL(blob);status('Saving audit backup to Downloads/AUREM…','good');return;}const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=fileName;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);status('Audit backup downloaded. Keep a secure copy.','good')});

 $('invRestore').addEventListener('change',async e=>{try{const file=e.target.files[0];if(!file)return;if(file.size>15000000)throw Error('Backup file too large');const data=JSON.parse(await file.text());if(data.format!=='AUREM-AUDIT-V7'||!Array.isArray(data.records))throw Error('Not a supported Audit backup');if(!confirm(`Merge ${data.records.length} saved products into this device? This can update verified product names.`))return;const n=await restoreVerified(data.records);meta.racks=[...new Set([...meta.racks,...(data.racks||[])])];meta.categories=[...new Set([...meta.categories,...(data.categories||[])])];await putMeta(meta);lists();renderProgress();status(`${n} Audit records restored/merged.`, 'good')}catch(err){status('Restore failed: '+err.message,'error')}finally{e.target.value=''}});



 getMeta().then(x=>{meta=x;lists()}).catch(e=>status('Audit rack list could not load: '+e.message,'error'));

}

