/* AUREM AI Board Studio — Cloudflare FLUX.2 Klein 4B Engine
   Full real image generation, Google Login integration, Option A/B typography overlay,
   PDF/image saving, WhatsApp sharing, printing and local IndexedDB persistence. */

import {jpegPdf} from './preview.js';
import {attachAutoUppercase} from './app.js';

const S$ = id => document.getElementById(id);
const studioEsc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const note = (msg, bad = false, good = false) => {
  const e = S$('studioStatus');
  if (e) {
    e.textContent = msg;
    e.className = 'studio-status' + (bad ? ' bad' : good ? ' good' : '');
  }
};

const getDb = () => new Promise((yes, no) => {
  const r = indexedDB.open('AUREM_Offline_Data', 1);
  r.onsuccess = () => yes(r.result);
  r.onerror = () => no(r.error);
});

async function getKey(k) {
  const db = await getDb();
  try {
    return await new Promise((yes, no) => {
      const tx = db.transaction('data', 'readonly'), r = tx.objectStore('data').get(k);
      r.onsuccess = () => yes(r.result);
      r.onerror = () => no(r.error);
    });
  } finally {
    db.close();
  }
}

async function putKey(k, v) {
  const db = await getDb();
  try {
    await new Promise((yes, no) => {
      const tx = db.transaction('data', 'readwrite');
      tx.objectStore('data').put(v, k);
      tx.oncomplete = yes;
      tx.onerror = () => no(tx.error);
    });
  } finally {
    db.close();
  }
}

async function imageFile(file) {
  if (!file) return '';
  if (!/^image\/(png|jpeg|webp)$/.test(file.type)) throw Error('Choose PNG, JPEG or WebP.');
  if (file.size > 12e6) throw Error('Each photo must be under 12 MB before resizing.');
  const bmp = await createImageBitmap(file);
  const canvas = document.createElement('canvas');
  const scale = Math.min(1, 1300 / Math.max(bmp.width, bmp.height));
  canvas.width = Math.round(bmp.width * scale);
  canvas.height = Math.round(bmp.height * scale);
  canvas.getContext('2d').drawImage(bmp, 0, 0, canvas.width, canvas.height);
  bmp.close();
  return canvas.toDataURL('image/jpeg', 0.85);
}

const imageLoad = src => new Promise((yes, no) => {
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => yes(img);
  img.onerror = () => no(Error('Image loading failed'));
  img.src = src;
});

const studioSizes = {
  '1/1': {cols: 1, rows: 1, portrait: false},
  '1/2': {cols: 1, rows: 2, portrait: true},
  '1/3': {cols: 1, rows: 3, portrait: true},
  '1/4': {cols: 2, rows: 2, portrait: true},
  '1/8': {cols: 2, rows: 4, portrait: true},
  '1/9': {cols: 3, rows: 3, portrait: true},
  '1/20': {cols: 4, rows: 5, portrait: true}
};

async function sheetPdf(imgSrc, orientation, boardSize = '1/1', copies = 1) {
  const img = await imageLoad(imgSrc);
  const cfg = studioSizes[boardSize] || studioSizes['1/1'];
  const cols = cfg.cols, rows = cfg.rows;
  const perPage = cols * rows;
  const totalCopies = Math.max(1, Math.min(300, Number(copies) || 1));
  const totalPages = Math.ceil(totalCopies / perPage);

  const portrait = (boardSize === '1/1') ? (orientation === 'portrait') : cfg.portrait;
  const wmm = portrait ? 210 : 297, hmm = portrait ? 297 : 210;
  const pageW = Math.round(wmm * 6), pageH = Math.round(hmm * 6);

  const pages = [];
  let renderedCopies = 0;

  for (let p = 0; p < totalPages; p++) {
    const page = document.createElement('canvas');
    page.width = pageW;
    page.height = pageH;
    const ctx = page.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, pageW, pageH);

    const cellW = pageW / cols;
    const cellH = pageH / rows;
    const pad = Math.round(Math.min(cellW, cellH) * 0.02);

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (renderedCopies >= totalCopies) break;
        const cellX = c * cellW;
        const cellY = r * cellH;

        if (cols > 1 || rows > 1) {
          ctx.strokeStyle = '#cccccc';
          ctx.lineWidth = 1;
          ctx.setLineDash([4, 4]);
          ctx.strokeRect(cellX, cellY, cellW, cellH);
          ctx.setLineDash([]);
        }

        const drawAreaW = cellW - pad * 2;
        const drawAreaH = cellH - pad * 2;
        const factor = Math.min(drawAreaW / img.width, drawAreaH / img.height);
        const w = img.width * factor;
        const h = img.height * factor;
        const drawX = cellX + pad + (drawAreaW - w) / 2;
        const drawY = cellY + pad + (drawAreaH - h) / 2;

        ctx.drawImage(img, drawX, drawY, w, h);
        renderedCopies++;
      }
      if (renderedCopies >= totalCopies) break;
    }

    const jpeg = await new Promise((yes, no) =>
      page.toBlob(async b => b ? yes(new Uint8Array(await b.arrayBuffer())) : no(Error('PDF generation failed')), 'image/jpeg', 0.96)
    );
    pages.push({
      jpeg,
      wPt: wmm * 72 / 25.4,
      hPt: hmm * 72 / 25.4,
      wPx: pageW,
      hPx: pageH
    });
  }

  return jpegPdf(pages);
}

const blobToBase64 = blob => new Promise((resolve, reject) => {
  const r = new FileReader();
  r.onloadend = () => {
    const res = r.result;
    resolve(typeof res === 'string' ? res.split(',')[1] : '');
  };
  r.onerror = reject;
  r.readAsDataURL(blob);
});

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

function getAuthUser() {
  try {
    const raw = window.AUREMNative?.getSignedInUser?.();
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return { signedIn: false, email: '', displayName: '', photoUrl: '', idToken: '' };
}

export function mountStudio() {
  const root = S$('studioMount');
  if (!root) return;

  let concepts = [];
  let active = -1;
  let saved = [];
  let references = [];
  let designOption = 'A'; // 'A' = pure artwork, 'B' = editable product info
  let activeRenderedUrl = '';
  let busy = false;

  const overlayConfig = {
    productName: '',
    sp: '',
    mrp: '',
    offer: 'SPECIAL OFFER',
    badge: 'FRESH ARRIVAL',
    style: 'bottom-luxury' // bottom-luxury, top-bottom, badge-overlay, frame-gold
  };

  root.innerHTML = `
    <div class="studio-head">
      <div>
        <div class="studio-title"><span>✦ AUREM</span> AI Board Studio</div>
        <p class="studio-subtitle">Cloudflare FLUX.2 Klein 4B Engine · Creative Variations · Live Typography Overlay · Print-Ready</p>
      </div>
      <div id="studioAuthStatus" class="studio-auth-badge"></div>
    </div>

    <div id="studioAuthWarning" class="studio-auth-warning hidden">
      <div class="auth-warning-content">
        <strong>Google Sign-In Required for AI Studio</strong>
        <p>AUREM AI Board Studio connects to our Cloudflare FLUX.2 Klein 4B AI model and requires a verified Google account. Offline floor walks, CORE, and NON-CORE remain completely accessible offline without login.</p>
        <button type="button" id="studioSignInBtn" class="goldbtn compact-btn">Sign in with Google</button>
      </div>
    </div>

    <div class="studio-columns">
      <!-- COLUMN 1: Describe Board -->
      <section class="studio-panel">
        <h3>① Describe Your Board</h3>
        <textarea id="studioPrompt" placeholder="Describe the board and imagery you imagine — product, background, lighting, colors, promotional mood, scene composition... (e.g. Pure cow ghee golden jar on festive royal velvet with marigold flowers and diya)"></textarea>

        <label>Optional reference photo, logo or product image</label>
        <div class="studio-ref">
          <input id="studioRef" type="file" accept="image/jpeg,image/png,image/webp" multiple>
          <button type="button" id="studioClearRef">Remove all</button>
        </div>
        <div id="studioRefGallery" class="studio-ref-gallery"></div>
        <p class="mini">Select up to 5 optional photos (12 MB max each). References are compressed locally before transfer. Original AI generation works without photos.</p>

        <label>Actual board orientation</label>
        <select id="studioOrientation">
          <option value="landscape" selected>Landscape (Default)</option>
          <option value="portrait">Portrait</option>
        </select>

        <label>Creative direction</label>
        <select id="studioDirection">
          <option value="">Follow the prompt freely (no forced style)</option>
          <option value="luxury">Luxury & Premium</option>
          <option value="cinematic">Cinematic & Moody</option>
          <option value="energetic">Energetic & Vibrant</option>
          <option value="editorial">Editorial Clean</option>
          <option value="festive">Festive / Diwali Indian Retail</option>
          <option value="playful">Playful & Warm</option>
          <option value="minimal">Minimalist Modern</option>
        </select>

        <label>AI Generation Engine</label>
        <select id="studioModel">
          <option value="@cf/black-forest-labs/flux-2-klein-4b" selected>FLUX.2 Klein 4B (Default · Fast &amp; Balanced)</option>
          <option value="@cf/black-forest-labs/flux-1-schnell">FLUX.1 Schnell (Ultra Fast 4-Step · Text Only)</option>
          <option value="@cf/leonardo/lucid-origin">Leonardo Lucid Origin (Photorealistic Retail)</option>
          <option value="@cf/leonardo/phoenix-1.0">Leonardo Phoenix 1.0 (Creative &amp; Stylized Art)</option>
          <option value="@cf/black-forest-labs/flux-2-klein-9b">FLUX.2 Klein 9B (High Fidelity Commercial Detail)</option>
          <option value="@cf/black-forest-labs/flux-2-dev">FLUX.2 Dev (Maximum Flagship Quality)</option>
        </select>
        <p class="mini" id="studioModelNote">FLUX.2 Klein 4B generates original retail artwork in ~8-12 seconds and supports up to 4 reference photos.</p>

        <label>Concepts (each incurs 1 generation)</label>
        <select id="studioCount">
          <option value="1">1 concept</option>
          <option value="3" selected>3 distinct concepts</option>
          <option value="5">5 distinct concepts</option>
          <option value="10">10 distinct concepts</option>
        </select>

        <button id="studioGenerate" class="goldbtn" style="width:100%;margin-top:14px">✦ Generate Creative Concepts</button>
      </section>

      <!-- COLUMN 2: Concepts & Active Workspace -->
      <section class="studio-panel">
        <h3>② AI Generated Concepts</h3>
        <div id="studioConcepts" class="studio-concepts">
          <div class="studio-placeholder" style="grid-column:1/-1">Your original AI-created advertisements will appear here after generation.</div>
        </div>

        <div class="studio-workspace-header">
          <h3>Refined / Selected Artwork</h3>
          <!-- Option A vs Option B Toggle -->
          <div class="design-option-tabs" role="group" aria-label="Design layout option">
            <button type="button" id="btnOptionA" class="option-tab active" data-option="A">Option A: Artwork Unchanged</button>
            <button type="button" id="btnOptionB" class="option-tab" data-option="B">Option B: Editable Product Info</button>
          </div>
        </div>

        <!-- Option B Overlay Editor (Shown only when Option B is selected) -->
        <div id="optionBPanel" class="option-b-panel hidden">
          <div class="option-b-title">Live High-Contrast Typography &amp; Price Overlay</div>
          <div class="option-b-grid">
            <label class="field">Product Name
              <input type="text" id="optBName" placeholder="e.g. VIDHI COW GHEE 1 LT" autocomplete="off">
            </label>
            <div class="option-b-row">
              <label class="field">Selling Price ₹
                <input type="text" id="optBSp" inputmode="decimal" placeholder="599">
              </label>
              <label class="field">MRP ₹
                <input type="text" id="optBMrp" inputmode="decimal" placeholder="650">
              </label>
            </div>
            <div class="option-b-row">
              <label class="field">Offer Wording
                <input type="text" id="optBOffer" placeholder="e.g. BUY 1 GET 1 FREE or SPECIAL OFFER">
              </label>
              <label class="field">Badge / Subtext
                <input type="text" id="optBBadge" placeholder="e.g. 100% PURE · LIMITED STOCK">
              </label>
            </div>
            <div class="option-b-helpers">
              <button type="button" id="btnHelperB1G1" class="helper-btn">★ B1G1 (Buy 1 Get 1 Free)</button>
              <button type="button" id="btnHelperB1G2" class="helper-btn">★ B1G2 (Buy 1 Get 2 Free)</button>
            </div>
            <label class="field">Overlay Design Style
              <select id="optBStyle">
                <option value="bottom-luxury" selected>Bottom Luxury Gold Bar (Dark gradient, bold gold price, red tag)</option>
                <option value="top-bottom">Top Offer Ribbon + Bottom Price Bar</option>
                <option value="badge-overlay">Floating High-Contrast Floating Badges</option>
                <option value="frame-gold">Full Promotional Gold Border &amp; Header</option>
              </select>
            </label>
          </div>
        </div>

        <!-- Selected Artwork Stage -->
        <div id="studioSelected" class="studio-selected">
          <div class="studio-placeholder">Select a generated board to preview it.</div>
        </div>
        <canvas id="studioCanvas" class="hidden"></canvas>

        <div class="studio-print-config">
          <label class="field">Physical Board Size
            <select id="studioBoardSize">
              <option value="1/1" selected>1/1 • Full A4</option>
              <option value="1/2">1/2 • 2 per A4</option>
              <option value="1/3">1/3 • 3 per A4</option>
              <option value="1/4">1/4 • 4 per A4</option>
              <option value="1/8">1/8 • 8 per A4</option>
              <option value="1/9">1/9 • 9 per A4</option>
              <option value="1/20">1/20 • 20 per A4</option>
            </select>
          </label>
          <label class="field">Print Copies
            <input type="number" id="studioCopies" min="1" max="300" step="1" value="1">
          </label>
        </div>

        <div class="studio-actions">
          <button type="button" id="studioMore">Generate 3 more</button>
          <button type="button" id="studioSave">Save project</button>
          <button type="button" id="studioSaveImage" class="action-btn">Save Image</button>
          <button type="button" id="studioPdf" class="action-btn">Save PDF</button>
          <button type="button" id="studioPrint" class="action-btn">Print manually</button>
          <button type="button" id="studioShareWhatsApp" class="action-btn whatsapp-btn">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2zm0 18.12c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.106 8.106 0 0 1-1.25-4.35c0-4.48 3.65-8.13 8.14-8.13 2.17 0 4.22.85 5.75 2.39a8.09 8.09 0 0 1 2.38 5.75c0 4.49-3.65 8.14-8.13 8.14zm4.46-6.1c-.24-.12-1.45-.71-1.67-.79-.23-.08-.39-.12-.56.12-.17.24-.64.79-.79.95-.14.16-.29.18-.53.06-.24-.12-1.03-.38-1.96-1.21-.72-.65-1.21-1.45-1.35-1.69-.14-.24-.02-.37.1-.49.11-.11.24-.29.37-.43.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.56-1.35-.77-1.85-.2-.49-.41-.42-.56-.43h-.48c-.16 0-.43.06-.66.31-.23.24-.87.85-.87 2.08s.89 2.42 1.01 2.58c.12.16 1.75 2.67 4.24 3.74.59.26 1.06.41 1.42.52.6.19 1.14.16 1.57.1.48-.07 1.45-.59 1.66-1.16.2-.57.2-1.06.14-1.16-.06-.1-.22-.16-.46-.28z"/></svg>
            Share on WhatsApp
          </button>
        </div>
        <div id="studioStatus" class="studio-status">Ready. Describe your desired artwork and click Generate Creative Concepts.</div>
      </section>

      <!-- COLUMN 3: Edit with AI & Saved Boards -->
      <section class="studio-panel">
        <h3>③ Edit with AI (Chat)</h3>
        <p>Refine your selected board: make the lighting more dramatic, add festive marigold garlands, intensify colors, or adjust composition.</p>
        <textarea id="studioEditText" style="min-height:120px" placeholder="e.g. Make the background a deep midnight blue with floating golden embers, keep the ghee jar unchanged..."></textarea>
        <button type="button" id="studioEdit" class="goldbtn" style="width:100%">✦ Apply Creative Revision</button>

        <h3 style="margin-top:20px">Your saved boards</h3>
        <div id="studioSaved" class="studio-saved">
          <p class="quiet">No saved designs yet.</p>
        </div>
      </section>
    </div>

    <!-- Inspirations Gallery -->
    <div class="studio-examples">
      <div class="studio-example-title">✦ Original AI Artwork — Design Inspirations <small>Examples only · not generated for this session</small></div>
      <div class="studio-example-grid">
        <div><img src="review_previews/sample_festival.png" alt="Example Diwali fashion advertisement"><span>Festive Fashion</span></div>
        <div><img src="review_previews/sample_grocery.png" alt="Example original grocery ad"><span>Fresh Grocery</span></div>
        <div><img src="review_previews/sample_electronics.png" alt="Example electronics promo"><span>Futuristic Electronics</span></div>
        <div><img src="review_previews/sample_jewellery.png" alt="Example jewellery ad"><span>Luxury Jewellery</span></div>
        <div><img src="review_previews/sample_toys.png" alt="Example creative toy campaign"><span>Kids Toy Festival</span></div>
      </div>
    </div>

    <div class="studio-footer">
      AI creates original artwork with Cloudflare FLUX.2 Klein 4B from your creative words. With Option B, high-contrast store pricing and offer wording are rendered crisp and readable directly over the AI artwork for store printing. Offline floor walks (CORE and NON-CORE) remain completely local.
    </div>
  `;

  // Update authentication badge
  function updateAuthDisplay() {
    const auth = getAuthUser();
    const badge = S$('studioAuthStatus');
    const warning = S$('studioAuthWarning');
    if (!badge) return;

    if (auth.signedIn) {
      const name = auth.displayName || auth.email || 'Authenticated User';
      badge.innerHTML = `
        <span class="auth-user-chip">
          ${auth.photoUrl ? `<img src="${studioEsc(auth.photoUrl)}" class="auth-avatar" alt="Avatar">` : '👤'}
          <span>${studioEsc(name)}</span>
          <span class="quota-pill">FLUX.2 · Free Quota (10/day)</span>
        </span>
      `;
      badge.classList.remove('unauthenticated');
      warning?.classList.add('hidden');
    } else {
      badge.innerHTML = `<span class="auth-user-chip unauthenticated">○ Google Sign-In Required</span>`;
      badge.classList.add('unauthenticated');
      warning?.classList.remove('hidden');
    }
  }

  updateAuthDisplay();
  window.addEventListener('aurem-auth-changed', updateAuthDisplay);
  if (!window._auremAuthStudioHooked) {
    window._auremAuthStudioHooked = true;
    const origAuthChanged = window.onAuremAuthChanged;
    window.onAuremAuthChanged = user => {
      origAuthChanged?.(user);
      updateAuthDisplay();
    };
  }

  S$('studioSignInBtn')?.addEventListener('click', () => {
    window.AUREMNative?.requestGoogleSignIn?.();
  });

  function getSelectedConcept() {
    return concepts[active] || null;
  }

  // Live Canvas composite for Option B
  async function renderOptionBOverlay(sourceImgSrc) {
    const canvas = S$('studioCanvas');
    if (!canvas) return sourceImgSrc;
    const img = await imageLoad(sourceImgSrc);
    canvas.width = img.width || 1024;
    canvas.height = img.height || 1024;
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;

    // Draw background AI artwork
    ctx.drawImage(img, 0, 0, W, H);

    if (designOption !== 'B') {
      return canvas.toDataURL('image/jpeg', 0.95);
    }

    const name = (S$('optBName')?.value || overlayConfig.productName || '').trim();
    const sp = (S$('optBSp')?.value || overlayConfig.sp || '').trim();
    const mrp = (S$('optBMrp')?.value || overlayConfig.mrp || '').trim();
    const offer = (S$('optBOffer')?.value || overlayConfig.offer || '').trim();
    const badge = (S$('optBBadge')?.value || overlayConfig.badge || '').trim();
    const style = S$('optBStyle')?.value || overlayConfig.style;

    ctx.save();

    if (style === 'bottom-luxury' || style === 'top-bottom') {
      // Top Ribbon if top-bottom style or offer is present
      if (offer) {
        const ribbonH = Math.round(H * 0.08);
        const gradTop = ctx.createLinearGradient(0, 0, W, 0);
        gradTop.addColorStop(0, '#c62828');
        gradTop.addColorStop(0.5, '#e53935');
        gradTop.addColorStop(1, '#c62828');
        ctx.fillStyle = gradTop;
        ctx.shadowColor = 'rgba(0,0,0,0.6)';
        ctx.shadowBlur = 12;
        ctx.fillRect(0, 0, W, ribbonH);
        ctx.shadowBlur = 0;

        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.round(ribbonH * 0.48)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(offer.toUpperCase(), W / 2, ribbonH / 2);

        // Gold border under ribbon
        ctx.fillStyle = '#f5c542';
        ctx.fillRect(0, ribbonH - 3, W, 3);
      }

      // Bottom Bar for Product Name and Price
      const barH = Math.round(H * 0.28);
      const barY = H - barH;
      const gradBar = ctx.createLinearGradient(0, barY, 0, H);
      gradBar.addColorStop(0, 'rgba(10, 16, 26, 0.94)');
      gradBar.addColorStop(1, 'rgba(5, 8, 14, 0.98)');
      ctx.fillStyle = gradBar;
      ctx.fillRect(0, barY, W, barH);

      // Gold top accent line on bottom bar
      ctx.fillStyle = '#f5c542';
      ctx.fillRect(0, barY, W, 4);

      // Badge tag above product name
      let curY = barY + Math.round(barH * 0.16);
      if (badge) {
        ctx.fillStyle = '#f5c542';
        ctx.font = `bold ${Math.round(barH * 0.12)}px sans-serif`;
        ctx.textAlign = 'left';
        ctx.fillText(badge.toUpperCase(), W * 0.05, curY);
        curY += Math.round(barH * 0.16);
      }

      // Product Name
      if (name) {
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.round(barH * 0.22)}px sans-serif`;
        ctx.textAlign = 'left';
        ctx.fillText(name.toUpperCase(), W * 0.05, curY);
      }

      // Price block (Right aligned or bottom row)
      const priceY = barY + Math.round(barH * 0.65);
      if (sp) {
        // Selling Price in Gold
        ctx.fillStyle = '#f5c542';
        ctx.font = `900 ${Math.round(barH * 0.36)}px sans-serif`;
        ctx.textAlign = 'left';
        const spText = `₹ ${sp}`;
        ctx.fillText(spText, W * 0.05, priceY);

        const spWidth = ctx.measureText(spText).width;

        // MRP with strike-through
        if (mrp) {
          ctx.fillStyle = '#a0aec0';
          ctx.font = `bold ${Math.round(barH * 0.18)}px sans-serif`;
          const mrpX = W * 0.05 + spWidth + 24;
          const mrpText = `MRP ₹${mrp}`;
          ctx.fillText(mrpText, mrpX, priceY - Math.round(barH * 0.04));

          const mrpWidth = ctx.measureText(mrpText).width;
          ctx.strokeStyle = '#e53935';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(mrpX - 2, priceY - Math.round(barH * 0.09));
          ctx.lineTo(mrpX + mrpWidth + 2, priceY - Math.round(barH * 0.09));
          ctx.stroke();

          // Calculate and display savings
          const spNum = parseFloat(sp), mrpNum = parseFloat(mrp);
          if (mrpNum > spNum) {
            const saveAmount = (mrpNum - spNum).toFixed(0);
            ctx.fillStyle = '#48bb78';
            ctx.font = `bold ${Math.round(barH * 0.14)}px sans-serif`;
            ctx.fillText(`SAVE ₹${saveAmount}`, mrpX, priceY + Math.round(barH * 0.16));
          }
        }
      }
    } else if (style === 'frame-gold') {
      // Full frame with gold border
      ctx.strokeStyle = '#f5c542';
      ctx.lineWidth = Math.round(W * 0.02);
      ctx.strokeRect(ctx.lineWidth / 2, ctx.lineWidth / 2, W - ctx.lineWidth, H - ctx.lineWidth);

      // Top Offer Box
      if (offer) {
        const topH = Math.round(H * 0.12);
        ctx.fillStyle = 'rgba(12, 18, 30, 0.92)';
        ctx.fillRect(W * 0.1, W * 0.03, W * 0.8, topH);
        ctx.strokeStyle = '#f5c542';
        ctx.lineWidth = 2;
        ctx.strokeRect(W * 0.1, W * 0.03, W * 0.8, topH);

        ctx.fillStyle = '#f5c542';
        ctx.font = `bold ${Math.round(topH * 0.42)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(offer.toUpperCase(), W / 2, W * 0.03 + topH * 0.65);
      }

      // Bottom Details Pill
      const botH = Math.round(H * 0.22);
      const botY = H - botH - Math.round(W * 0.03);
      ctx.fillStyle = 'rgba(12, 18, 30, 0.94)';
      ctx.fillRect(W * 0.06, botY, W * 0.88, botH);
      ctx.strokeStyle = '#f5c542';
      ctx.lineWidth = 2;
      ctx.strokeRect(W * 0.06, botY, W * 0.88, botH);

      if (name) {
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.round(botH * 0.24)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(name.toUpperCase(), W / 2, botY + botH * 0.38);
      }

      if (sp) {
        ctx.fillStyle = '#f5c542';
        ctx.font = `900 ${Math.round(botH * 0.4)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(`₹ ${sp}  ${mrp ? `(MRP ₹${mrp})` : ''}`, W / 2, botY + botH * 0.82);
      }
    } else {
      // badge-overlay: floating badges with shadow
      if (offer) {
        const offW = Math.round(W * 0.45), offH = Math.round(H * 0.1);
        ctx.fillStyle = '#c62828';
        ctx.shadowColor = 'rgba(0,0,0,0.8)';
        ctx.shadowBlur = 15;
        ctx.fillRect(W * 0.05, H * 0.05, offW, offH);
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.round(offH * 0.45)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(offer.toUpperCase(), W * 0.05 + offW / 2, H * 0.05 + offH * 0.65);
      }

      if (sp) {
        const priceBoxW = Math.round(W * 0.5), priceBoxH = Math.round(H * 0.22);
        const pX = W * 0.05, pY = H * 0.72;
        ctx.fillStyle = 'rgba(12, 18, 30, 0.94)';
        ctx.shadowColor = 'rgba(0,0,0,0.8)';
        ctx.shadowBlur = 20;
        ctx.fillRect(pX, pY, priceBoxW, priceBoxH);
        ctx.shadowBlur = 0;
        ctx.strokeStyle = '#f5c542';
        ctx.lineWidth = 3;
        ctx.strokeRect(pX, pY, priceBoxW, priceBoxH);

        if (name) {
          ctx.fillStyle = '#ffffff';
          ctx.font = `bold ${Math.round(priceBoxH * 0.22)}px sans-serif`;
          ctx.textAlign = 'left';
          ctx.fillText(name.toUpperCase().slice(0, 24), pX + 20, pY + priceBoxH * 0.35);
        }

        ctx.fillStyle = '#f5c542';
        ctx.font = `900 ${Math.round(priceBoxH * 0.44)}px sans-serif`;
        ctx.textAlign = 'left';
        ctx.fillText(`₹ ${sp}`, pX + 20, pY + priceBoxH * 0.82);
      }
    }

    ctx.restore();
    return canvas.toDataURL('image/jpeg', 0.95);
  }

  async function updateActivePreview() {
    const sel = getSelectedConcept();
    const container = S$('studioSelected');
    if (!container) return;

    if (!sel) {
      container.innerHTML = '<div class="studio-placeholder">Select a generated board to preview it.</div>';
      activeRenderedUrl = '';
      return;
    }

    if (designOption === 'A') {
      container.innerHTML = `<img src="${sel.image}" alt="Selected artwork (Option A: Unchanged)">`;
      activeRenderedUrl = sel.image;
    } else {
      container.innerHTML = '<div class="studio-placeholder">Rendering Option B overlay…</div>';
      try {
        const compositeUrl = await renderOptionBOverlay(sel.image);
        activeRenderedUrl = compositeUrl;
        container.innerHTML = `<img src="${compositeUrl}" alt="Selected artwork (Option B: With Product Info)">`;
      } catch (err) {
        container.innerHTML = `<img src="${sel.image}" alt="Selected artwork">`;
        activeRenderedUrl = sel.image;
      }
    }
  }

  function renderConcepts() {
    const list = S$('studioConcepts');
    if (!list) return;
    list.innerHTML = concepts.length ? concepts.map((c, i) => `
      <div class="studio-concept ${i === active ? 'active' : ''}" data-sel="${i}">
        <img src="${c.image}" alt="AI concept ${i + 1}">
        <span class="label">Concept ${i + 1} · ${studioEsc(c.direction || 'Original')}</span>
      </div>
    `).join('') : '<div class="studio-placeholder" style="grid-column:1/-1">Your original AI-created advertisements will appear here after generation.</div>';

    updateActivePreview();
  }

  function renderSaved() {
    const el = S$('studioSaved');
    if (!el) return;
    el.innerHTML = saved.length ? saved.slice().reverse().map((x, i) => `
      <button type="button" data-saved="${saved.length - 1 - i}">
        <img src="${x.image}" alt="Saved creative">
        <span>${studioEsc(x.name || 'AI Creative Board').slice(0, 60)}<br><small>${studioEsc(x.orientation || 'landscape')} · ${new Date(x.createdAt || 0).toLocaleDateString('en-IN')}</small></span>
      </button>
    `).join('') : '<p class="quiet">No saved designs yet.</p>';
  }

  function renderReferences() {
    const gal = S$('studioRefGallery');
    if (!gal) return;
    gal.innerHTML = references.map((src, i) => `
      <div class="studio-ref-item">
        <img src="${src}" alt="Reference ${i + 1}">
        <button type="button" data-remove-ref="${i}" aria-label="Remove reference">×</button>
        <small>Ref ${i + 1}</small>
      </div>
    `).join('');
  }

  const modelNotes = {
    '@cf/black-forest-labs/flux-2-klein-4b': 'FLUX.2 Klein 4B generates original retail artwork in ~8-12 seconds and supports up to 4 reference photos.',
    '@cf/black-forest-labs/flux-1-schnell': 'FLUX.1 Schnell generates in 4 steps with prompt only (no dimensions or photos allowed).',
    '@cf/leonardo/lucid-origin': 'Leonardo Lucid Origin produces photorealistic retail scenes with crisp lighting.',
    '@cf/leonardo/phoenix-1.0': 'Leonardo Phoenix 1.0 creates high-impact creative and stylized commercial artwork.',
    '@cf/black-forest-labs/flux-2-klein-9b': 'FLUX.2 Klein 9B delivers deep fidelity and detailed product textures.',
    '@cf/black-forest-labs/flux-2-dev': 'FLUX.2 Dev is the flagship model for highest creative perfection.'
  };

  // Real backend call to Cloudflare AI Models
  async function generateAiArt(promptText, orientation, modelId = '@cf/black-forest-labs/flux-2-klein-4b') {
    const auth = getAuthUser();
    const idToken = auth.idToken || window.AUREMNative?.getGoogleIdToken?.() || '';

    // FLUX.1 Schnell strictly forbids reference images and dimensions
    const refsToSend = (modelId === '@cf/black-forest-labs/flux-1-schnell') ? [] : references.slice(0, 4);

    // First try the native bridge to bypass WebView CORS and memory limits
    if (window.AUREMNative?.generateAiArtwork) {
      const requestId = 'ai-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          if (window._auremAiPending?.id === requestId) {
            window._auremAiPending = null;
            reject(Error('Cloudflare AI request timed out after 130 seconds. Please retry.'));
          }
        }, 130000);

        window._auremAiPending = {
          id: requestId,
          resolve: dataUrl => {
            clearTimeout(timer);
            resolve(dataUrl);
          },
          reject: err => {
            clearTimeout(timer);
            reject(Error(err || 'Generation failed'));
          }
        };

        window.AUREMNative.generateAiArtwork(promptText, orientation, idToken, JSON.stringify(refsToSend), requestId, modelId);
      });
    }

    // Fallback: direct fetch (if running in desktop / test mode)
    const formData = new FormData();
    formData.append('prompt', promptText);
    formData.append('model', modelId);
    if (modelId !== '@cf/black-forest-labs/flux-1-schnell') {
      formData.append('width', orientation === 'portrait' ? '768' : '1024');
      formData.append('height', orientation === 'portrait' ? '1024' : '768');
      refsToSend.forEach((ref, idx) => {
        const arr = ref.split(',');
        const mime = arr[0].match(/:(.*?);/)[1];
        const bstr = atob(arr[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
        while (n--) u8arr[n] = bstr.charCodeAt(n);
        const blob = new Blob([u8arr], {type: mime});
        formData.append(`image_${idx}`, blob, `ref_${idx}.jpg`);
      });
    }

    const headers = {};
    if (idToken) headers['Authorization'] = `Bearer ${idToken}`;

    const res = await fetch('https://aurem-ai-test.grnpatan8953.workers.dev/generate', {
      method: 'POST',
      headers,
      body: formData
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => `HTTP ${res.status}`);
      throw Error(errText || `Generation failed (${res.status})`);
    }

    const blob = await res.blob();
    const b64 = await blobToBase64(blob);
    return `data:image/jpeg;base64,${b64}`;
  }

  // Hook native callback for AI generation
  window.onAuremAiGenerated = (requestId, success, dataUrl, errorMsg) => {
    const pending = window._auremAiPending;
    if (!pending || pending.id !== requestId) return;
    if (success && dataUrl) {
      pending.resolve(dataUrl);
    } else {
      pending.reject(errorMsg || 'AI Generation failed');
    }
    window._auremAiPending = null;
  };

  async function generateConcepts(extra = false) {
    if (busy) return;
    const auth = getAuthUser();
    if (!auth.signedIn) {
      note('Google Sign-In is required to generate AI artwork. Please sign in above.', true);
      window.AUREMNative?.requestGoogleSignIn?.();
      return;
    }

    const rawPrompt = S$('studioPrompt')?.value.trim() || '';
    if (rawPrompt.length < 8) {
      return note('Please describe the board and imagery you want (at least 8 characters).', true);
    }

    const count = extra ? 3 : parseInt(S$('studioCount')?.value || '1', 10);
    const orientation = S$('studioOrientation')?.value || 'landscape';
    const direction = S$('studioDirection')?.value || '';
    const directionLabel = S$('studioDirection')?.selectedOptions?.[0]?.textContent || '';
    const modelId = S$('studioModel')?.value || '@cf/black-forest-labs/flux-2-klein-4b';
    const modelLabel = S$('studioModel')?.selectedOptions?.[0]?.textContent?.split('(')[0]?.trim() || 'FLUX.2 Klein 4B';

    busy = true;
    if (S$('studioGenerate')) S$('studioGenerate').disabled = true;
    if (S$('studioMore')) S$('studioMore').disabled = true;

    try {
      if (!extra) {
        concepts = [];
        active = -1;
        renderConcepts();
      }

      for (let i = 0; i < count; i++) {
        note(`Creating concept ${i + 1} of ${count} with ${modelLabel}...`, false);

        let variationPrompt = rawPrompt;
        if (direction) variationPrompt += `, ${direction} style`;
        if (count > 1) {
          const seeds = ['high resolution commercial retail photography', 'vivid lighting, clean product showcase', 'dramatic promotional composition, rich textures', 'crisp studio presentation, vibrant colors'];
          variationPrompt += `, ${seeds[i % seeds.length]}`;
        }

        const dataUrl = await generateAiArt(variationPrompt, orientation, modelId);
        concepts.push({
          image: dataUrl,
          orientation,
          prompt: rawPrompt,
          direction: directionLabel,
          model: modelId,
          createdAt: Date.now()
        });
        active = concepts.length - 1;
        renderConcepts();
      }

      note(`Successfully generated ${count} original artwork ${count === 1 ? 'concept' : 'concepts'} with ${modelLabel}!`, false, true);
    } catch (err) {
      note('AI Generation error: ' + err.message, true);
    } finally {
      busy = false;
      if (S$('studioGenerate')) S$('studioGenerate').disabled = false;
      if (S$('studioMore')) S$('studioMore').disabled = false;
    }
  }

  // Listeners for inputs
  S$('studioGenerate')?.addEventListener('click', () => generateConcepts(false));
  S$('studioMore')?.addEventListener('click', () => generateConcepts(true));

  S$('studioConcepts')?.addEventListener('click', e => {
    const item = e.target.closest('[data-sel]');
    if (item) {
      active = parseInt(item.dataset.sel, 10);
      renderConcepts();
    }
  });

  // Option A vs Option B tabs
  S$('btnOptionA')?.addEventListener('click', () => {
    designOption = 'A';
    S$('btnOptionA')?.classList.add('active');
    S$('btnOptionB')?.classList.remove('active');
    S$('optionBPanel')?.classList.add('hidden');
    updateActivePreview();
  });

  S$('btnOptionB')?.addEventListener('click', () => {
    designOption = 'B';
    S$('btnOptionB')?.classList.add('active');
    S$('btnOptionA')?.classList.remove('active');
    S$('optionBPanel')?.classList.remove('hidden');
    updateActivePreview();
  });

  // Option B input changes live update
  ['optBName', 'optBSp', 'optBMrp', 'optBOffer', 'optBBadge', 'optBStyle'].forEach(id => {
    S$(id)?.addEventListener('input', () => {
      if (designOption === 'B') updateActivePreview();
    });
    S$(id)?.addEventListener('change', () => {
      if (designOption === 'B') updateActivePreview();
    });
  });

  // Reference photos handling
  S$('studioRef')?.addEventListener('change', async e => {
    try {
      const files = [...(e.target.files || [])];
      if (references.length + files.length > 4) {
        throw Error('FLUX.2 Klein 4B supports up to 4 reference photos. Maximum 4 photos allowed.');
      }
      for (const f of files) {
        references.push(await imageFile(f));
      }
      S$('studioRef').value = '';
      renderReferences();
      note(`${references.length} reference photo(s) added (supported limit: 4).`);
    } catch (err) {
      note(err.message, true);
    }
  });

  S$('studioRefGallery')?.addEventListener('click', e => {
    const btn = e.target.closest('[data-remove-ref]');
    if (!btn) return;
    const idx = parseInt(btn.dataset.removeRef, 10);
    references.splice(idx, 1);
    renderReferences();
  });

  S$('studioClearRef')?.addEventListener('click', () => {
    references = [];
    if (S$('studioRef')) S$('studioRef').value = '';
    renderReferences();
    note('All references removed.');
  });

  // Chat revision
  S$('studioEdit')?.addEventListener('click', async () => {
    if (busy) return;
    const sel = getSelectedConcept();
    if (!sel) return note('Select a generated concept first before applying revisions.', true);

    const revisionText = S$('studioEditText')?.value.trim() || '';
    if (revisionText.length < 4) {
      return note('Describe the creative revision you want to apply.', true);
    }

    const auth = getAuthUser();
    if (!auth.signedIn) {
      note('Google Sign-In is required to generate AI artwork.', true);
      window.AUREMNative?.requestGoogleSignIn?.();
      return;
    }

    busy = true;
    S$('studioEdit').disabled = true;
    try {
      const modelId = S$('studioModel')?.value || sel.model || '@cf/black-forest-labs/flux-2-klein-4b';
      note(`Applying creative revision with ${modelId.split('/').pop()}...`, false);
      const combinedPrompt = `${sel.prompt}. Creative revision: ${revisionText}`;
      const dataUrl = await generateAiArt(combinedPrompt, sel.orientation, modelId);

      concepts.push({
        image: dataUrl,
        orientation: sel.orientation,
        prompt: combinedPrompt,
        direction: 'AI Revision',
        model: modelId,
        createdAt: Date.now()
      });
      active = concepts.length - 1;
      renderConcepts();
      note('Revision concept created! Review the new artwork in the preview.', false, true);
    } catch (err) {
      note('Revision error: ' + err.message, true);
    } finally {
      busy = false;
      S$('studioEdit').disabled = false;
    }
  });

  // Save selected to IndexedDB — Full project persistence, no 40-item purge limit
  S$('studioSave')?.addEventListener('click', async () => {
    const sel = getSelectedConcept();
    if (!sel || !activeRenderedUrl) return note('Select an artwork first to save.', true);
    try {
      const boardSize = S$('studioBoardSize')?.value || '1/1';
      const copies = Number(S$('studioCopies')?.value) || 1;
      const currentOverlay = {
        productName: S$('optBName')?.value || '',
        sp: S$('optBSp')?.value || '',
        mrp: S$('optBMrp')?.value || '',
        offer: S$('optBOffer')?.value || '',
        badge: S$('optBBadge')?.value || '',
        style: S$('optBStyle')?.value || 'bottom-luxury'
      };
      saved.push({
        image: activeRenderedUrl,
        rawImage: sel.image,
        name: sel.prompt.slice(0, 70),
        prompt: sel.prompt,
        orientation: sel.orientation,
        model: sel.model || S$('studioModel')?.value || '@cf/black-forest-labs/flux-2-klein-4b',
        option: designOption,
        overlayConfig: currentOverlay,
        boardSize,
        copies,
        createdAt: Date.now()
      });
      await putKey('auremCreativeBoards', saved);
      renderSaved();
      note('Board artwork project saved permanently in AUREM.', false, true);
    } catch (err) {
      saved.pop();
      note('Save failed: ' + err.message, true);
    }
  });

  // Click saved board to restore
  S$('studioSaved')?.addEventListener('click', e => {
    const btn = e.target.closest('[data-saved]');
    if (!btn) return;
    const item = saved[parseInt(btn.dataset.saved, 10)];
    if (!item) return;
    concepts.push({
      image: item.rawImage || item.image,
      orientation: item.orientation || 'landscape',
      prompt: item.prompt || item.name || 'Saved Board',
      direction: 'Saved Project',
      model: item.model || '@cf/black-forest-labs/flux-2-klein-4b',
      createdAt: item.createdAt || Date.now()
    });
    active = concepts.length - 1;
    if (S$('studioOrientation')) S$('studioOrientation').value = item.orientation || 'landscape';
    if (S$('studioModel') && item.model) S$('studioModel').value = item.model;
    if (S$('studioBoardSize') && item.boardSize) S$('studioBoardSize').value = item.boardSize;
    if (S$('studioCopies') && item.copies) S$('studioCopies').value = item.copies;
    if (item.option) {
      designOption = item.option;
      if (item.option === 'B') {
        S$('btnOptionB')?.click();
        if (item.overlayConfig) {
          if (S$('optBName')) S$('optBName').value = item.overlayConfig.productName || '';
          if (S$('optBSp')) S$('optBSp').value = item.overlayConfig.sp || '';
          if (S$('optBMrp')) S$('optBMrp').value = item.overlayConfig.mrp || '';
          if (S$('optBOffer')) S$('optBOffer').value = item.overlayConfig.offer || '';
          if (S$('optBBadge')) S$('optBBadge').value = item.overlayConfig.badge || '';
          if (S$('optBStyle')) S$('optBStyle').value = item.overlayConfig.style || 'bottom-luxury';
        }
      } else {
        S$('btnOptionA')?.click();
      }
    }
    renderConcepts();
    note('Saved board project restored into active workspace.', false, true);
  });

  // Export Save Image
  S$('studioSaveImage')?.addEventListener('click', async () => {
    const sel = getSelectedConcept();
    if (!sel || !activeRenderedUrl) return note('Select an artwork first.', true);
    try {
      const fileName = `AUREM_AI_BOARD_${Date.now()}.jpg`;
      const base64Data = activeRenderedUrl.split(',')[1];
      if (window.AUREMNative?.saveFile) {
        window.AUREMNative.saveFile(base64Data, fileName, 'image/jpeg');
      } else {
        const blob = await (await fetch(activeRenderedUrl)).blob();
        downloadBlob(blob, fileName);
        note('Image saved to downloads.', false, true);
      }
    } catch (err) {
      note('Save Image failed: ' + err.message, true);
    }
  });

  // Export Save PDF with physical board size & copies
  S$('studioPdf')?.addEventListener('click', async () => {
    const sel = getSelectedConcept();
    if (!sel || !activeRenderedUrl) return note('Select an artwork first.', true);
    const boardSize = S$('studioBoardSize')?.value || '1/1';
    const copies = Number(S$('studioCopies')?.value) || 1;
    try {
      note(`Generating print-ready PDF (${boardSize} · ${copies} copies)...`, false);
      const pdfBlob = await sheetPdf(activeRenderedUrl, sel.orientation, boardSize, copies);
      const fileName = `AUREM_AI_BOARD_${boardSize.replace('/', '_')}_${Date.now()}.pdf`;
      const base64Data = await blobToBase64(pdfBlob);
      if (window.AUREMNative?.saveFile) {
        window.AUREMNative.saveFile(base64Data, fileName, 'application/pdf');
      } else {
        downloadBlob(pdfBlob, fileName);
        note('PDF saved to downloads.', false, true);
      }
    } catch (err) {
      note('Save PDF failed: ' + err.message, true);
    }
  });

  // Print manually with physical board size & copies
  S$('studioPrint')?.addEventListener('click', async () => {
    const sel = getSelectedConcept();
    if (!sel || !activeRenderedUrl) return note('Select an artwork first.', true);
    const boardSize = S$('studioBoardSize')?.value || '1/1';
    const copies = Number(S$('studioCopies')?.value) || 1;
    try {
      note(`Preparing ${copies} cop${copies === 1 ? 'y' : 'ies'} (${boardSize}) for print spooler...`, false);
      const pdfBlob = await sheetPdf(activeRenderedUrl, sel.orientation, boardSize, copies);
      const base64Data = await blobToBase64(pdfBlob);
      if (window.AUREMNative?.printPdf) {
        window.AUREMNative.printPdf(base64Data, `AUREM AI Board (${boardSize} · ${copies} pcs)`);
      } else {
        const url = URL.createObjectURL(pdfBlob);
        window.open(url, '_blank');
        setTimeout(() => URL.revokeObjectURL(url), 60000);
      }
    } catch (err) {
      note('Print setup failed: ' + err.message, true);
    }
  });

  // Share on WhatsApp with physical board size & copies
  S$('studioShareWhatsApp')?.addEventListener('click', async () => {
    const sel = getSelectedConcept();
    if (!sel || !activeRenderedUrl) return note('Select an artwork first.', true);
    const boardSize = S$('studioBoardSize')?.value || '1/1';
    const copies = Number(S$('studioCopies')?.value) || 1;
    try {
      note('Preparing board for WhatsApp sharing...', false);
      const pdfBlob = await sheetPdf(activeRenderedUrl, sel.orientation, boardSize, copies);
      const fileName = `AUREM_AI_BOARD_${Date.now()}.pdf`;
      const base64Data = await blobToBase64(pdfBlob);
      if (window.AUREMNative?.sharePdf) {
        window.AUREMNative.sharePdf(base64Data, fileName, 'whatsapp');
      } else {
        downloadBlob(pdfBlob, fileName);
        note('PDF downloaded; open WhatsApp to share.', false, true);
      }
    } catch (err) {
      note('Share failed: ' + err.message, true);
    }
  });

  // Option B uppercase and helper buttons
  if (S$('optBName')) attachAutoUppercase(S$('optBName'));

  S$('btnHelperB1G1')?.addEventListener('click', () => {
    if (S$('optBOffer')) S$('optBOffer').value = 'BUY 1 GET 1 FREE';
    const sp = parseFloat(S$('optBSp')?.value);
    if (!isNaN(sp) && sp > 0) {
      const half = (sp / 2).toFixed(2).replace(/\.00$/, '');
      if (S$('optBBadge')) S$('optBBadge').value = `EFFECTIVE ₹${half} / PCS`;
    }
    updateActivePreview();
  });

  S$('btnHelperB1G2')?.addEventListener('click', () => {
    if (S$('optBOffer')) S$('optBOffer').value = 'BUY 1 GET 2 FREE';
    const sp = parseFloat(S$('optBSp')?.value);
    if (!isNaN(sp) && sp > 0) {
      const third = (sp / 3).toFixed(2).replace(/\.00$/, '');
      if (S$('optBBadge')) S$('optBBadge').value = `EFFECTIVE ₹${third} / PCS`;
    }
    updateActivePreview();
  });

  S$('studioModel')?.addEventListener('change', () => {
    const m = S$('studioModel').value;
    if (S$('studioModelNote')) S$('studioModelNote').textContent = modelNotes[m] || '';
    const isSchnell = m === '@cf/black-forest-labs/flux-1-schnell';
    const refContainer = S$('studioRef')?.closest('.studio-ref');
    if (refContainer) {
      refContainer.classList.toggle('hidden', isSchnell);
    }
    if (isSchnell && references.length > 0) {
      note('Note: FLUX.1 Schnell is text-only; uploaded reference photos will not be sent.', false);
    }
  });

  // Load saved boards from IndexedDB
  getKey('auremCreativeBoards').then(v => {
    saved = Array.isArray(v) ? v : [];
    renderSaved();
  }).catch(() => {});
}
