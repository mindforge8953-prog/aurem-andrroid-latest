/* One durable AUREM product register: never modifies REG-STAT or daily prices. */
const KEY='auremVerifiedProductsV7';
let data=Object.create(null);
let queue=Promise.resolve();
function database(){return new Promise((ok,bad)=>{const r=indexedDB.open('AUREM_Offline_Data',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('data'))r.result.createObjectStore('data')};r.onsuccess=()=>ok(r.result);r.onerror=()=>bad(r.error)})}
export async function loadVerified(){const db=await database();try{const v=await new Promise((ok,bad)=>{const t=db.transaction('data');const r=t.objectStore('data').get(KEY);r.onsuccess=()=>ok(r.result||{});r.onerror=()=>bad(r.error)});data=v&&typeof v==='object'?v:Object.create(null);return data}finally{db.close()}}
export function verified(code){return data[String(code)]||null}
export function allVerified(){return Object.values(data)}
export function verifiedName(code,stockName){const v=verified(code);return v?.name||stockName}
export function verifiedChoice(code){const v=verified(code)||{};return {name:v.name||'',qty:v.qty||'',unit:v.unit||'',size:v.size||'1/8',copies:Number(v.copies)||1,pcs:v.pcs||'',underSize:v.underSize||'',homeSize:v.homeSize||'',infoPcs:!!v.infoPcs,infoUnder:!!v.infoUnder,infoHome:!!v.infoHome,infoWarranty:!!v.infoWarranty,warrantyDuration:v.warrantyDuration||'1',warrantyUnit:v.warrantyUnit||'YEAR',warrantyText:v.warrantyText||''}}
export function saveVerified(code,patch){code=String(code);if(!/^\d{9}$/.test(code))throw Error('Invalid permanent Bansal CODE');const old=verified(code)||{code,locations:[]};const record={...old,...patch,code,locations:old.locations||[],updatedAt:Date.now()};
 if(patch.location){const {rack,category}=patch.location;const loc={rack:String(rack||'').trim().toUpperCase(),category:String(category||'').trim().toUpperCase()};if(!loc.rack||!loc.category)throw Error('Rack and category are required');record.locations=[...record.locations.filter(x=>x.rack!==loc.rack),loc]}
 delete record.location;
 data[code]=record;
 const snapshot=structuredClone(data);
 queue=queue.catch(()=>{}).then(async()=>{const db=await database();try{await new Promise((ok,bad)=>{const t=db.transaction('data','readwrite');t.objectStore('data').put(snapshot,KEY);t.oncomplete=ok;t.onerror=()=>bad(t.error)})}finally{db.close()}});
 return queue.then(()=>{window.dispatchEvent(new CustomEvent('aurem-verified-updated',{detail:{code}}));return record});
}

export async function restoreVerified(records){if(!Array.isArray(records)||records.length>100000)throw Error('Invalid or oversized Audit backup');for(const entry of records){if(!entry||!/^\d{9}$/.test(entry.code))throw Error('Invalid Bansal CODE in backup');const {location,locations,updatedAt,...fields}=entry;
 if(Array.isArray(locations)&&locations.length>250)throw Error('Too many rack locations for '+entry.code);
 await saveVerified(entry.code,{...fields});for(const l of locations||[]){if(!l||!l.rack||!l.category)throw Error('Invalid rack entry in backup');await saveVerified(entry.code,{location:l})}}
 return records.length}
