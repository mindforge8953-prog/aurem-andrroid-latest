/* Obsolete selective clear UI safely removed to protect user data from deletion. */
export function mountAdmin() {
  const holder = document.getElementById('adminMount');
  if (holder) {
    holder.innerHTML = '';
  }
}
