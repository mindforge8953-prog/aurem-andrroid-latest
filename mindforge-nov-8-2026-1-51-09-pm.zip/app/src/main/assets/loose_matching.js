/* AUREM Loose Grocery meanings. Conservative, explainable matching; NO silent guess.
   Confirmed code->WordArt mappings are always the authority. */
export const normalizeLoose=s=>String(s||'').toUpperCase().replace(/\b(LOOSE|L[.\s]|BULK|NOS|NO|KG|KGS|GRAM|GMS|PACK|PKT|PCS|PIECE|FRESH|STORE|1|2|3)\b/g,' ').replace(/[^A-Z0-9\u0A80-\u0AFF]+/g,' ').replace(/\s+/g,' ').trim();
const ALIASES=[
 ['WHEAT FLOUR',['ATTA','AATA','GHAU NO ATO','ઘઉંનો આટો','GHAV NO ATO','WHEAT ATTA']],
 ['BAJARI FLOUR',['BAJRA ATTA','BAJRI ATTA','BAJRI NO ATO','BAJARI ATTA']],
 ['BESAN',['GRAM FLOUR','CHANA FLOUR','CHICKPEA FLOUR']],
 ['SOOJI',['SUJI','RAVA','RAWA','SEMOLINA']],
 ['MAIDA',['REFINED FLOUR','REFINED WHEAT FLOUR']],
 ['LOOSE SUGAR',['SUGAR','SAKAR','SAKKAR','KHAND']],
 ['POHA',['PAUVA','PAUHA','FLATTENED RICE']],
 ['L.MASUR DALL',['MASOOR DAL','MASOOR DALL','MASUR DAL']],
 ['L.MOONG DALL',['MUNG DAL','MOONG DAL','MUNG DALL']],
 ['L.CHANA DALL',['CHANA DAL','CHANA DALL','CHANA DAAL']],
 ['L.TOOR DALL OILY DESHI',['TUVAR DAL','TOOR DAL','TUR DAL']],
 ['L.JUVAR',['JOWAR','JOWARI','SORGHUM']],
 ['L.SABUDANA',['SAGO','SABU DANA']],
 ['L.GREEN PEAS',['VATANA GREEN','DRIED GREEN PEAS']],
 ['LOOSE VATANA WHITE',['WHITE VATANA','SAFED VATANA','WHITE PEAS']],
 ['L.JEERA',['CUMIN','CUMIN SEEDS']],
 ['L.MAKHANA',['FOX NUT','LOTUS SEEDS']],
 ['L.SOYABEAN WADI',['SOYA CHUNKS','SOYA WADI']],
 ['L.FRYMS',['FRYUMS','FRYUM']]
];
const words=s=>new Set(normalizeLoose(s).split(' ').filter(x=>x.length>1));
function similar(a,b){const aa=words(a),bb=words(b);if(!aa.size||!bb.size)return 0;let intersection=0;for(const word of aa)if(bb.has(word))intersection++;return intersection/Math.max(aa.size,bb.size)}
export function looseCandidates(stockName, catalog, searchMachine=''){
 const raw=normalizeLoose(stockName),out=[];
 for(const board of catalog){const nm=normalizeLoose(board.name);let score=similar(stockName,board.name),reasons=[];
  if(raw&&raw===nm){score=1;reasons.push('exact normalized product name');}
  else if(raw.length>=5&&nm.length>=5&&(raw.includes(nm)||nm.includes(raw))){score=Math.max(score,.84);reasons.push('partial product name');}
  for(const [canonical,terms] of ALIASES){if(normalizeLoose(canonical)!==nm)continue;
   for(const term of terms){const tag=normalizeLoose(term);if(tag&&((raw===tag)||(raw.includes(tag)&&tag.length>=4))){score=Math.max(score,raw===tag?.98:.86);reasons.push('known grocery synonym: '+term);}}
  }
  if(searchMachine&&String(Number(board.machineCode))===String(Number(searchMachine))){score=1;reasons.push('exact original machine code');}
  if(score>=.34)out.push({board,score:Number(score.toFixed(3)),reason:reasons.join('; ')||'product words overlap'});
 }
 // Return candidates ordered; never automatically confirm even a single unverified semantic match.
 return out.sort((a,b)=>b.score-a.score||a.board.index-b.board.index).slice(0,10);
}
