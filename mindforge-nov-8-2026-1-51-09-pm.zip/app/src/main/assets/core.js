/* AUREM — pure deterministic product, price, and barcode logic. No demo records. */
export const norm = s => String(s??'').replace(/^\uFEFF/,'').trim().toUpperCase().replace(/[\s_.-]+/g,' ');
const exact=(row,names)=>{const heads=row.map(norm);for(const name of names){const i=heads.indexOf(norm(name));if(i>=0)return i;}return -1};

// R-Soft exports sometimes contain stray unescaped quotes inside names (e.g., 14" SILICON WIPER).
// Begin a quoted CSV field only when the field starts with a double quote.
export function parseDelimited(text,delimiter=','){
 if(delimiter!==','&&delimiter!=='\t')throw Error('Unsupported text delimiter.');
 const out=[];let row=[],field='',quoted=false,after=false,wasQuoted=false;const s=String(text??'').replace(/^\uFEFF/,'');
 const end=()=>{row.push(wasQuoted?field:field.trim());field='';after=false;wasQuoted=false};
 const line=()=>{end();if(row.some(v=>v!==''))out.push(row);row=[]};
 for(let i=0;i<s.length;i++){
  const c=s[i];if(quoted){if(c==='"'){if(s[i+1]==='"'){field+='"';i++}else{quoted=false;after=true}}else field+=c;}
  else if(c==='"'&&field.trim()===''&&!after){quoted=true;wasQuoted=true;field='';}
  else if(c===delimiter)end();
  else if(c==='\n'||c==='\r'){if(c==='\r'&&s[i+1]==='\n')i++;line();}
  else if(after&&/\s/.test(c)){}else{field+=c;after=false;}
 }
 if(quoted)throw Error('An unclosed quoted field was detected.');
 if(field!==''||row.length)line();return out;
}
export const parseCSV=text=>parseDelimited(text,',');
export function detectTextEncoding(bytes){
 const b=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);if(b.length>=3&&b[0]===0xef&&b[1]===0xbb&&b[2]===0xbf)return'utf-8';if(b.length>=2&&b[0]===0xff&&b[1]===0xfe)return'utf-16le';if(b.length>=2&&b[0]===0xfe&&b[1]===0xff)return'utf-16be';
 const n=Math.min(b.length,65536);let evenZero=0,oddZero=0;for(let i=0;i<n;i++){if(b[i]===0){if(i&1)oddZero++;else evenZero++;}}const evenRate=evenZero/Math.max(1,Math.ceil(n/2)),oddRate=oddZero/Math.max(1,Math.floor(n/2));if(oddRate>.12&&oddRate>evenRate*3)return'utf-16le';if(evenRate>.12&&evenRate>oddRate*3)return'utf-16be';
 const sample=b.subarray(0,n-(n%2)),controlCount=text=>{let c=0;for(let i=0;i<text.length;i++){const x=text.charCodeAt(i);if((x<32&&x!==9&&x!==10&&x!==13)||x===127)c++;}return c;},pairEvidence=little=>{let c=0;for(let i=0;i+1<sample.length;i+=2){const x=little?sample[i]|(sample[i+1]<<8):(sample[i]<<8)|sample[i+1];if(x===9||x===10||x===13||x===34||x===44||x===59)c++;}return c;},tryDecode=encoding=>{try{return new TextDecoder(encoding,{fatal:true}).decode(sample)}catch{return null}};
 const utf8=tryDecode('utf-8');if(utf8!==null){const controls=controlCount(utf8);if(controls>Math.max(3,utf8.length*.015)){for(const [encoding,little] of [['utf-16le',true],['utf-16be',false]]){const candidate=tryDecode(encoding);if(candidate!==null&&pairEvidence(little)>=2&&controlCount(candidate)<Math.max(3,candidate.length*.01)&&candidate.length>utf8.length*.4)return encoding;}}return'utf-8';}
 for(const [encoding,little] of [['utf-16le',true],['utf-16be',false]]){const candidate=tryDecode(encoding);if(candidate!==null&&candidate.length>0&&pairEvidence(little)>=2&&controlCount(candidate)<Math.max(3,candidate.length*.01))return encoding;}
 return'windows-1252';
}const expandNumericText=raw=>{const m=/^(\d+)(?:\.(\d*))?[eE]([+-]?\d+)$/.exec(String(raw??'').trim());if(!m)return String(raw??'').trim();const whole=m[1],frac=m[2]||'',exp=Number(m[3]);if(!Number.isInteger(exp)||Math.abs(exp)>100)return String(raw??'').trim();const digits=whole+frac,point=whole.length+exp;if(point<=0)return'0.'+'0'.repeat(-point)+digits;if(point>=digits.length)return digits+'0'.repeat(point-digits.length);return digits.slice(0,point)+'.'+digits.slice(point);};
export const normalizeBansal=raw=>{let s=expandNumericText(raw).replace(/^'+/,'');if(/^\d+(?:\.0+)?$/.test(s))s=s.replace(/\.0+$/,'');return /^\d{1,9}$/.test(s)?s.padStart(9,'0'):s};
export const barcodeText=v=>expandNumericText(v).replace(/^'+/,'');const f={code:['CODE','BANSAL CODE','BANSAL ITEM CODE','ITEM CODE','PRODUCT CODE'],name:['ITEM NAME','ITEMNAME','PRODUCT NAME','PRODUCT DESCRIPTION'],mrp:['MRP','M.R.P.','M.R.P','MAX RETAIL PRICE','MAXIMUM RETAIL PRICE'],retail:['RETAIL','SELLING PRICE','SELLING RATE','SP','S.P.','SALE RATE','SALES RATE','RETAIL PRICE','RETAIL RATE'],barcode:['BAR CODE','BARCODE','BAR CODE NO','BARCODE NO','BARCODE NUMBER','EAN','EAN NO','EAN CODE','ITEM BARCODE','PRODUCT BARCODE'],ean:['EAN','EAN/UPC','EAN CODE','BAR CODE','BARCODE','BAR CODE NO','BARCODE NO']};
export function sniffRows(rows,type){
 const limit=Math.min(rows.length,3000);let best=null,bestScore=-1;
 for(let i=0;i<limit;i++){
  const r=rows[i];if(!Array.isArray(r))continue;const code=exact(r,f.code),name=exact(r,f.name),mrp=exact(r,f.mrp),retail=exact(r,f.retail),ean=exact(r,f.ean);
  if(type==='stock'&&code>=0&&name>=0&&mrp>=0&&retail>=0){
   const fields={code,name,mrp,retail,cost:exact(r,['COST','UNIT COST','PUR. RATE','PUR RATE','PURCHASE RATE','PUR. PRICE','PURCHASE PRICE','PUR COST','PURCHASE COST','LANDED COST','NET RATE','RATE','COST RATE','COST PRICE','CP']),barcode:exact(r,f.barcode),opening:exact(r,['OPENING QTY','OPENING QUANTITY','OPENING STOCK','OP. QTY','OP QTY','OP. STOCK','OP STOCK','OPENING BALANCE','OP BAL','OPENING']),stock:exact(r,['CLOSING QTY','CLOSING STOCK','CLOSING QUANTITY','AVAILABLE STOCK','AVAIL STOCK','STOCK QTY','BALANCE QTY','BAL QTY','QTY IN HAND','STOCK IN HAND','STOCK BALANCE','BALANCE STOCK','STOCK QUANTITY','CURRENT STOCK','CL. QTY','CL QTY','CL. STOCK','CL STOCK','STOCK','QUANTITY','QTY']),stockUnit:exact(r,['STOCK UNIT','QTY UNIT','QUANTITY UNIT','UOM','UNIT']),supplier:exact(r,['SUPPLIER','SUPPLIER NAME','VENDOR','VENDOR NAME','PARTY','PARTY NAME','SUPP NAME','SUPP. NAME','MANUFACTURER','COMPANY','ACCOUNT NAME']),lastPurDate:exact(r,['LAST PUR DATE','LAST PURCHASE DATE','LAST PURCH DATE','LAST PURCHASED DATE','LAST PUR. DATE','LAST PUR DT','LAST PUR. DT','L.P. DATE','LP DATE','PUR DATE','PURCHASE DATE']),main:exact(r,['MAIN CODE']),category:exact(r,['CATEGORY']),group:exact(r,['GROUP']),subgroup:exact(r,['SUB-GROUP','SUB GROUP']),brand:exact(r,['BRAND'])};
   const score=Object.values(fields).filter(x=>x>=0).length+(fields.main>=0?3:0)+(fields.barcode>=0?2:0)+(fields.stock>=0?2:0);if(score>bestScore){best={header:i,cols:fields};bestScore=score;}
  }
  if(type==='eans'&&code>=0&&ean>=0){const cols={code,ean};const score=2+(exact(r,['BAR CODE','BARCODE'])>=0?1:0);if(score>bestScore){best={header:i,cols};bestScore=score;}}
  if(['focus','permanent'].includes(type)&&code>=0)return{header:i,cols:{code}};
 }
 if(best)return best;
 if(['focus','permanent'].includes(type)&&rows.filter(r=>r.length===1&&/^\d{6,9}$/.test(String(r[0]??'').trim())).length)return{header:-1,cols:{code:0}};
 throw Error(type==='stock'?'REG-STAT header not found. Expected CODE, ITEM NAME, MRP and RETAIL columns.':type==='eans'?'ITEM_EANS header not found. Expected permanent CODE and EAN/barcode columns.':`No product CODE column found for ${type}.`);
 }
export function parseEanMappings(eanRows){
 const eh=sniffRows(eanRows,'eans'),out=[],invalidRows=[];
 const rowsSlice=eanRows.slice(eh.header+1);
 for(let idx=0;idx<rowsSlice.length;idx++){
  const r=rowsSlice[idx];
  if(!Array.isArray(r)||!r.length)continue;
  const rawCode=r[eh.cols.code],rawEan=r[eh.cols.ean],code=normalizeBansal(rawCode),ean=barcodeText(rawEan);
  if(/^\d{9}$/.test(code)&&ean&&/^\d{5,18}$/.test(ean)){
   out.push({code,ean,row:eh.header+2+idx});
  }else if(rawCode||rawEan){
   invalidRows.push({row:eh.header+2+idx,rawCode,rawEan,reason:!/^\d{9}$/.test(code)?'Invalid Bansal CODE':'Invalid EAN barcode'});
  }
 }
 out.invalidRows=invalidRows;
 out.totalProcessed=rowsSlice.length;
 return out;
}
export function makeMaster(stockRows,eanRows=[],allowEmptyEans=false){
  const h=sniffRows(stockRows,'stock'),eh=eanRows?.length?sniffRows(eanRows,'eans'):null,products=Object.create(null),lookups=Object.create(null),warnings=[];
 let skipped=0,orphans=0,eanRowsCount=0;
 const link=(v,code)=>{const k=barcodeText(v);if(!k)return;const m=lookups[k]??(lookups[k]=[]);if(!m.includes(code))m.push(code)};
 for(const r of stockRows.slice(h.header+1)){
  const raw=r[h.cols.code];if(raw===undefined||String(raw).trim()==='')continue;
  const code=normalizeBansal(raw);if(!/^\d{9}$/.test(code)){skipped++;continue;}
  if(products[code])throw Error(`Duplicate stock CODE ${code}. Import stopped.`);
  const cell=k=>k<0?'':String(r[k]??'').trim();if(!cell(h.cols.name)){skipped++;continue;}
  const p={code,name:cell(h.cols.name),barcode:cell(h.cols.barcode),mrp:cell(h.cols.mrp),retail:cell(h.cols.retail),cost:cell(h.cols.cost),supplier:cell(h.cols.supplier),lastPurDate:cell(h.cols.lastPurDate),openingStock:h.cols.opening>=0?cell(h.cols.opening):null,stock:h.cols.stock>=0?cell(h.cols.stock):null,stockUnit:h.cols.stockUnit>=0?cell(h.cols.stockUnit):'',stockColumn:h.cols.stock>=0?String(stockRows[h.header][h.cols.stock]):'',main:cell(h.cols.main),category:cell(h.cols.category),group:cell(h.cols.group),subgroup:cell(h.cols.subgroup),brand:cell(h.cols.brand)};
  products[code]=p;link(code,code);link(p.barcode,code);
 }
 const productCount=Object.keys(products).length;if(!productCount)throw Error('No products found in REG-STAT.');
  if(eh)for(const {code,ean} of parseEanMappings(eanRows)){eanRowsCount++;if(!products[code]){orphans++;continue;}link(ean,code)}
  if(!eanRowsCount&&!allowEmptyEans)throw Error('ITEM_EANS contains no barcode mappings.');
 const conflicts=Object.entries(lookups).filter(([,codes])=>codes.length>1).map(([barcode,codes])=>({barcode,codes}));
 if(skipped)warnings.push(`${skipped} stock rows were skipped for invalid CODE or blank ITEM NAME`);
 if(orphans)warnings.push(`${orphans} EAN rows refer to products missing from stock`);
 if(conflicts.length)warnings.push(`${conflicts.length} conflicting barcode mapping(s)`);
 const columnName=i=>i>=0?String(stockRows[h.header][i]??'').trim():'not found';const mapping={headerRow:h.header+1,code:columnName(h.cols.code),name:columnName(h.cols.name),barcode:columnName(h.cols.barcode),opening:columnName(h.cols.opening),stock:columnName(h.cols.stock),mrp:columnName(h.cols.mrp),retail:columnName(h.cols.retail),cost:columnName(h.cols.cost),supplier:columnName(h.cols.supplier),lastPurDate:columnName(h.cols.lastPurDate)};return{products,lookups,productCount,mappingRows:eanRowsCount,orphans,skipped,conflicts,warnings,mapping};
}
const productSearchCache=new WeakMap();
export function productMatches(master,code,query,extraNames=[]){
 const q=String(query??'').trim().toLocaleLowerCase();if(!q)return false;
 let index=productSearchCache.get(master);
 if(!index){index=new Map(Object.entries(master.products||{}).map(([c,p])=>[c,[c,p.name,p.barcode].filter(Boolean).join(' ').toLocaleLowerCase()]));for(const [barcode,codes]of Object.entries(master.lookups||{}))for(const c of codes){if(index.has(c))index.set(c,index.get(c)+' '+barcode.toLocaleLowerCase())}productSearchCache.set(master,index)}
 return(index.get(String(code))||'').includes(q)||extraNames.some(n=>String(n||'').toLocaleLowerCase().includes(q));
}export function resolveCode(raw,master,overrides={}){
 const barcode=barcodeText(raw);if(!barcode)return{status:'UNKNOWN',barcode};
 const maps=new Set(master.lookups[barcode]||[]);
 // A stripped-leading-zero code is permissible ONLY when it uniquely matches a real Bansal code.
 if(/^\d{1,8}$/.test(barcode)){const c=normalizeBansal(barcode);if(master.products[c])maps.add(c);}
 if(/^\d{12}$/.test(barcode))for(const c of master.lookups['0'+barcode]||[])maps.add(c);
 const verified=overrides[barcode];if(verified&&master.products[verified])return{status:'MATCH',barcode,code:verified,product:master.products[verified],manual:true};
 const codes=[...maps];if(codes.length>1)return{status:'AMBIGUOUS',barcode,candidates:codes};
 if(codes.length===1&&master.products[codes[0]])return{status:'MATCH',barcode,code:codes[0],product:master.products[codes[0]]};
 return{status:'UNKNOWN',barcode};
}
export function parseMembership(rows,type){const {header,cols}=sniffRows(rows,type);const s=new Set();for(const r of rows.slice(header+1)){const code=normalizeBansal(r[cols.code]);if(/^\d{9}$/.test(code))s.add(code)}if(!s.size)throw Error(`${type} file has no CODEs`);return [...s];}
export function parseMoneyCents(raw){const s=String(raw??'').trim().replace(/^[₹\s]+/,'').replace(/,/g,'');if(!/^\d+(?:\.\d{1,2})?$/.test(s))return null;const [a,b='']=s.split('.');const n=Number(a)*100+Number((b+'00').slice(0,2));return Number.isSafeInteger(n)?n:null;}
export const money=c=>c===null?'—':(c/100).toLocaleString('en-IN',{minimumFractionDigits:c%100===0?0:2,maximumFractionDigits:2});
const any=(txt,re)=>re.test(norm(txt));
// The term FOOD alone must NOT cause ONLY: e.g. Weikfield Cocoa is FOOD but ₹ OFF.
export function productClass(p){
 const n=norm(p.name),data=norm([p.main,p.category,p.group,p.subgroup,p.brand].join(' '));
 const hair=/(?:\bHAIR\b|\bSHAMPOO\b|\bBODY\b|\bAMLA\b|\bCOCONUT HAIR\b|\bROSEMARY\b|\bMASSAGE\b|\bCOSMETIC\b)/.test(n+' '+data);
 const edibleOil=!hair&&(/\b(?:EDIBLE|COOKING|REFINED|SUNFLOWER|GROUNDNUT|MUSTARD|SOYABEAN|SOYBEAN|RICE BRAN|OLIVE OIL|SESAME OIL|PALM OIL|VEGETABLE OIL)\b/.test(n+' '+data)&&/\bOIL\b/.test(n+' '+data) || /\b(?:EDIBLE OIL|COOKING OIL)\b/.test(data));
 const processed=/\b(?:NAMKEEN|SNACKS|BISCUIT|BAKERY|CHOCOLATE|CONFECTIONERY|CUSTARD|MUKHVAS|HAIR CARE|SHAMPOO|BODY WASH|COOKIES|WAFERS|CHOCOLATES|SOAP|DETERGENT|SHMP)\b/.test(n+' '+data);
 const rawGroceryBase=/\b(?:CHANA DAL|MIX DAL|MOONG DAL|TOOR DAL|TUVAR DAL|URAD DAL|MASOOR DAL|MATH|MOTH|CHICKPEA|BAJRA|JOWAR|WHEAT|ATTA|MAIDA|BESAN|RAWA|SOOJI|RICE|SUGAR|RAJMA|KABULI CHANA|CHANA|PULSES|GRAINS|DRY FRUIT|DRYFRUIT|KAJU|BADAM|ALMOND|CASHEW|PISTA|AKHROT)\b/.test(n+' '+data) || /\b(?:PACK GROCERY|PACKED GROCERY|DRY FRUIT|DRYFRUITS|PULSES|RAW GROCERY|GRAINS)\b/.test(data);
 const rawGrocery=rawGroceryBase&&!processed;
 const ghee=/\bGHEE\b/.test(n+' '+data);
 // no PER NOS for razors, soaps, tissues, toothbrushes, biscuit packs.
 const countable=/\b(?:PAMPERS|DIAPER|DIAPERS|SANITARY|NAPKIN|PADS|PANTY LINER|BABY PANTS)\b/.test(n+' '+data);
 return{edibleOil,rawGrocery,ghee,countable,onlyCategory:edibleOil||rawGrocery||ghee};
}
export function boardFormat(p,permCodes=new Set(),focusCodes=new Set()){
 const m=parseMoneyCents(p.mrp),s=parseMoneyCents(p.retail),focus=focusCodes.has(p.code),permanent=permCodes.has(p.code),kind=productClass(p);
 if(m===null||m<=0||s===null||s<=0||s>=m)return{format:'REVIEW',error:true,focus,permanent,kind,detail:'Check MRP and RETAIL: both must be positive and SP below MRP.'};
 const diff=m-s;let format;
 if(BigInt(s)*3n===BigInt(m))format='B1G2';
 else if(BigInt(s)*2n===BigInt(m))format='B1G1';
 else if(diff>=100&&diff<=300)format='ONLY';
 else if(permanent)format='% OFF';
 else if(BigInt(s)*2n<BigInt(m))format='ONLY';
 else if(kind.onlyCategory)format='ONLY';
 else format='₹ OFF';
 let value='',detail='';if(format==='B1G1'||format==='B1G2')detail=`₹${money(s)} PER PCS`;
 if(format==='₹ OFF'){value=money(diff);detail=`₹${value} OFF`}
 if(format==='% OFF'){const hundredths=Number(BigInt(diff)*10000n/BigInt(m));value=Math.floor(hundredths/100);detail=`${value}% OFF`}
 if(format==='ONLY'){value=money(s);detail=`₹${value} ONLY`}
 return{format,error:false,focus,permanent,kind,detail,value,mrpCents:m,spCents:s,diffCents:diff,hideMrp:format==='ONLY'&&kind.edibleOil};
}
// The total entered quantity overrides all inferred package amounts for THIS floor walk.
const decimalParts=raw=>{const m=/^(\d+)(?:\.(\d+))?$/.exec(String(raw??'').trim());if(!m)return null;const digits=m[2]||'',den=10n**BigInt(digits.length);return{num:BigInt(m[1]+digits),den}};
const decimalString=(num,den)=>{let scale=1n,places=0;while(num%den!==0n&&places<12){num*=10n;scale*=10n;places++;}let whole=(num/den).toString();if(!places)return whole;whole=whole.padStart(places+1,'0');const at=whole.length-places;return whole.slice(0,at)+'.'+whole.slice(at).replace(/0+$/,'').replace(/\.$/,'')};
const multiplyDecimal=(a,b)=>{const x=decimalParts(a),y=decimalParts(b);return decimalString(x.num*y.num,x.den*y.den)};
function normalizedMeasure(qty,unit){const u=String(unit).toUpperCase();if(['G','GM','GMS','GRAM','GRAMS'].includes(u))return{qty:decimalString(decimalParts(qty).num,decimalParts(qty).den*1000n),unit:'KG'};if(['ML'].includes(u))return{qty:decimalString(decimalParts(qty).num,decimalParts(qty).den*1000n),unit:'LTR'};if(['KG','KGS'].includes(u))return{qty,unit:'KG'};if(['LTR','LT','LTS','LITRE','LITRES','L'].includes(u))return{qty,unit:'LTR'};return{qty,unit:u}}
// Report total net quantity per sellable item; a multipack price already covers its full combined quantity.
export function inferPack(product){
 const raw=String(product?.name??'').toUpperCase(),n=norm(raw),c=productClass(product);
 if(c.countable){const m=n.match(/(?:\bM\s?(\d{2,3})\b|\b(\d{2,3})\s?(?:PANTS|PADS|DIAPERS|NOS|NAPS)\b)/);if(m)return{qty:m[1]||m[2],unit:'NOS',source:'name'};}
 const units='KGS?|G|GMS?|GRAMS?|LTR|LTS?|LT|LITRES?|L|ML';let m=[...raw.matchAll(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*[x×]\\s*(\\d+(?:\\.\\d+)?)\\s*(${units})\\b`,'gi'))].at(-1);if(m){const total=multiplyDecimal(m[1],m[2]);return{...normalizedMeasure(total,m[3]),source:'name-multipack'}}
 m=[...raw.matchAll(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*(${units})\\s*[x×]\\s*(\\d+(?:\\.\\d+)?)`,'gi'))].at(-1);if(m)return{...normalizedMeasure(multiplyDecimal(m[1],m[3]),m[2]),source:'name-multipack'};
 const pairs=[...raw.matchAll(new RegExp(`(?:^|[^\\d.])(\\d+(?:\\.\\d+)?)\\s*(${units})\\b`,'gi'))];if(pairs.length){const q=pairs.at(-1);return{...normalizedMeasure(q[1],q[2]),source:'name'}}
 return{qty:'',unit:'',source:'none'};
}
export function unitPrice(p,fmt,choice={}){
 if(fmt.error)return null;if(fmt.format==='B1G1'||fmt.format==='B1G2')return{amount:fmt.spCents,unit:'PCS'};
 let raw=String(choice.qty??'').trim(),u=String(choice.unit??'').trim().toUpperCase();if(!raw||!u){const inf=inferPack(p);raw=inf.qty;u=inf.unit;}
 const quantity=decimalParts(raw);if(!quantity||quantity.num<=0n)return null;let total={...quantity},label='';
 if(['GRAM','GRAMS','GM','GMS','G'].includes(u)){total.den*=1000n;label='KG'}else if(['KG','KGS'].includes(u))label='KG';else if(['LTR','LT','LTS','LITRE','LITRES','L'].includes(u))label='LTR';else if(u==='ML'){total.den*=1000n;label='LTR'}else if(['NOS','PCS','PIECES'].includes(u)){if(!fmt.kind.countable)return null;label='NOS'}else return null;
 if(total.num<2n*total.den)return null;if(label==='NOS'&&total.num%total.den!==0n)return null;const cents=BigInt(fmt.spCents)*total.den/total.num;if(cents>BigInt(Number.MAX_SAFE_INTEGER))return null;return{amount:Number(cents),unit:label,total:decimalString(total.num,total.den)};
}
/** REG-STAT MAIN CODE: NON CORE is the only Non-Core classification. */
export function isNonCoreProduct(p){return String(p?.main??'').toUpperCase().replace(/[-_\s]+/g,' ').trim()==='NON CORE'}
