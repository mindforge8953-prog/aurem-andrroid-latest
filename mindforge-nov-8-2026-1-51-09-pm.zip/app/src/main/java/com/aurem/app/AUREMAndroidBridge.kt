package com.aurem.app

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.webkit.JavascriptInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import android.util.Log

class AUREMAndroidBridge(private val activity: Activity) {
    private val pdfIoExecutor = Executors.newSingleThreadExecutor()
    private val aiExecutor = Executors.newFixedThreadPool(2)

    private data class LinearCrop(val bitmap: android.graphics.Bitmap, val barBottom: Int, val found: Boolean, val score: Double)
    private data class OcrToken(val value: String, val box: Rect)
    private fun validEan13(value: String): Boolean { if (value.length != 13 || !value.all { it.isDigit() }) return false; val sum=(0 until 12).sumOf { (value[it]-'0') * if (it % 2 == 0) 1 else 3 }; return (10-sum%10)%10 == value[12]-'0' }

    private fun localizedBarcodeCrop(source: android.graphics.Bitmap): LinearCrop {
        val scale = minOf(1f, 1000f / maxOf(source.width, source.height))
        val base = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(source, (source.width * scale).toInt().coerceAtLeast(1), (source.height * scale).toInt().coerceAtLeast(1), true) else source
        var best: LinearCrop? = null
        for (degree in listOf(0f, 90f, 180f, 270f)) {
            val rotated = if (degree == 0f) base else android.graphics.Bitmap.createBitmap(base, 0, 0, base.width, base.height, android.graphics.Matrix().apply { postRotate(degree) }, true)
            val w = rotated.width; val h = rotated.height
            val edges = IntArray(h)
            for (y in 0 until h) {
                var previous = (android.graphics.Color.red(rotated.getPixel(0, y)) + android.graphics.Color.green(rotated.getPixel(0, y)) + android.graphics.Color.blue(rotated.getPixel(0, y))) / 3
                for (x in 2 until w step 2) {
                    val color = rotated.getPixel(x, y)
                    val gray = (android.graphics.Color.red(color) + android.graphics.Color.green(color) + android.graphics.Color.blue(color)) / 3
                    if (kotlin.math.abs(gray - previous) > 55) edges[y]++
                    previous = gray
                }
            }
            val threshold = maxOf(14, w / 42)
            val minRun = maxOf(10, h / 55)
            var start = -1; var last = -1
            for (y in 0 until h) {
                if (edges[y] >= threshold) { if (start < 0) start = y; last = y }
                else if (start >= 0 && y - last > 2) {
                    val length = last - start + 1
                    if (length >= minRun) {
                        val avg = edges.slice(start..last).average()
                        val score = avg * kotlin.math.sqrt(length.toDouble())
                        val top = (start - (length * .08).toInt()).coerceAtLeast(0)
                        val bottom = (last + (length * .72).toInt()).coerceAtMost(h - 1)
                        val crop = android.graphics.Bitmap.createBitmap(rotated, 0, top, w, (bottom - top + 1).coerceAtLeast(1))
                        val candidate = LinearCrop(crop, last - top, true, score)
                        if (best == null || candidate.score > best!!.score) { best?.bitmap?.recycle(); best = candidate } else candidate.bitmap.recycle() 
                    }
                    start = -1; last = -1
                }
            }
            if (start >= 0) {
                val length = last - start + 1
                if (length >= minRun) {
                    val avg = edges.slice(start..last).average(); val score = avg * kotlin.math.sqrt(length.toDouble())
                    val top = (start - (length * .08).toInt()).coerceAtLeast(0); val bottom = (last + (length * .72).toInt()).coerceAtMost(h - 1)
                    val candidate = LinearCrop(android.graphics.Bitmap.createBitmap(rotated, 0, top, w, (bottom - top + 1).coerceAtLeast(1)), last - top, true, score)
                    if (best == null || candidate.score > best!!.score) { best?.bitmap?.recycle(); best = candidate } else candidate.bitmap.recycle()
                }
            }
            if (rotated !== base) rotated.recycle()
        }
        val chosen = best ?: LinearCrop(base, base.height / 2, false, 0.0)
        if (base !== source && chosen.bitmap !== base) base.recycle()
        return chosen
    }

    @JavascriptInterface
    fun recognizeDigits(base64Image: String, requestId: String) {
        try {
            val bytes = Base64.decode(base64Image, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw IllegalArgumentException("Camera frame could not be decoded")
            val region = localizedBarcodeCrop(bitmap)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(region.bitmap, 0))
                .addOnSuccessListener { result ->
                    val textLines = result.textBlocks.flatMap { it.lines }
                    val tokens = textLines.flatMap { line ->
                        val box = line.boundingBox ?: return@flatMap emptyList<OcrToken>()
                        Regex("[0-9]{1,14}").findAll(line.text).map { OcrToken(it.value, Rect(box)) }.toList()
                    }
                    val candidates = mutableListOf<String>()
                    // Some EAN-13 labels print the first digit separately from the following 12.
                    // Combine only digits OCR actually read, using text adjacency or their measured positions.
                    for (line in textLines) {
                        Regex("(?<![0-9])([0-9])\\s+([0-9]{12})(?![0-9])").findAll(line.text).forEach { candidates.add(it.groupValues[1] + it.groupValues[2]) }
                    }
                    val groups = tokens.filter { it.value.length == 12 }
                    val singles = tokens.filter { it.value.length == 1 }
                    for (group in groups) {
                        val prefix = singles.filter { token ->
                            val gap = group.box.left - token.box.right
                            val maxGap = maxOf(48, group.box.height() * 5)
                            gap in 0..maxGap && kotlin.math.abs(group.box.centerY() - token.box.centerY()) <= maxOf(18, group.box.height() * 2)
                        }.minByOrNull { group.box.left - it.box.right }
                        if (prefix != null) candidates.add(prefix.value + group.value)
                    }
                    candidates.addAll(tokens.filter { it.value.length in 5..14 }.map { it.value })
                    val ordered = candidates.distinct().sortedWith(compareBy<String>({ if (validEan13(it)) 0 else 1 }, { if (it.length == 13) 0 else 1 }, { it.length }))
                    val output = (if (region.found) "" else "UNSURE\n") + ordered.joinToString("\n")
                    activity.runOnUiThread { webViewCallback("window.onAuremOcrResult(${JSONObject.quote(requestId)},${JSONObject.quote(output)})") }
                    recognizer.close(); region.bitmap.recycle(); if (region.bitmap !== bitmap) bitmap.recycle()
                }
                .addOnFailureListener { error ->
                    activity.runOnUiThread { webViewCallback("window.onAuremOcrResult(${JSONObject.quote(requestId)},'')") }
                    recognizer.close(); region.bitmap.recycle(); if (region.bitmap !== bitmap) bitmap.recycle()
                }
        } catch (e: Exception) {
            activity.runOnUiThread { webViewCallback("window.onAuremOcrResult(${JSONObject.quote(requestId)},'')") }
        }
    }

    private fun webViewCallback(script: String) {
        (activity as? MainActivity)?.runOcrCallback(script)
    }

    @JavascriptInterface
    fun isAndroid(): Boolean {
        return true
    }

    @JavascriptInterface
    fun getSignedInUser(): String {
        return (activity as? MainActivity)?.getSignedInUserJson() ?: "{\"signedIn\":false}"
    }

    @JavascriptInterface
    fun requestGoogleSignIn() {
        activity.runOnUiThread {
            (activity as? MainActivity)?.launchGoogleSignIn()
        }
    }

    @JavascriptInterface
    fun requestSignOut() {
        activity.runOnUiThread {
            (activity as? MainActivity)?.performSignOut()
        }
    }

    @JavascriptInterface
    fun getGoogleIdToken(): String {
        return (activity as? MainActivity)?.getGoogleIdToken() ?: ""
    }

    @JavascriptInterface
    fun generateAiArtwork(prompt: String, orientation: String, idToken: String, referencesJson: String, requestId: String) {
        generateAiArtwork(prompt, orientation, idToken, referencesJson, requestId, "@cf/black-forest-labs/flux-2-klein-4b")
    }

    @JavascriptInterface
    fun generateAiArtwork(prompt: String, orientation: String, idToken: String, referencesJson: String, requestId: String, modelId: String) {
        aiExecutor.execute {
            try {
                val boundary = "===AUREM_BOUNDARY_" + System.currentTimeMillis() + "==="
                val url = java.net.URL("https://aurem-ai-test.grnpatan8953.workers.dev/generate")
                val conn = url.openConnection() as javax.net.ssl.HttpsURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 30000
                conn.readTimeout = 120000
                conn.doInput = true
                conn.doOutput = true
                conn.useCaches = false
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                if (idToken.isNotBlank()) {
                    conn.setRequestProperty("Authorization", "Bearer $idToken")
                }

                val width = if (orientation.equals("portrait", ignoreCase = true)) 768 else 1024
                val height = if (orientation.equals("portrait", ignoreCase = true)) 1024 else 768

                // Parse reference images JSON array
                val refList = mutableListOf<ByteArray>()
                try {
                    if (referencesJson.isNotBlank()) {
                        val jsonArr = org.json.JSONArray(referencesJson)
                        for (i in 0 until minOf(jsonArr.length(), 4)) {
                            val dataUrl = jsonArr.optString(i, "")
                            if (dataUrl.contains(",")) {
                                val b64 = dataUrl.substringAfter(",")
                                val bytes = Base64.decode(b64, Base64.DEFAULT)
                                if (bytes != null && bytes.isNotEmpty()) {
                                    refList.add(bytes)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w("AUREM_AI", "Failed to parse reference images", e)
                }

                conn.outputStream.use { os ->
                    fun writeTextPart(name: String, value: String) {
                        os.write(("--$boundary\r\n").toByteArray())
                        os.write(("Content-Disposition: form-data; name=\"$name\"\r\n\r\n").toByteArray())
                        os.write(value.toByteArray(Charsets.UTF_8))
                        os.write("\r\n".toByteArray())
                    }

                    fun writeBinaryPart(name: String, bytes: ByteArray, filename: String) {
                        os.write(("--$boundary\r\n").toByteArray())
                        os.write(("Content-Disposition: form-data; name=\"$name\"; filename=\"$filename\"\r\n").toByteArray())
                        os.write(("Content-Type: image/jpeg\r\n\r\n").toByteArray())
                        os.write(bytes)
                        os.write("\r\n".toByteArray())
                    }

                    writeTextPart("prompt", prompt)
                    writeTextPart("model", modelId.ifBlank { "@cf/black-forest-labs/flux-2-klein-4b" })
                    writeTextPart("width", width.toString())
                    writeTextPart("height", height.toString())

                    for ((idx, imgBytes) in refList.withIndex()) {
                        writeBinaryPart("image_$idx", imgBytes, "ref_$idx.jpg")
                    }

                    os.write(("--$boundary--\r\n").toByteArray())
                    os.flush()
                }

                val responseCode = conn.responseCode
                if (responseCode in 200..299) {
                    val bytes = conn.inputStream.use { it.readBytes() }
                    // Validate JPEG magic bytes FF D8 FF
                    if (bytes.size < 10 || bytes[0] != 0xFF.toByte() || bytes[1] != 0xD8.toByte() || bytes[2] != 0xFF.toByte()) {
                        val errText = String(bytes, Charsets.UTF_8)
                        val msg = try { JSONObject(errText).optString("error", errText) } catch (_: Exception) { errText }
                        activity.runOnUiThread {
                            webViewCallback("window.onAuremAiGenerated && window.onAuremAiGenerated(${JSONObject.quote(requestId)}, false, '', ${JSONObject.quote(msg)})")
                        }
                        return@execute
                    }

                    val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    val dataUrl = "data:image/jpeg;base64,$base64"
                    activity.runOnUiThread {
                        webViewCallback("window.onAuremAiGenerated && window.onAuremAiGenerated(${JSONObject.quote(requestId)}, true, ${JSONObject.quote(dataUrl)}, '')")
                    }
                } else {
                    val err = try {
                        conn.errorStream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: "HTTP $responseCode"
                    } catch (_: Exception) {
                        "HTTP $responseCode"
                    }
                    val cleanErr = try { JSONObject(err).optString("error", err) } catch (_: Exception) { err }
                    activity.runOnUiThread {
                        webViewCallback("window.onAuremAiGenerated && window.onAuremAiGenerated(${JSONObject.quote(requestId)}, false, '', ${JSONObject.quote(cleanErr)})")
                    }
                }
            } catch (e: Exception) {
                Log.e("AUREM_AI", "generateAiArtwork failed", e)
                val errMsg = e.localizedMessage ?: "Network connection failed"
                activity.runOnUiThread {
                    webViewCallback("window.onAuremAiGenerated && window.onAuremAiGenerated(${JSONObject.quote(requestId)}, false, '', ${JSONObject.quote(errMsg)})")
                }
            }
        }
    }

    @JavascriptInterface
    fun saveFile(base64Data: String, fileName: String, mimeType: String) {
        pdfIoExecutor.execute {
            val startedAt = System.nanoTime()
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val savedUri = saveToDownloads(fileName, mimeType, bytes)
                Log.i("AUREM_PDF", "saveFile decode+write ${(System.nanoTime()-startedAt)/1_000_000}ms bytes=${bytes.size}")
                activity.runOnUiThread {
                    if (savedUri != null) showDownloadSuccessDialog(fileName, savedUri, mimeType)
                    else Toast.makeText(activity, "Failed to save $fileName to Downloads", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Log.e("AUREM_PDF", "saveFile failed after ${(System.nanoTime()-startedAt)/1_000_000}ms", e)
                activity.runOnUiThread { Toast.makeText(activity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    @JavascriptInterface
    fun printPdf(base64Data: String, jobTitle: String) {
        pdfIoExecutor.execute {
            val startedAt = System.nanoTime()
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val tempFile = File(activity.cacheDir, "print_job_${System.currentTimeMillis()}.pdf")
                tempFile.writeBytes(bytes)

                Log.i("AUREM_PDF", "printFile decode+write ${(System.nanoTime()-startedAt)/1_000_000}ms bytes=${bytes.size}")
                activity.runOnUiThread {
                    val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                    if (printManager == null) {
                        Toast.makeText(activity, "Printing service unavailable on this device", Toast.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    val adapter = PdfPrintDocumentAdapter(tempFile, jobTitle)
                    val attributes = PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
                    printManager.print(jobTitle, adapter, attributes)
                }
            } catch (e: Exception) {
                Log.e("AUREM_PDF", "printPdf failed after ${(System.nanoTime()-startedAt)/1_000_000}ms", e)
                activity.runOnUiThread { Toast.makeText(activity, "Print setup failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    @JavascriptInterface
    fun sharePdf(base64Data: String, fileName: String, targetPackage: String) {
        pdfIoExecutor.execute {
            val startedAt = System.nanoTime()
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val shareDir = File(activity.cacheDir, "shares")
                if (!shareDir.exists()) shareDir.mkdirs()
                val tempFile = File(shareDir, fileName)
                FileOutputStream(tempFile).use { it.write(bytes) }

                val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", tempFile)
                Log.i("AUREM_PDF", "sharePdf written in ${(System.nanoTime()-startedAt)/1_000_000}ms bytes=${bytes.size}")

                activity.runOnUiThread {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, fileName)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }

                    if (targetPackage.equals("whatsapp", ignoreCase = true)) {
                        val pm = activity.packageManager
                        val whatsappPackages = listOf("com.whatsapp", "com.whatsapp.w4b")
                        val installedPkg = whatsappPackages.firstOrNull { pkg ->
                            try {
                                pm.getPackageInfo(pkg, 0)
                                true
                            } catch (_: Exception) {
                                false
                            }
                        }

                        if (installedPkg != null) {
                            shareIntent.setPackage(installedPkg)
                            try {
                                activity.startActivity(shareIntent)
                                return@runOnUiThread
                            } catch (e: Exception) {
                                Log.w("AUREM_SHARE", "Direct launch of WhatsApp failed, falling back to chooser", e)
                            }
                        } else {
                            Toast.makeText(activity, "WhatsApp not found on device; opening share options.", Toast.LENGTH_SHORT).show()
                        }
                    }

                    val chooser = Intent.createChooser(shareIntent, "Share PDF with")
                    activity.startActivity(chooser)
                }
            } catch (e: Exception) {
                Log.e("AUREM_SHARE", "sharePdf failed", e)
                activity.runOnUiThread {
                    Toast.makeText(activity, "Share PDF failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun saveToDownloads(fileName: String, mimeType: String, bytes: ByteArray): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/AUREM")
                }
                val resolver = activity.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { it.write(bytes) }
                }
                uri
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val auremDir = File(downloadsDir, "AUREM")
                if (!auremDir.exists()) auremDir.mkdirs()
                val file = File(auremDir, fileName)
                FileOutputStream(file).use { it.write(bytes) }
                MediaScannerConnection.scanFile(activity, arrayOf(file.absolutePath), arrayOf(mimeType), null)
                FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun showDownloadSuccessDialog(fileName: String, uri: Uri, mimeType: String) {
        val message = "File successfully saved to:\nDownloads/AUREM/$fileName\n\nWould you like to open it now?"
        AlertDialog.Builder(activity)
            .setTitle("AUREM — File Saved")
            .setMessage(message)
            .setPositiveButton("Open File") { _, _ ->
                openFile(uri, mimeType)
            }
            .setNegativeButton("Done", null)
            .show()
    }

    private fun openFile(uri: Uri, mimeType: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            activity.startActivity(Intent.createChooser(intent, "Open file with"))
        } catch (e: Exception) {
            Toast.makeText(activity, "No application found on device to open $mimeType", Toast.LENGTH_LONG).show()
        }
    }
}
