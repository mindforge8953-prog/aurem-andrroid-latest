/**
 * AUREM AI Board Studio — Production Cloudflare Worker
 * Models Supported:
 * 1. @cf/black-forest-labs/flux-2-klein-4b (Default, balanced, supports up to 4 ref images)
 * 2. @cf/black-forest-labs/flux-1-schnell (Ultra fast 4-step, strictly prompt + steps: 4, no width/height)
 * 3. @cf/leonardo/lucid-origin (Leonardo Lucid Origin photorealistic retail)
 * 4. @cf/leonardo/phoenix-1.0 (Leonardo Phoenix 1.0 stylized creative)
 * 5. @cf/black-forest-labs/flux-2-klein-9b (9B high fidelity detail)
 * 6. @cf/black-forest-labs/flux-2-dev (FLUX.2 Dev maximum quality)
 *
 * Features:
 * - Mandatory server-side Google OAuth ID Token verification (aud, iss, exp, sub)
 * - Strict per-user daily quota enforcement (10 generations/user/day) via KV AI_USAGE
 * - Model-specific payload routing & constraint handling (e.g. FLUX.1 Schnell strictly excludes width/height)
 * - Support for up to 4 reference images (image_0 to image_3) where supported
 * - Robust output validation (JPEG/PNG magic bytes verification)
 * - Full CORS support
 */

const EXPECTED_CLIENT_ID = "119004603451-bnmu5tolkta41d5fgas0geueekpmf8bj.apps.googleusercontent.com";
const DAILY_LIMIT_PER_USER = 10;

const ALLOWED_MODELS = [
  "@cf/black-forest-labs/flux-2-klein-4b",
  "@cf/black-forest-labs/flux-1-schnell",
  "@cf/leonardo/lucid-origin",
  "@cf/leonardo/phoenix-1.0",
  "@cf/black-forest-labs/flux-2-klein-9b",
  "@cf/black-forest-labs/flux-2-dev"
];

const DEFAULT_MODEL = "@cf/black-forest-labs/flux-2-klein-4b";

function getCorsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
  };
}

async function verifyGoogleToken(idToken) {
  if (!idToken || typeof idToken !== "string" || idToken.length < 20) {
    return { valid: false, error: "Missing or malformed Google ID token" };
  }

  try {
    const res = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`, {
      headers: { "Accept": "application/json" }
    });

    if (!res.ok) {
      return { valid: false, error: "Google token verification failed (HTTP " + res.status + ")" };
    }

    const payload = await res.json();

    // Verify audience matches AUREM OAuth Web Client ID or project number
    if (payload.aud !== EXPECTED_CLIENT_ID && (!payload.aud || !payload.aud.startsWith("119004603451"))) {
      return { valid: false, error: "Token audience mismatch for AUREM" };
    }

    // Verify issuer
    if (payload.iss !== "accounts.google.com" && payload.iss !== "https://accounts.google.com") {
      return { valid: false, error: "Invalid token issuer" };
    }

    // Verify expiration
    const nowSec = Math.floor(Date.now() / 1000);
    if (payload.exp && Number(payload.exp) < nowSec) {
      return { valid: false, error: "Google ID token has expired" };
    }

    const today = new Date().toISOString().slice(0, 10);
    const userId = payload.sub || payload.email || "unknown";

    return {
      valid: true,
      userId,
      email: payload.email || "",
      name: payload.name || "",
      dayKey: `aurem:quota:${today}:${userId}`
    };
  } catch (err) {
    return { valid: false, error: "Token verification network error: " + err.message };
  }
}

async function checkAndIncrementUsage(env, dayKey) {
  if (!env.AI_USAGE) {
    throw Error("Cloudflare KV binding 'AI_USAGE' is required for durable quota enforcement.");
  }
  const currentVal = await env.AI_USAGE.get(dayKey);
  const current = currentVal ? parseInt(currentVal, 10) : 0;
  if (current >= DAILY_LIMIT_PER_USER) {
    return { allowed: false, count: current };
  }
  await env.AI_USAGE.put(dayKey, (current + 1).toString(), { expirationTtl: 86400 });
  return { allowed: true, count: current + 1 };
}

export default {
  async fetch(request, env) {
    const cors = getCorsHeaders();

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }

    if (request.method === "GET") {
      return new Response(
        JSON.stringify({
          status: "ok",
          service: "AUREM AI Board Studio",
          defaultModel: DEFAULT_MODEL,
          supportedModels: ALLOWED_MODELS,
          freeTierQuota: `${DAILY_LIMIT_PER_USER} generations/day`,
          timestamp: new Date().toISOString()
        }),
        { headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    if (request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method Not Allowed" }), {
        status: 405,
        headers: { "Content-Type": "application/json", ...cors }
      });
    }

    // MANDATORY AUTHENTICATION: Reject every unauthenticated request
    const authHeader = request.headers.get("Authorization") || "";
    const idToken = authHeader.replace(/^Bearer\s+/i, "").trim();

    if (!idToken) {
      return new Response(
        JSON.stringify({ error: "Authentication required. Google ID token missing." }),
        { status: 401, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    const authResult = await verifyGoogleToken(idToken);
    if (!authResult.valid) {
      return new Response(
        JSON.stringify({ error: authResult.error }),
        { status: 401, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    const user = authResult;

    // Enforce durable daily free usage quota
    try {
      const usage = await checkAndIncrementUsage(env, user.dayKey);
      if (!usage.allowed) {
        return new Response(
          JSON.stringify({
            error: `Daily free quota reached (${DAILY_LIMIT_PER_USER} generations/day). Quota resets tomorrow.`,
            quotaReached: true
          }),
          { status: 429, headers: { "Content-Type": "application/json", ...cors } }
        );
      }
    } catch (quotaErr) {
      return new Response(
        JSON.stringify({ error: "Quota enforcement error: " + quotaErr.message }),
        { status: 500, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    // Parse payload
    let prompt = "";
    let width = 1024;
    let height = 1024;
    let requestedModel = DEFAULT_MODEL;
    const images = [];

    try {
      const contentType = request.headers.get("content-type") || "";
      if (contentType.includes("multipart/form-data")) {
        const formData = await request.formData();
        prompt = (formData.get("prompt") || "").toString().trim();
        const m = (formData.get("model") || "").toString().trim();
        if (m && ALLOWED_MODELS.includes(m)) requestedModel = m;

        const w = parseInt(formData.get("width"), 10);
        const h = parseInt(formData.get("height"), 10);
        if (!isNaN(w) && w > 0) width = w;
        if (!isNaN(h) && h > 0) height = h;

        // Extract up to 4 reference images (image_0 to image_3)
        for (let i = 0; i < 4; i++) {
          const imgField = formData.get(`image_${i}`) || formData.get(`image${i}`);
          if (imgField && typeof imgField === "object") {
            const arrayBuffer = await imgField.arrayBuffer();
            images.push([...new Uint8Array(arrayBuffer)]);
          }
        }
      } else {
        const json = await request.json().catch(() => ({}));
        prompt = (json.prompt || "").toString().trim();
        const m = (json.model || "").toString().trim();
        if (m && ALLOWED_MODELS.includes(m)) requestedModel = m;
        if (json.width) width = json.width;
        if (json.height) height = json.height;
      }
    } catch (parseErr) {
      return new Response(
        JSON.stringify({ error: "Failed to parse request payload: " + parseErr.message }),
        { status: 400, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    if (!prompt || prompt.length < 3) {
      return new Response(
        JSON.stringify({ error: "Missing or invalid 'prompt' parameter" }),
        { status: 400, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    try {
      let aiInput;

      if (requestedModel === "@cf/black-forest-labs/flux-1-schnell") {
        // FLUX.1 Schnell strictly forbids width/height and references (Error 5006)
        aiInput = {
          prompt,
          steps: 4
        };
      } else {
        aiInput = {
          prompt,
          width,
          height
        };

        if (images.length > 0) {
          aiInput.image = images[0];
          if (images.length > 1) {
            aiInput.images = images;
          }
        }
      }

      const aiResponse = await env.AI.run(requestedModel, aiInput);

      let imageBytes = null;
      let contentType = "image/jpeg";

      if (aiResponse instanceof Uint8Array || aiResponse instanceof ArrayBuffer) {
        imageBytes = new Uint8Array(aiResponse);
      } else if (aiResponse && typeof aiResponse === "object") {
        if (aiResponse.image && typeof aiResponse.image === "string") {
          const b64 = aiResponse.image.replace(/^data:image\/[a-z]+;base64,/, "");
          const bin = atob(b64);
          imageBytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) imageBytes[i] = bin.charCodeAt(i);
        } else if (aiResponse instanceof ReadableStream) {
          const buf = await new Response(aiResponse).arrayBuffer();
          imageBytes = new Uint8Array(buf);
        }
      }

      if (!imageBytes || imageBytes.length < 100) {
        throw Error("AI model returned invalid or empty image output");
      }

      // Detect format: JPEG (FF D8 FF) or PNG (89 50 4E 47)
      const isJpeg = imageBytes[0] === 0xff && imageBytes[1] === 0xd8 && imageBytes[2] === 0xff;
      const isPng = imageBytes[0] === 0x89 && imageBytes[1] === 0x50 && imageBytes[2] === 0x4e && imageBytes[3] === 0x47;

      if (isJpeg) {
        contentType = "image/jpeg";
      } else if (isPng) {
        contentType = "image/png";
      } else {
        try {
          const text = new TextDecoder().decode(imageBytes);
          const json = JSON.parse(text);
          if (json.error) throw Error(json.error);
        } catch (_) {}
        throw Error("Generated output is not a valid JPEG/PNG image stream");
      }

      return new Response(imageBytes, {
        headers: {
          "Content-Type": contentType,
          "Cache-Control": "public, max-age=86400",
          ...cors
        }
      });
    } catch (err) {
      return new Response(
        JSON.stringify({ error: "Cloudflare AI generation failed: " + err.message }),
        { status: 500, headers: { "Content-Type": "application/json", ...cors } }
      );
    }
  }
};
