# AUREM Cloudflare Worker — Deployment Instructions

This Cloudflare Worker powers the **AUREM AI Board Studio** with 6 supported Cloudflare Workers AI models.

---

## 6 Supported AI Models
1. **`@cf/black-forest-labs/flux-2-klein-4b`** (Default) — Fast, balanced, supports up to 4 reference photos.
2. **`@cf/black-forest-labs/flux-1-schnell`** — Ultra-fast 4-step generation. Strictly prompt + `steps: 4` (no width/height, text only).
3. **`@cf/leonardo/lucid-origin`** — Leonardo Lucid Origin photorealistic commercial retail imagery.
4. **`@cf/leonardo/phoenix-1.0`** — Leonardo Phoenix 1.0 high-impact creative and stylized retail artwork.
5. **`@cf/black-forest-labs/flux-2-klein-9b`** — 9B parameter high-fidelity commercial detail.
6. **`@cf/black-forest-labs/flux-2-dev`** — FLUX.2 Dev flagship quality.

---

## Zero Cost & Safe Free Plan Guarantee
- **No paid Cloudflare subscription** is required.
- **Workers AI Free Tier** includes daily free model requests.
- **No secrets or credentials** are stored inside the Android APK.
- Access is authenticated via the user's Google Sign-In session (`id_token`) validated against the AUREM Web Client ID: `119004603451-bnmu5tolkta41d5fgas0geueekpmf8bj.apps.googleusercontent.com`.
- Quota: 10 generations per user per day via KV `AI_USAGE` binding.

---

## Deploy in 2 Minutes via Cloudflare Dashboard (Recommended)

1. Log in to your [Cloudflare Dashboard](https://dash.cloudflare.com/).
2. In the left navigation menu, click **Workers & Pages**.
3. Click your existing worker: **`aurem-ai-test`** (or create a new Worker named `aurem-ai-test`).
4. In the top-right corner, click **Edit code** (or **Quick Edit**).
5. Open `worker.js` in the editor.
6. Replace all existing text with the complete contents of `cloudflare/worker.js`.
7. Ensure the AI Binding is active:
   - Go to **Settings** > **Bindings** (or **Variables & Secrets**).
   - Under **Workers AI**, confirm there is a binding named `AI` assigned to **Workers AI**.
   - Under **KV Namespace Bindings**, confirm `AI_USAGE` is bound to your quota namespace.
8. Click **Deploy** (or **Save and Deploy**).
9. Done! The Worker endpoint is live at:
   `https://aurem-ai-test.grnpatan8953.workers.dev/generate`

---

## Deploy via Wrangler CLI

If you use Wrangler on your computer:
```bash
cd cloudflare
npx wrangler deploy
```

With `wrangler.toml`:
```toml
name = "aurem-ai-test"
main = "worker.js"
compatibility_date = "2024-11-01"

[ai]
binding = "AI"

[[kv_namespaces]]
binding = "AI_USAGE"
id = "<your-kv-namespace-id>"
```

---

## Verification
You can test the deployed worker with:
```bash
curl https://aurem-ai-test.grnpatan8953.workers.dev/
```
Expected response:
```json
{
  "status": "ok",
  "service": "AUREM AI Board Studio",
  "defaultModel": "@cf/black-forest-labs/flux-2-klein-4b",
  "supportedModels": [
    "@cf/black-forest-labs/flux-2-klein-4b",
    "@cf/black-forest-labs/flux-1-schnell",
    "@cf/leonardo/lucid-origin",
    "@cf/leonardo/phoenix-1.0",
    "@cf/black-forest-labs/flux-2-klein-9b",
    "@cf/black-forest-labs/flux-2-dev"
  ],
  "freeTierQuota": "10 generations/day"
}
```
